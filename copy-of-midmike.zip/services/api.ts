
// Fix: Added BaseEntity to the import statement from types.ts to resolve "Cannot find name 'BaseEntity'" errors
import { EventEntity, ProfessionalEntity, BaseEntity, OpportunityEntity, ContentItem, BookingRequest, BookingStatus } from '../types';

// Image Width Constants for Optimization
const WIDTH_FEATURED = 1200;
const WIDTH_PORTRAIT = 800;
const WIDTH_THUMB = 400;

export const mockEvents: EventEntity[] = [
  {
    id: 'e1',
    title: 'DJ Black Friday Night Party',
    imageUrl: `https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=85&w=${WIDTH_FEATURED}&auto=format&fit=crop`,
    category: 'Featured Event',
    date: 'Fri 02/05',
    location: 'Hotel Houria Palace',
    price: '120 TND',
    description: 'The most anticipated nocturnal event of the season. Experience a masterclass in sound and rhythm at the exclusive Friday Night Party.',
    tags: ['Nightlife', 'DJ Black', 'Exclusive'],
    rating: 5.0
  },
  {
    id: 'e2',
    title: 'Midnight Terrace',
    imageUrl: `https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'House / Disco',
    date: '21:00',
    location: 'La Marsa',
    price: '45 TND',
    description: 'Open air rooftop vibes.',
    tags: ['Rooftop', 'DJ'],
    rating: 4.5
  },
  {
    id: 'e3',
    title: 'Analog Ritual',
    imageUrl: `https://images.unsplash.com/photo-1514525253361-bee8718a747c?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'Live Set',
    date: '22:30',
    location: 'Downtown',
    price: '60 TND',
    description: 'Experimental electronic live set.',
    tags: ['Live', 'Techno'],
    rating: 4.9
  },
  {
    id: 'e4',
    title: 'Cinema Wave',
    imageUrl: `https://images.unsplash.com/photo-1492684223066-81342ee5ff30?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'Visual Show',
    date: '20:00',
    location: 'The Bridge',
    price: '30 TND',
    description: 'Immersive audio-visual experience.',
    tags: ['AV', 'Art'],
    rating: 4.6
  },
  {
    id: 'e5',
    title: 'Neon Session',
    imageUrl: `https://images.unsplash.com/photo-1574169208507-84376144848b?q=80&w=${WIDTH_PORTRAIT}&auto=format&fit=crop`,
    category: 'DJ Set',
    date: '23:00',
    location: 'Gammarth',
    price: '25 TND',
    description: 'Late night groove.',
    tags: ['Club', 'Dance'],
    rating: 4.4
  },
  {
    id: 'e6',
    title: 'Velvet Lounge',
    imageUrl: `https://images.unsplash.com/photo-1571266028243-3716f02d2d2e?q=80&w=${WIDTH_PORTRAIT}&auto=format&fit=crop`,
    category: 'Jazz Night',
    date: '19:00',
    location: 'Sidi Bou',
    price: '80 TND',
    description: 'Smooth jazz and cocktails.',
    tags: ['Jazz', 'Lounge'],
    rating: 4.8
  },
  {
    id: 'e7',
    title: 'Pulse Underground',
    imageUrl: `https://images.unsplash.com/photo-1545128485-c400e7702796?q=80&w=${WIDTH_PORTRAIT}&auto=format&fit=crop`,
    category: 'Techno',
    date: '01:00',
    location: 'Warehouse X',
    price: '35 TND',
    description: 'Uncompromising techno rhythms.',
    tags: ['Industrial', 'Techno'],
    rating: 4.7
  }
];

export const mockArtists: ProfessionalEntity[] = [
  {
    id: 'a1',
    title: 'A.L.A',
    imageUrl: `https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'Singer',
    profession: 'Rap / Pop',
    location: 'Tunis',
    rating: 5.0,
    verified: true,
    tags: ['Focus: Singer'],
    priceRange: '2500 - 4000 TND',
    responseTime: '24h',
    bio: 'Tunisian rap icon bringing lyrical depth and high-energy performance.',
    specialties: ['Rap', 'Trap', 'Songwriting']
  },
  {
    id: 'a2',
    title: 'Galbi',
    imageUrl: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'Singer',
    profession: 'Alternative',
    location: 'Sousse',
    rating: 4.8,
    verified: true,
    tags: ['Focus: Singer'],
    priceRange: '800 - 1500 TND',
    responseTime: '4h',
    bio: 'Soulful alternative voices mixing traditional roots with modern indie vibes.',
    specialties: ['Indie', 'Folk', 'Acoustic']
  },
  {
    id: 'a3',
    title: 'Mardi',
    imageUrl: `https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'Singer',
    profession: 'Hip Hop',
    location: 'Hammamet',
    rating: 4.9,
    verified: true,
    tags: ['Focus: Singer'],
    priceRange: '1200 - 2000 TND',
    responseTime: '12h'
  },
  {
    id: 'a4',
    title: 'Omar',
    imageUrl: `https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'DJ',
    profession: 'House',
    location: 'Tunis',
    rating: 4.7,
    verified: true,
    tags: ['Focus: DJ'],
    priceRange: '500 - 1000 TND',
    responseTime: '1h'
  }
];

export const mockTechnicians: ProfessionalEntity[] = [
  {
    id: 't1',
    title: 'SoundMaster Pro',
    imageUrl: `https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'Sound Engineer',
    profession: 'Audio Engineering',
    location: 'Tunis',
    rating: 4.9,
    verified: true,
    tags: ['Live Sound', 'Mixing'],
    hasEquipment: true,
    equipment: 'Midas M32 Console, 4x Line Array, Shure Mic Kit',
    priceRange: '400 TND (Daily)',
    responseTime: '2h',
    bio: 'Senior Audio Engineer with 10 years experience in festival sound design.'
  },
  {
    id: 't2',
    title: 'Lumina FX',
    imageUrl: `https://images.unsplash.com/photo-1514525253361-bee8718a747c?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'Light Tech',
    profession: 'Lighting Designer',
    location: 'Sousse',
    rating: 4.8,
    verified: true,
    tags: ['Stage Design', 'Lasers'],
    hasEquipment: true,
    equipment: 'GrandMA2 Command Wing, 12x Beam Moving Heads',
    priceRange: '500 TND (Show)',
    responseTime: '5h'
  },
  {
    id: 't3',
    title: 'Visual Core',
    imageUrl: `https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'Video Tech',
    profession: 'VJ / Mapping',
    location: 'Hammamet',
    rating: 5.0,
    verified: true,
    tags: ['Projection', 'LED Walls'],
    hasEquipment: false,
    priceRange: '600 TND (Project)',
    responseTime: '24h'
  }
];

export const mockVenues: BaseEntity[] = [
  {
    id: 'v1',
    title: 'Sky Lounge',
    imageUrl: `https://images.unsplash.com/photo-1566414791190-04534b9d090a?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'Rooftop',
    location: 'Gammarth',
    rating: 4.7,
    verified: true,
    tags: ['Cocktails', 'View']
  },
  {
    id: 'v2',
    title: 'The Warehouse',
    imageUrl: `https://images.unsplash.com/photo-1514933651103-005eec06c04b?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'Club',
    location: 'Industrial Zone',
    rating: 4.6,
    verified: true,
    tags: ['Underground', 'Techno']
  },
  {
    id: 'v3',
    title: 'Villa Azure',
    imageUrl: `https://images.unsplash.com/photo-1600596542815-2a4d9fdb88d8?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'Private Venue',
    location: 'Carthage',
    rating: 4.9,
    verified: true,
    tags: ['Luxury', 'Pool']
  }
];

export const mockAgencies: BaseEntity[] = [
  {
    id: 'ag1',
    title: 'Pulse Management',
    imageUrl: `https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'Talent Agency',
    location: 'Tunis',
    rating: 4.8,
    verified: true,
    tags: ['Booking', 'PR']
  },
  {
    id: 'ag2',
    title: 'Vibe Events',
    imageUrl: `https://images.unsplash.com/photo-1556761175-5973dc0f32e7?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'Event Planner',
    location: 'Sousse',
    rating: 4.7,
    verified: true,
    tags: ['Weddings', 'Corporate']
  }
];

export const mockProviders: ProfessionalEntity[] = [
  {
    id: 'p1',
    title: 'SafeGuard Security',
    imageUrl: `https://images.unsplash.com/photo-1555952517-2e8e729e0b44?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'Security',
    profession: 'Event Security',
    location: 'National',
    rating: 4.9,
    verified: true,
    tags: ['VIP Protection', 'Crowd Control'],
    priceRange: '150 TND / Guard',
    responseTime: '1h',
    bio: 'Professional security teams for high-profile events and private gatherings.'
  },
  {
    id: 'p2',
    title: 'Gourmet Catering',
    imageUrl: `https://images.unsplash.com/photo-1555244162-803834f70033?q=80&w=${WIDTH_THUMB}&auto=format&fit=crop`,
    category: 'Catering',
    profession: 'Food & Beverage',
    location: 'Tunis',
    rating: 4.8,
    verified: true,
    tags: ['Buffet', 'Cocktail'],
    priceRange: '45 TND / Pax',
    responseTime: '48h'
  }
];

// Mock Booking Requests
export const mockBookings: BookingRequest[] = [
    {
        id: 'bk1',
        clientName: 'Sarah K.',
        eventName: 'Summer Sunset Festival',
        date: 'Aug 24, 2025',
        time: '20:00 - 22:00',
        location: 'Hammamet, Tunisia',
        price: '800 TND',
        status: 'pending',
        type: 'Performance',
        message: 'We love your style and want you for the closing set.'
    },
    {
        id: 'bk2',
        clientName: 'Pulse Productions',
        eventName: 'Corporate Gala',
        date: 'Sep 10, 2025',
        time: '18:00 - 23:00',
        location: 'Tunis',
        price: '1200 TND',
        status: 'confirmed',
        type: 'Sound Engineering'
    },
    {
        id: 'bk3',
        clientName: 'Karim B.',
        eventName: 'Private Wedding',
        date: 'Oct 05, 2025',
        time: '21:00 - 01:00',
        location: 'Gammarth',
        price: '2000 TND',
        status: 'declined',
        type: 'Performance'
    }
];

export const api = {
  getFeaturedEvents: async () => {
    await new Promise(r => setTimeout(r, 600));
    return mockEvents;
  },
  getAllEvents: async () => {
    await new Promise(r => setTimeout(r, 700));
    return mockEvents;
  },
  getEventDetails: async (id: string) => {
      await new Promise(r => setTimeout(r, 500));
      const base = mockEvents.find(e => e.id === id) || mockEvents[0];
      
      const extended: EventEntity = {
          ...base,
          organizer: {
              name: 'Pulse Productions',
              role: 'Verified Organizer',
              avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=200'
          },
          lineup: mockArtists.slice(0, 3),
          features: ['Free Parking', 'VIP Area', 'Outdoor Bar', 'Sound System: Void Acoustics'],
          media: [
              { type: 'image', url: 'https://images.unsplash.com/photo-1540039155733-5bb30b53aa14?q=80&w=1080&h=1080&fit=crop' },
              { type: 'image', url: 'https://images.unsplash.com/photo-1514525253361-bee8718a747c?q=80&w=1080&h=1080&fit=crop' }
          ],
          faqs: [
              { id: 1, q: "Is there parking?", a: "Yes, we have 200 slots available." },
              { id: 2, q: "Age restriction?", a: "18+ only with valid ID." }
          ],
          testimonials: [
              { id: 1, type: 'manual', name: 'Sami K.', rating: 5, quote: 'Best sound system in Tunis!', date: '2 days ago' }
          ],
          isIndoor: true
      };
      return extended;
  },
  getFeaturedArtists: async () => {
    await new Promise(r => setTimeout(r, 600));
    return mockArtists;
  },
  getArtistDetails: async (id: string) => {
      await new Promise(r => setTimeout(r, 500));
      const base = mockArtists.find(a => a.id === id) || mockArtists[0];
      return {
          ...base,
          media: [
              { type: 'image', url: base.imageUrl },
              { type: 'image', url: 'https://images.unsplash.com/photo-1516280440614-6697288d5d38?q=80&w=800' },
              { type: 'image', url: 'https://images.unsplash.com/photo-1493225255756-d9584f8606e9?q=80&w=800' }
          ],
          availability: ['Fridays', 'Saturdays'],
          socials: { instagram: '@artist_official', youtube: 'youtube.com/artist' }
      };
  },
  getFeaturedTechnicians: async () => {
    await new Promise(r => setTimeout(r, 500));
    return mockTechnicians;
  },
  getTechnicianDetails: async (id: string) => {
      await new Promise(r => setTimeout(r, 500));
      const base = mockTechnicians.find(t => t.id === id) || mockTechnicians[0];
      return {
          ...base,
          media: [
              { type: 'image', url: base.imageUrl },
              { type: 'image', url: 'https://images.unsplash.com/photo-1525201548942-d8732f6617a0?q=80&w=800' }
          ],
          availability: ['Weekdays', 'Weekends'],
      };
  },
  getFeaturedVenues: async () => {
    await new Promise(r => setTimeout(r, 600));
    return mockVenues;
  },
  getVenueDetails: async (id: string) => {
      await new Promise(r => setTimeout(r, 500));
      const base = mockVenues.find(v => v.id === id) || mockVenues[0];
      return {
          ...base,
          // Venue Specifics mocked
          capacity: 500,
          venueType: 'Lounge',
          venueServices: ['Sound', 'Light', 'Bar'],
          media: [
              { type: 'image', url: base.imageUrl },
              { type: 'image', url: 'https://images.unsplash.com/photo-1514362545857-3bc16549766b?q=80&w=800' }
          ],
          description: 'A premium venue located in the heart of the city, perfect for intimate gatherings and high-energy parties.'
      };
  },
  getFeaturedAgencies: async () => {
    await new Promise(r => setTimeout(r, 500));
    return mockAgencies;
  },
  getAgencyDetails: async (id: string) => {
      await new Promise(r => setTimeout(r, 500));
      const base = mockAgencies.find(a => a.id === id) || mockAgencies[0];
      return {
          ...base,
          agencyServices: ['Booking', 'Production', 'PR'],
          operatingZones: ['Tunis', 'Sousse'],
          media: [
              { type: 'image', url: base.imageUrl },
              { type: 'image', url: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=800' }
          ]
      };
  },
  getFeaturedServiceProviders: async () => {
    await new Promise(r => setTimeout(r, 500));
    return mockProviders;
  },
  getProviderDetails: async (id: string) => {
      await new Promise(r => setTimeout(r, 500));
      const base = mockProviders.find(p => p.id === id) || mockProviders[0];
      return {
          ...base,
          media: [
              { type: 'image', url: base.imageUrl },
              { type: 'image', url: 'https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?q=80&w=800' }
          ],
          availability: ['On Call', 'Scheduled'],
      };
  },
  getOpportunities: async () => {
    await new Promise(r => setTimeout(r, 800));
    return [
      { id: 'opp1', title: 'Wedding DJ Needed', clientName: 'Sarah K.', date: 'Aug 24', location: 'Hammamet', budget: '1500 TND', type: 'Private Event', requiredRoles: ['DJ'], description: 'Looking for a DJ who specializes in mixed weddings (Oriental & Pop).', deadline: '2 days', status: 'Open' },
      { id: 'opp2', title: 'Sound Engineer for Festival', clientName: 'Pulse Prod', date: 'Sep 10-12', location: 'Tunis', budget: '2000 TND', type: 'Festival', requiredRoles: ['Sound Tech'], description: 'Main stage engineer needed for 3 day electronic festival.', deadline: '1 week', status: 'Open' },
      { id: 'opp3', title: 'Video Team', clientName: 'Corp Event', date: 'Oct 05', location: 'Sousse', budget: '3000 TND', type: 'Corporate', requiredRoles: ['Videographer', 'Editor'], description: 'Full coverage of annual gala dinner + highlight reel.', deadline: '3 days', status: 'Open' },
    ] as OpportunityEntity[];
  },
  submitOpportunityOffer: async (id: string, offer: any) => {
    await new Promise(r => setTimeout(r, 1000));
    console.log(`Offer submitted for ${id}:`, offer);
    return true;
  },
  getContent: async () => {
    await new Promise(r => setTimeout(r, 600));
    return [
      { id: 'c1', title: 'Sunset Sessions Vol. 4', thumbnailUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=600&auto=format&fit=crop', duration: '1:20:00', views: '12k', category: 'Live Set', channel: 'MidMike Radio', date: '2 days ago' },
      { id: 'c2', title: 'Tech Talk: Stage Design', thumbnailUrl: 'https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?q=80&w=600&auto=format&fit=crop', duration: '15:42', views: '3.5k', category: 'Vlog', channel: 'Pro Tips', date: '1 week ago' },
      { id: 'c3', title: 'Underground Rhythms Ep. 1', thumbnailUrl: 'https://images.unsplash.com/photo-1598653222000-6b7b7a552625?q=80&w=600&auto=format&fit=crop', duration: '45:00', views: '8k', category: 'Podcast', channel: 'Deep Dive', date: '3 days ago' },
      { id: 'c4', title: 'Live from Carthage', thumbnailUrl: 'https://images.unsplash.com/photo-1459749411177-287ce35e8b95?q=80&w=600&auto=format&fit=crop', duration: 'Live', views: '1.2k Watching', category: 'Live Set', channel: 'MidMike Live', date: 'Now', isLive: true },
    ] as ContentItem[];
  },
  submitStudioBooking: async (data: any) => {
      await new Promise(r => setTimeout(r, 1500));
      console.log('Studio Booking:', data);
      return true;
  },
  getBookingRequests: async () => {
    await new Promise(r => setTimeout(r, 600));
    return mockBookings;
  },
  updateBookingStatus: async (id: string, status: BookingStatus) => {
    await new Promise(r => setTimeout(r, 400));
    // in a real app this would update backend
    return true;
  }
};
