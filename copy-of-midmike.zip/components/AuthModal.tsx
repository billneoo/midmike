
import React, { useState, useEffect } from 'react';
import { Modal } from './Modal';
import { useAuth } from '../contexts/AuthContext';
import { Role } from '../types';
import { 
  User as UserIcon, Music, Wrench, MapPin, Building2, 
  Briefcase, Mail, Lock, ArrowRight, CheckCircle2, 
  Phone, ArrowLeft, Ticket, Mic2, PlayCircle, Plus 
} from 'lucide-react';
import { ArtistOnboarding } from './ArtistOnboarding';
import { RoleOnboarding } from './RoleOnboarding';

const GoogleIcon = () => (
  <svg className="w-4 h-4" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
  </svg>
);

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, setAuthModalOpen, register, login, isAddingRole, user, updateProfile } = useAuth();
  const [isRegistering, setIsRegistering] = useState(false);
  const [selectedRole, setSelectedRole] = useState<Role>('Client'); // Default to Client
  const [step, setStep] = useState<1 | 2 | 3>(1); // 1: Info, 2: Role, 3: Interests (Client only)
  const [isLoadingGoogle, setIsLoadingGoogle] = useState(false);
  const [isGoogleAuth, setIsGoogleAuth] = useState(false); // Track if user is using Google Auth
  
  // Pro Onboarding State
  const [showArtistOnboarding, setShowArtistOnboarding] = useState(false);
  const [showRoleOnboarding, setShowRoleOnboarding] = useState(false);

  // Step 3: Interests State
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [otherInterestText, setOtherInterestText] = useState('');

  // Forgot Password State
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [resetSent, setResetSent] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Reset State on Open/Close
  useEffect(() => {
    if (isAuthModalOpen) {
        if (isAddingRole && user) {
            // "Add Role" Mode: Skip to step 2, prepopulate data
            setIsRegistering(true);
            setStep(2);
            setFormData({
                name: user.name,
                email: user.email,
                phone: user.phone,
                password: ''
            });
            setErrors({});
            setSelectedInterests([]);
            setOtherInterestText('');
            setShowArtistOnboarding(false);
            setShowRoleOnboarding(false);
        } else {
            // Normal Auth Mode
            setErrors({});
            setStep(1);
            setFormData({ name: '', email: '', password: '', phone: '' });
            setIsLoadingGoogle(false);
            setIsGoogleAuth(false);
            setIsForgotPassword(false);
            setResetSent(false);
            setIsResetting(false);
            setSelectedRole('Client');
            setSelectedInterests([]);
            setOtherInterestText('');
            setShowArtistOnboarding(false);
            setShowRoleOnboarding(false);
        }
    }
  }, [isAuthModalOpen, isAddingRole, user]);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.email) newErrors.email = 'Email required';
    
    if (isRegistering) {
      if (step === 1 && !isAddingRole) {
          if (!formData.name) newErrors.name = 'Full Name required';
          if (!isGoogleAuth && !formData.password) newErrors.password = 'Password required';
          if (!formData.phone && !isGoogleAuth) newErrors.phone = 'Phone number required';
      }
    } else {
       if (!formData.password) newErrors.password = 'Password required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNextStep = (e: React.FormEvent) => {
      e.preventDefault();
      if (validate()) {
          if (step === 1) {
              setStep(2);
              return;
          }
      }
  };

  const handleRegisterAction = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (step === 1) {
        if (validate()) setStep(2);
        return;
    }

    if (step === 2) {
        if (selectedRole === 'Client') {
            setStep(3);
        } else if (selectedRole === 'Artist') {
            setShowArtistOnboarding(true);
        } else if (['Technician', 'Venue', 'Agency', 'ServiceProvider'].includes(selectedRole)) {
            setShowRoleOnboarding(true);
        } else {
            finishRegistration();
        }
        return;
    }

    if (step === 3) {
        finishRegistration();
    }
  };

  const finishRegistration = (additionalData: any = {}) => {
      if (isAddingRole && user) {
          const newRoles = [...user.availableRoles];
          if (!newRoles.includes(selectedRole)) {
              newRoles.push(selectedRole);
          }
          
          updateProfile({
              availableRoles: newRoles,
              role: selectedRole,
              ...additionalData
          });
          setAuthModalOpen(false);
          return;
      }

      const userRoles: Role[] = ['Client'];
      if (selectedRole !== 'Client') {
          userRoles.push(selectedRole);
      }

      const payload = {
        id: Math.random().toString(36).substr(2, 9),
        name: formData.name,
        email: formData.email,
        phone: formData.phone || '', 
        role: selectedRole,
        availableRoles: userRoles, 
        avatarUrl: isGoogleAuth ? 'https://lh3.googleusercontent.com/a/default-user=s96-c' : undefined,
        interests: selectedInterests,
        otherInterest: otherInterestText,
        ...additionalData
      };
      register(payload);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!validate()) return;
      const payload = {
        id: 'mock-user-login',
        name: 'Demo User', 
        email: formData.email,
        phone: '+1234567890',
        role: 'Client' as Role,
        availableRoles: ['Client', 'Artist', 'Venue'] as Role[],
        avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=200&auto=format&fit=crop'
      };
      login(payload);
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.email) {
      setErrors({ email: 'Email is required to reset password' });
      return;
    }
    setIsResetting(true);
    setTimeout(() => {
      setIsResetting(false);
      setResetSent(true);
      setErrors({});
    }, 1500);
  };

  const handleGoogleAuth = () => {
    setIsLoadingGoogle(true);
    setTimeout(() => {
      setFormData(prev => ({
        ...prev,
        name: 'Google User',
        email: 'user@gmail.com',
      }));
      setIsGoogleAuth(true);
      setIsRegistering(true);
      setStep(2);
      setIsLoadingGoogle(false);
    }, 1200);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => {
        const next = { ...prev };
        delete next[name];
        return next;
      });
    }
  };

  const interestsOptions = [
      { id: 'live', label: 'Événements live', icon: Ticket },
      { id: 'booking', label: 'Booking d’artistes', icon: Mic2 },
      { id: 'content', label: 'Découverte de contenus', icon: PlayCircle },
      { id: 'other', label: 'Autres (champ libre)', icon: Plus },
  ];

  const toggleInterest = (id: string) => {
      if (selectedInterests.includes(id)) {
          setSelectedInterests(prev => prev.filter(i => i !== id));
      } else {
          setSelectedInterests(prev => [...prev, id]);
      }
  };

  const roles: { id: Role; label: string; icon: any; color: string }[] = [
    { id: 'Artist', label: 'Artist', icon: Music, color: 'text-mid-accent' },
    { id: 'Technician', label: 'Tech', icon: Wrench, color: 'text-mid-primary' },
    { id: 'Venue', label: 'Venue', icon: MapPin, color: 'text-mid-secondary' },
    { id: 'Agency', label: 'Agency', icon: Building2, color: 'text-mid-primary' },
    { id: 'ServiceProvider', label: 'Provider', icon: Briefcase, color: 'text-mid-accent' },
  ];

  const handleRoleSelect = (roleId: Role) => {
    if (isAddingRole && user?.availableRoles.includes(roleId)) return;
    setSelectedRole(roleId);
  };

  const getButtonText = () => {
      if (isRegistering) {
          if (step === 1) return 'Continue';
          if (step === 2) {
            if (isAddingRole && selectedRole !== 'Client') return `Create ${selectedRole} Profile`;
            return selectedRole === 'Client' ? 'Continue' : `Join as ${selectedRole}`;
          }
          if (step === 3) return 'Complete Sign Up';
      }
      return 'Grant Entry';
  };

  const getStepTitle = () => {
      if (isForgotPassword) return resetSent ? "Check Inbox" : "Reset Password";
      if (isAddingRole) return "Expand Your Identity";
      if (!isRegistering) return "Welcome Back";
      switch(step) {
          case 1: return "Create Account";
          case 2: return "Select Identity";
          case 3: return "Personnalisation";
          default: return "Create Account";
      }
  };

  const getStepSubtitle = () => {
      if (isForgotPassword) return resetSent ? `Recovery link sent to ${formData.email}` : "Secure account recovery";
      if (isAddingRole) return "Select a new professional role to add to your profile";
      if (!isRegistering) return "Return to the spotlight";
      switch(step) {
          case 1: return "Your digital footprint begins here";
          case 2: return "Define your role";
          case 3: return "Je suis intéressé par :";
          default: return "";
      }
  };

  // Main Render Content Logic
  const renderContent = () => {
    if (isForgotPassword) {
      return !resetSent ? (
        <form onSubmit={handleResetPassword} className="space-y-6">
             <div className="relative group">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle group-focus-within:text-mid-primary transition-colors" />
                <input 
                    name="email" 
                    type="email" 
                    value={formData.email} 
                    onChange={handleInputChange} 
                    className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-4 pl-12 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-white/20 focus:outline-none focus:bg-white dark:focus:bg-white/[0.08] focus:border-mid-primary/50 transition-all backdrop-blur-md" 
                    placeholder="Enter your registered email" 
                />
                {errors.email && <span className="absolute -bottom-5 left-4 text-[9px] text-red-400 font-bold uppercase tracking-wider">{errors.email}</span>}
             </div>

             <button 
                type="submit" 
                disabled={isResetting}
                className="w-full py-4 rounded-2xl bg-mid-primary hover:bg-mid-primary/90 text-white text-[11px] font-bold uppercase tracking-[0.3em] shadow-glow-blue transition-all duration-500 active:scale-[0.98] flex items-center justify-center gap-3 disabled:opacity-50"
              >
                {isResetting ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                    <>Send Recovery Link <ArrowRight className="w-4 h-4" /></>
                )}
              </button>
        </form>
      ) : (
        <div className="flex flex-col gap-6 animate-in fade-in slide-in-from-bottom-4">
            <div className="p-6 bg-mid-secondary/10 border border-mid-secondary/20 rounded-2xl flex items-center gap-4 text-mid-secondary">
                <CheckCircle2 className="w-6 h-6 flex-shrink-0" />
                <div>
                    <h4 className="text-sm font-bold">Email Sent Successfully</h4>
                    <p className="text-[10px] opacity-80 mt-1">Please check your email folder for password reset instructions.</p>
                </div>
            </div>
            <button 
                onClick={() => { setIsForgotPassword(false); setResetSent(false); }}
                className="w-full py-4 rounded-2xl bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white text-[11px] font-bold uppercase tracking-[0.3em] transition-all"
            >
                Return to Login
            </button>
        </div>
      );
    }

    return (
      <form onSubmit={isRegistering ? handleRegisterAction : handleLoginSubmit} className="space-y-6">
          {/* Step 1: Info Fields */}
          {isRegistering && step === 1 && !isAddingRole && (
          <div className="space-y-5 animate-cinematic-fade">
              <div className="relative group">
              <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle group-focus-within:text-mid-primary transition-colors" />
              <input name="name" type="text" value={formData.name} onChange={handleInputChange} className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-4 pl-12 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-white/20 focus:outline-none transition-all" placeholder="Full Name" />
              {errors.name && <span className="absolute -bottom-5 left-4 text-[9px] text-red-400 font-bold uppercase tracking-wider">{errors.name}</span>}
              </div>
              <div className="relative group">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle group-focus-within:text-mid-primary transition-colors" />
              <input name="email" type="email" value={formData.email} onChange={handleInputChange} className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-4 pl-12 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-white/20 focus:outline-none transition-all" placeholder="Email Address" />
              {errors.email && <span className="absolute -bottom-5 left-4 text-[9px] text-red-400 font-bold uppercase tracking-wider">{errors.email}</span>}
              </div>
              {!isGoogleAuth && (
                  <>
                      <div className="relative group">
                      <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle group-focus-within:text-mid-primary transition-colors" />
                      <input name="phone" type="tel" value={formData.phone} onChange={handleInputChange} className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-4 pl-12 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-white/20 focus:outline-none transition-all" placeholder="Phone Number" />
                      {errors.phone && <span className="absolute -bottom-5 left-4 text-[9px] text-red-400 font-bold uppercase tracking-wider">{errors.phone}</span>}
                      </div>
                      <div className="relative group">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle group-focus-within:text-mid-primary transition-colors" />
                      <input name="password" type="password" value={formData.password} onChange={handleInputChange} className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-4 pl-12 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-white/20 focus:outline-none transition-all" placeholder="Secure Password" />
                      {errors.password && <span className="absolute -bottom-5 left-4 text-[9px] text-red-400 font-bold uppercase tracking-wider">{errors.password}</span>}
                      </div>
                  </>
              )}
          </div>
          )}

           {/* Step 2: Role Selection */}
           {isRegistering && step === 2 && (
          <div className="space-y-4 animate-cinematic-fade">
              <div className="flex items-center justify-between px-1">
                <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-[0.25em]">
                  {isAddingRole ? 'Choose new identity' : (selectedRole === 'Client' ? 'Register as User' : `Joining as ${selectedRole}`)}
                </label>
              </div>
              <div className="grid grid-cols-3 gap-3">
              {roles.map(role => {
                  const isOwned = isAddingRole && user?.availableRoles.includes(role.id);
                  return (
                  <button key={role.id} type="button" onClick={() => handleRoleSelect(role.id)} disabled={isOwned} className={`flex flex-col items-center justify-center py-5 rounded-2xl border transition-all duration-500 relative group/role ${selectedRole === role.id && !isOwned ? 'bg-mid-primary/10 border-mid-primary shadow-glow-blue scale-[1.02] text-slate-900 dark:text-white' : isOwned ? 'bg-slate-100 dark:bg-white/5 border-transparent opacity-50 cursor-not-allowed grayscale' : 'bg-slate-50 dark:bg-white/[0.02] border-slate-200 dark:border-white/5 text-slate-500 dark:text-mid-text-subtle hover:border-slate-300 dark:hover:border-white/20 hover:bg-slate-100 dark:hover:bg-white/[0.05]'}`}>
                  <role.icon className={`w-5 h-5 mb-2 transition-transform duration-500 group-hover/role:scale-110 ${selectedRole === role.id ? 'text-mid-primary dark:text-white' : role.color}`} strokeWidth={1.5} />
                  <span className={`text-[9px] font-bold uppercase tracking-[0.1em] ${selectedRole === role.id ? 'text-slate-900 dark:text-white' : 'text-slate-500 dark:text-mid-text-subtle'}`}>{role.label}</span>
                  {selectedRole === role.id && !isOwned && (<div className="absolute top-2 right-2"><CheckCircle2 className="w-3.5 h-3.5 text-mid-primary" /></div>)}
                  {isOwned && (<div className="absolute top-2 right-2"><span className="text-[7px] font-bold uppercase tracking-wider bg-slate-200 dark:bg-white/10 px-1.5 py-0.5 rounded text-slate-600 dark:text-white">Active</span></div>)}
                  </button>
              )})}
              </div>
              {selectedRole !== 'Client' && !isAddingRole && (
                  <button type="button" onClick={() => setSelectedRole('Client')} className="w-full py-2 text-[9px] text-slate-500 dark:text-mid-text-subtle hover:text-slate-900 dark:hover:text-white uppercase tracking-widest transition-colors">Or Continue as Standard User</button>
              )}
          </div>
          )}

          {/* Step 3: Interests */}
          {isRegistering && step === 3 && (
              <div className="space-y-6 animate-cinematic-fade">
                  <div className="grid grid-cols-2 gap-3">
                      {interestsOptions.map((item) => {
                          const isSelected = selectedInterests.includes(item.id);
                          return (
                              <button key={item.id} type="button" onClick={() => toggleInterest(item.id)} className={`flex flex-col items-center justify-center p-4 rounded-2xl border transition-all duration-300 relative text-center ${isSelected ? 'bg-mid-secondary/10 border-mid-secondary shadow-glow-secondary text-slate-900 dark:text-white' : 'bg-slate-50 dark:bg-white/[0.02] border-slate-200 dark:border-white/5 text-slate-500 dark:text-mid-text-subtle hover:border-slate-300 dark:hover:border-white/20 hover:bg-slate-100 dark:hover:bg-white/[0.05]'}`}>
                                  <item.icon className={`w-6 h-6 mb-3 transition-colors duration-300 ${isSelected ? 'text-mid-secondary' : 'text-slate-400 dark:text-mid-text-subtle'}`} />
                                  <span className={`text-[10px] font-bold uppercase tracking-wider leading-relaxed ${isSelected ? 'text-slate-900 dark:text-white' : 'text-slate-500 dark:text-mid-text-subtle'}`}>{item.label}</span>
                                  {isSelected && (<div className="absolute top-2 right-2"><CheckCircle2 className="w-3.5 h-3.5 text-mid-secondary" /></div>)}
                              </button>
                          );
                      })}
                  </div>
                  {selectedInterests.includes('other') && (
                      <div className="animate-in fade-in slide-in-from-top-2">
                          <label className="block text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-[0.2em] mb-2">Précisez votre intérêt</label>
                          <input type="text" value={otherInterestText} onChange={(e) => setOtherInterestText(e.target.value)} className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-4 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-white/20 focus:outline-none transition-all" placeholder="Ex: Art numérique..." />
                      </div>
                  )}
              </div>
          )}

          {/* Login Fields */}
          {!isRegistering && (
              <div className="space-y-5 animate-cinematic-fade">
                  <div className="relative group">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle group-focus-within:text-mid-primary transition-colors" />
                      <input name="email" type="email" value={formData.email} onChange={handleInputChange} className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-4 pl-12 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-white/20 focus:outline-none transition-all" placeholder="Email Address" />
                      {errors.email && <span className="absolute -bottom-5 left-4 text-[9px] text-red-400 font-bold uppercase tracking-wider">{errors.email}</span>}
                  </div>
                  <div className="relative group">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle group-focus-within:text-mid-primary transition-colors" />
                      <input name="password" type="password" value={formData.password} onChange={handleInputChange} className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-4 pl-12 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-white/20 focus:outline-none transition-all" placeholder="Password" />
                      {errors.password && <span className="absolute -bottom-5 left-4 text-[9px] text-red-400 font-bold uppercase tracking-wider">{errors.password}</span>}
                  </div>
                  <div className="flex justify-end pt-1">
                      <button type="button" onClick={() => { setIsForgotPassword(true); setErrors({}); }} className="text-[10px] font-bold text-slate-500 dark:text-mid-text-subtle hover:text-slate-900 dark:hover:text-white transition-colors uppercase tracking-wider">Forgot Password?</button>
                  </div>
              </div>
          )}

          <div className="pt-6 space-y-4">
            <button type="submit" className="w-full py-4 rounded-2xl bg-mid-primary hover:bg-mid-primary/90 text-white text-[11px] font-bold uppercase tracking-[0.3em] shadow-glow-blue transition-all duration-500 active:scale-[0.98] flex items-center justify-center gap-3 group/btn overflow-hidden relative">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover/btn:translate-x-full transition-transform duration-1000" />
                {getButtonText()}
                <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
            </button>

            {(!isRegistering || step === 1) && !isAddingRole && (
                <>
                  <div className="flex items-center gap-4 px-2">
                      <div className="flex-1 h-[1px] bg-slate-200 dark:bg-white/10"></div>
                      <span className="text-[9px] text-slate-400 dark:text-mid-text-subtle uppercase tracking-widest font-bold">Or continue with</span>
                      <div className="flex-1 h-[1px] bg-slate-200 dark:bg-white/10"></div>
                  </div>
                  <button type="button" onClick={handleGoogleAuth} disabled={isLoadingGoogle} className="w-full py-4 rounded-2xl bg-white border border-slate-200 text-slate-900 hover:bg-slate-50 text-[11px] font-bold uppercase tracking-[0.2em] transition-all duration-300 flex items-center justify-center gap-3 active:scale-[0.98] disabled:opacity-70 disabled:cursor-wait">
                      {isLoadingGoogle ? (<div className="w-4 h-4 border-2 border-slate-300 border-t-slate-600 rounded-full animate-spin" />) : (<GoogleIcon />)}
                      <span>{isLoadingGoogle ? 'Connecting...' : 'Google Account'}</span>
                  </button>
              </>
            )}

            {isRegistering && !isAddingRole && (
              <p className="text-[10px] text-center text-slate-400 dark:text-mid-text-subtle/60 leading-relaxed px-4 pt-1">
                 By signing up, I accept the Terms of Service and <a href="#" className="underline decoration-slate-300 dark:decoration-white/20 hover:text-slate-900 dark:hover:text-white transition-colors">Privacy Policy*</a>.
              </p>
            )}
          </div>

          {!isAddingRole && (
              <div className="text-center pt-4">
              <button type="button" onClick={() => { setIsRegistering(!isRegistering); setErrors({}); setStep(1); setSelectedRole('Client'); setFormData({ name: '', email: '', password: '', phone: '' }); setIsGoogleAuth(false); setSelectedInterests([]); setShowArtistOnboarding(false); setShowRoleOnboarding(false); }} className="text-[10px] text-slate-500 dark:text-mid-text-subtle hover:text-slate-900 dark:hover:text-white uppercase tracking-[0.25em] font-bold transition-all hover:tracking-[0.3em] underline underline-offset-4 decoration-slate-200 dark:decoration-white/10">
                  {isRegistering ? 'Already Registered? Sign In' : "No Identity? Register Now"}
              </button>
              </div>
          )}
      </form>
    );
  };

  return (
    <Modal 
      isOpen={isAuthModalOpen} 
      onClose={() => setAuthModalOpen(false)} 
      title=""
      fullScreen={true}
      floatingClose={true}
    >
      {showArtistOnboarding ? (
          <ArtistOnboarding 
            onBack={() => setShowArtistOnboarding(false)} 
            onComplete={finishRegistration}
            initialData={{
                name: formData.name,
                email: formData.email,
                phone: formData.phone
            }}
          />
      ) : showRoleOnboarding ? (
          <RoleOnboarding 
            role={selectedRole}
            onBack={() => setShowRoleOnboarding(false)} 
            onComplete={finishRegistration}
            initialData={{
                name: formData.name,
                email: formData.email,
                phone: formData.phone
            }}
          />
      ) : (
      <div className="animate-cinematic-fade min-h-full flex flex-col items-center justify-center p-8 md:p-12 relative overflow-hidden bg-transparent">
        <div className="absolute top-1/4 left-1/4 w-[50vw] h-[50vw] bg-mid-primary/[0.03] blur-[150px] rounded-full pointer-events-none -z-10 animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-[40vw] h-[40vw] bg-mid-accent/[0.02] blur-[150px] rounded-full pointer-events-none -z-10" />

        <div className="w-full max-w-md relative z-10">
          {((isRegistering && step > 1) || isForgotPassword) && (
            <button 
              onClick={() => {
                if (isForgotPassword) {
                    setIsForgotPassword(false);
                    setResetSent(false);
                    setErrors({});
                } else if (isAddingRole) {
                    setAuthModalOpen(false);
                } else {
                    setStep(prev => (prev - 1) as 1 | 2);
                    if (step === 2 && isGoogleAuth) {
                        setIsGoogleAuth(false);
                        setFormData(prev => ({ ...prev, password: '' })); 
                        setStep(1);
                    }
                }
              }}
              className="absolute -top-12 left-0 group flex items-center gap-3 px-6 py-2.5 rounded-[10px] border border-black/5 dark:border-white/10 bg-white/20 dark:bg-black/20 backdrop-blur-md hover:border-mid-primary/50 hover:bg-mid-primary/5 transition-all duration-500 shadow-sm"
            >
              <ArrowLeft className="w-4 h-4 text-slate-600 dark:text-slate-300 group-hover:text-mid-primary group-hover:-translate-x-1 transition-all" />
              <span className="text-[10px] font-bold uppercase tracking-widest text-slate-600 dark:text-slate-300 group-hover:text-mid-primary transition-colors">{isAddingRole ? 'Cancel' : 'Back'}</span>
            </button>
          )}

          <header className="text-center mb-10">
            <h2 className="text-4xl md:text-5xl font-tiempos font-normal text-slate-900 dark:text-white tracking-tight mb-3 text-glow-none dark:text-glow">
              {getStepTitle()}
            </h2>
            <p className="text-slate-500 dark:text-mid-text-muted text-[10px] font-inter uppercase tracking-[0.4em] opacity-80">
              {getStepSubtitle()}
            </p>
          </header>

          {renderContent()}
        </div>
      </div>
      )}
    </Modal>
  );
};
