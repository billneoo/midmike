import React from 'react';
import { SlidersHorizontal } from 'lucide-react';

interface FilterOption {
    id: string;
    label: string;
    isActive?: boolean;
}

const CATEGORIES: FilterOption[] = [
    { id: 'all', label: 'All', isActive: true },
    { id: 'music', label: 'Music Festivals' },
    { id: 'techno', label: 'Techno' },
    { id: 'house', label: 'House' },
    { id: 'live', label: 'Live Bands' },
    { id: 'av', label: 'A/V Performance' },
    { id: 'rooftop', label: 'Rooftop' },
    { id: 'underground', label: 'Underground' },
];

export const FilterBar: React.FC = () => {
    return (
        <div className="w-full flex items-center gap-6 mb-12 pl-2">
            <button className="h-12 w-12 flex items-center justify-center rounded-[20px] bg-mid-surface/40 border border-white/10 text-mid-text-muted hover:text-white hover:border-mid-primary/50 transition-all flex-shrink-0 backdrop-blur-xl">
                <SlidersHorizontal className="w-5 h-5" />
            </button>
            
            <div className="flex-1 overflow-x-auto custom-scrollbar pb-4 -mb-4">
                <div className="flex items-center gap-4">
                    {CATEGORIES.map((cat) => (
                        <button
                            key={cat.id}
                            className={`
                                whitespace-nowrap px-8 py-3.5 rounded-full text-xs font-bold tracking-widest border transition-all duration-500 uppercase
                                ${cat.isActive 
                                    ? 'bg-mid-primary border-transparent text-white shadow-glow-blue scale-105' 
                                    : 'bg-mid-surface/20 border-white/5 text-mid-text-muted hover:border-white/20 hover:text-white hover:bg-mid-surface/60 backdrop-blur-md'
                                }
                            `}
                        >
                            {cat.label}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};