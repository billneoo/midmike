
import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { Card } from './Card';
import { Search, Music, Wrench, MapPin, Briefcase, Truck, Check, X } from 'lucide-react';
import { useBasket } from '../contexts/BasketContext';
import { BaseEntity, ProfessionalEntity } from '../types';

interface TalentBrowserModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type Tab = 'artists' | 'technicians' | 'venues' | 'agencies' | 'services';

export const TalentBrowserModal: React.FC<TalentBrowserModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<Tab>('artists');
  const [items, setItems] = useState<BaseEntity[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const { addToBasket, items: basketItems } = useBasket();

  // Lock body scroll when open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      loadData(activeTab);
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => { document.body.style.overflow = 'unset'; };
  }, [isOpen]);

  // Load data when tab changes
  useEffect(() => {
    if (isOpen) {
      loadData(activeTab);
    }
  }, [activeTab]);

  const loadData = async (type: Tab) => {
    setLoading(true);
    try {
      let data: BaseEntity[] = [];
      switch (type) {
        case 'artists':
          data = await api.getFeaturedArtists();
          break;
        case 'technicians':
          data = await api.getFeaturedTechnicians();
          break;
        case 'venues':
          data = await api.getFeaturedVenues();
          break;
        case 'agencies':
          data = await api.getFeaturedAgencies();
          break;
        case 'services':
          data = await api.getFeaturedServiceProviders();
          break;
      }
      setItems(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const filteredItems = items.filter(item => {
    const s = search.toLowerCase();
    const matchesTitle = item.title.toLowerCase().includes(s);
    const matchesCat = item.category?.toLowerCase().includes(s);
    const matchesProf = (item as ProfessionalEntity).profession?.toLowerCase().includes(s);
    const matchesLoc = item.location?.toLowerCase().includes(s);
    return matchesTitle || matchesCat || matchesProf || matchesLoc;
  });

  const isInBasket = (id: string) => basketItems.some(i => i.id === id);

  const TABS = [
      { id: 'artists', label: 'Artists', icon: Music },
      { id: 'technicians', label: 'Techs', icon: Wrench },
      { id: 'venues', label: 'Venues', icon: MapPin },
      { id: 'agencies', label: 'Agencies', icon: Briefcase },
      { id: 'services', label: 'Services', icon: Truck },
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed top-20 left-0 right-0 bottom-0 z-[120] bg-[#F2F4F7] dark:bg-[#0D0D0D] flex flex-col shadow-[0_-10px_40px_rgba(0,0,0,0.1)] animate-in slide-in-from-bottom-4 duration-300 border-t border-slate-200 dark:border-white/5">
      
      {/* Header Controls */}
      <div className="flex-none px-4 md:px-8 py-4 bg-white dark:bg-[#151515] border-b border-slate-200 dark:border-white/5 z-30 shadow-sm relative">
        <div className="max-w-6xl mx-auto flex flex-col lg:flex-row gap-4 lg:items-center justify-between">
          
          {/* Tabs - Horizontal Scroll on Mobile */}
          <div className="w-full lg:w-auto overflow-x-auto no-scrollbar -mx-4 px-4 lg:mx-0 lg:px-0">
              <div className="flex bg-slate-100 dark:bg-white/5 p-1 rounded-xl min-w-max">
                  {TABS.map(tab => (
                      <button 
                          key={tab.id}
                          onClick={() => setActiveTab(tab.id as Tab)}
                          className={`
                              px-4 md:px-6 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all whitespace-nowrap
                              ${activeTab === tab.id 
                                  ? 'bg-white dark:bg-white/10 text-slate-900 dark:text-white shadow-sm' 
                                  : 'text-slate-500 hover:text-slate-700 dark:hover:text-white'}
                          `}
                      >
                          <tab.icon className="w-4 h-4" /> {tab.label}
                      </button>
                  ))}
              </div>
          </div>

          {/* Search */}
          <div className="relative w-full lg:w-80">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={`Search ${activeTab}...`}
              className="w-full bg-slate-100 dark:bg-white/5 border border-transparent focus:border-mid-primary/50 rounded-2xl py-3 pl-11 pr-4 text-sm focus:outline-none transition-all"
            />
          </div>
        </div>

        {/* Mobile Close Button (Floating) */}
        <button 
            onClick={onClose}
            className="lg:hidden absolute top-4 right-4 p-2 bg-slate-100 dark:bg-white/10 rounded-full text-slate-500 dark:text-white"
        >
            <X className="w-5 h-5" />
        </button>
      </div>

      {/* Content Grid */}
      <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar">
        <div className="max-w-6xl mx-auto">
          {loading ? (
            <div className="flex justify-center py-20">
              <div className="w-10 h-10 border-2 border-mid-primary border-t-transparent rounded-full animate-spin" />
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pb-20">
              {filteredItems.map(item => {
                  // Dynamic subtitle based on type
                  let subtitle = (item as ProfessionalEntity).profession;
                  if (activeTab === 'venues' || activeTab === 'agencies') {
                      subtitle = item.location;
                  }
                  
                  return (
                      <div key={item.id} className="relative group">
                          <Card 
                              variant="portrait-action"
                              image={item.imageUrl}
                              title={item.title}
                              subtitle={subtitle}
                              badge={item.category}
                              rating={item.rating}
                              verified={item.verified}
                              imageAspectRatio={activeTab === 'venues' ? '16/9' : 'square'}
                              actionLabel={isInBasket(item.id) ? "Added" : "Select"}
                              onClick={() => !isInBasket(item.id) && addToBasket(item)}
                          />
                          {isInBasket(item.id) && (
                              <div className="absolute inset-0 bg-mid-primary/20 backdrop-blur-[2px] rounded-[16px] border-2 border-mid-primary z-20 flex items-center justify-center pointer-events-none animate-in fade-in zoom-in duration-200">
                                  <div className="bg-mid-primary text-white px-4 py-2 rounded-full text-xs font-bold uppercase tracking-widest shadow-lg flex items-center gap-2">
                                      <Check className="w-4 h-4" /> Selected
                                  </div>
                              </div>
                          )}
                      </div>
                  );
              })}
              {filteredItems.length === 0 && (
                  <div className="col-span-full py-20 text-center opacity-50">
                      <p>No results found for "{search}" in {activeTab}.</p>
                  </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="flex-none p-4 md:p-6 bg-white dark:bg-[#151515] border-t border-slate-200 dark:border-white/5 flex justify-between items-center z-30">
          <div className="text-xs font-bold text-slate-500 dark:text-mid-text-subtle">
            <span className="text-mid-primary font-black text-sm mr-1">{basketItems.length}</span> items selected
          </div>
          <div className="flex gap-3">
              <button 
                onClick={onClose}
                className="px-6 py-3 border border-slate-200 dark:border-white/10 text-slate-600 dark:text-white rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-slate-50 dark:hover:bg-white/5 transition-all"
              >
                Close
              </button>
              <button 
                onClick={onClose}
                className="px-8 py-3 bg-mid-primary hover:bg-mid-primary/90 text-white rounded-xl text-xs font-bold uppercase tracking-widest shadow-glow-blue transition-all"
              >
                Confirm
              </button>
          </div>
      </div>
    </div>
  );
};
