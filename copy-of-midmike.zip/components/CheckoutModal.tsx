
import React, { useState } from 'react';
import { Modal } from './Modal';
import { useBasket } from '../contexts/BasketContext';
import { 
  CreditCard, CheckCircle, Wallet, ArrowRight, 
  Calendar, ShieldCheck, Info, Sparkles, Receipt 
} from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({ isOpen, onClose }) => {
  const { items, clearBasket } = useBasket();
  const [step, setStep] = useState<1 | 2>(1); // 1: Review, 2: Success
  const [method, setMethod] = useState<'escrow' | 'direct'>('escrow');
  const [note, setNote] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  // Simple math for demo
  const subtotal = items.reduce((acc, item) => {
      // Mock parsing price string "300 TND" -> 300. Fallback 150.
      const priceStr = String(item.price || '150');
      const val = parseInt(priceStr.replace(/[^0-9]/g, '')) || 150;
      return acc + val;
  }, 0);
  
  const fee = Math.round(subtotal * 0.05);
  const total = subtotal + fee;

  const handleConfirm = () => {
    setIsProcessing(true);
    setTimeout(() => {
        setIsProcessing(false);
        setStep(2);
        clearBasket();
    }, 2000);
  };

  const handleClose = () => {
      setStep(1);
      onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title={step === 1 ? "Finalize Proposal" : ""}>
        {step === 1 ? (
            <div className="p-6 md:p-8 space-y-8 animate-cinematic-fade">
                {/* 1. Item Review */}
                <div className="space-y-4">
                    <h3 className="text-xs font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Order Summary</h3>
                    <div className="bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-2xl p-4 space-y-3 max-h-48 overflow-y-auto custom-scrollbar">
                        {items.map((item, i) => (
                            <div key={i} className="flex justify-between items-center text-sm">
                                <div className="flex items-center gap-3">
                                    <div className="w-8 h-8 rounded-lg bg-slate-200 dark:bg-white/10 overflow-hidden">
                                        <img src={item.imageUrl} className="w-full h-full object-cover" alt="" />
                                    </div>
                                    <div>
                                        <span className="block font-bold text-slate-900 dark:text-white truncate max-w-[150px]">{item.title}</span>
                                        <span className="block text-[10px] text-slate-500 dark:text-mid-text-subtle uppercase">{item.category}</span>
                                    </div>
                                </div>
                                <span className="font-mono text-slate-700 dark:text-slate-300">
                                    {item.price ? item.price : '150 TND'}
                                </span>
                            </div>
                        ))}
                        {items.length === 0 && (
                            <p className="text-center text-sm text-slate-400 italic py-4">Your basket is empty.</p>
                        )}
                    </div>
                </div>

                {/* 2. Project Brief */}
                <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Project Note (Brief)</label>
                    <textarea 
                        value={note}
                        onChange={(e) => setNote(e.target.value)}
                        placeholder="Describe your event needs (e.g. equipment needed, schedule...)"
                        className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl p-4 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-mid-primary h-24 resize-none"
                    />
                </div>

                {/* 3. Payment Method */}
                <div className="space-y-4">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Payment Method</label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <button 
                            onClick={() => setMethod('escrow')}
                            className={`p-4 rounded-xl border text-left transition-all relative overflow-hidden group ${method === 'escrow' ? 'bg-mid-primary/10 border-mid-primary' : 'bg-slate-50 dark:bg-white/5 border-slate-200 dark:border-white/10'}`}
                        >
                            <div className="flex items-center justify-between mb-2">
                                <ShieldCheck className={`w-5 h-5 ${method === 'escrow' ? 'text-mid-primary' : 'text-slate-400'}`} />
                                {method === 'escrow' && <div className="w-2 h-2 bg-mid-primary rounded-full shadow-glow-blue" />}
                            </div>
                            <h4 className={`text-sm font-bold ${method === 'escrow' ? 'text-mid-primary' : 'text-slate-700 dark:text-white'}`}>MidMike Escrow</h4>
                            <p className="text-[10px] text-slate-500 dark:text-mid-text-subtle mt-1">Funds held securely until event completion.</p>
                        </button>

                        <button 
                            onClick={() => setMethod('direct')}
                            className={`p-4 rounded-xl border text-left transition-all relative overflow-hidden group ${method === 'direct' ? 'bg-mid-accent/10 border-mid-accent' : 'bg-slate-50 dark:bg-white/5 border-slate-200 dark:border-white/10'}`}
                        >
                            <div className="flex items-center justify-between mb-2">
                                <Wallet className={`w-5 h-5 ${method === 'direct' ? 'text-mid-accent' : 'text-slate-400'}`} />
                                {method === 'direct' && <div className="w-2 h-2 bg-mid-accent rounded-full shadow-glow-accent" />}
                            </div>
                            <h4 className={`text-sm font-bold ${method === 'direct' ? 'text-mid-accent' : 'text-slate-700 dark:text-white'}`}>Direct Transfer</h4>
                            <p className="text-[10px] text-slate-500 dark:text-mid-text-subtle mt-1">Pay 50% deposit now directly to talent.</p>
                        </button>
                    </div>
                </div>

                {/* 4. Totals & Action */}
                <div className="pt-6 border-t border-slate-200 dark:border-white/10 space-y-6">
                    <div className="flex flex-col gap-2">
                        <div className="flex justify-between text-xs text-slate-500 dark:text-mid-text-subtle">
                            <span>Subtotal</span>
                            <span>{subtotal} TND</span>
                        </div>
                        <div className="flex justify-between text-xs text-slate-500 dark:text-mid-text-subtle">
                            <span>Service Fee (5%)</span>
                            <span>{fee} TND</span>
                        </div>
                        <div className="flex justify-between text-lg font-tiempos font-bold text-slate-900 dark:text-white pt-2 border-t border-dashed border-slate-200 dark:border-white/10 mt-2">
                            <span>Total Estimate</span>
                            <span>{total} TND</span>
                        </div>
                    </div>

                    <button 
                        onClick={handleConfirm}
                        disabled={items.length === 0 || isProcessing}
                        className="w-full py-4 rounded-2xl bg-mid-primary hover:bg-mid-primary/90 text-white font-bold text-xs uppercase tracking-[0.2em] shadow-glow-blue transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
                    >
                        {isProcessing ? 'Processing Request...' : 'Confirm Proposal'} 
                        {!isProcessing && <ArrowRight className="w-4 h-4" />}
                    </button>
                </div>
            </div>
        ) : (
            <div className="p-8 md:p-12 flex flex-col items-center justify-center text-center space-y-8 animate-in zoom-in duration-500">
                <div className="w-24 h-24 rounded-full bg-green-500/10 border border-green-500/20 flex items-center justify-center shadow-[0_0_40px_rgba(34,197,94,0.3)]">
                    <Sparkles className="w-10 h-10 text-green-500" />
                </div>
                <div className="space-y-2">
                    <h2 className="text-3xl md:text-4xl font-tiempos font-bold text-slate-900 dark:text-white">Proposal Sent!</h2>
                    <p className="text-sm text-slate-500 dark:text-mid-text-subtle max-w-xs mx-auto leading-relaxed">
                        Your request has been dispatched to the selected professionals. You will receive notifications once they accept.
                    </p>
                </div>
                <div className="flex flex-col gap-3 w-full">
                    <button onClick={handleClose} className="w-full py-3.5 bg-slate-900 dark:bg-white text-white dark:text-black rounded-xl text-[10px] font-bold uppercase tracking-widest hover:scale-[1.02] transition-transform">
                        Return to Discovery
                    </button>
                    <button className="w-full py-3.5 border border-slate-200 dark:border-white/10 rounded-xl text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle hover:bg-slate-50 dark:hover:bg-white/5 transition-colors flex items-center justify-center gap-2">
                        <Receipt className="w-4 h-4" /> Download Receipt
                    </button>
                </div>
            </div>
        )}
    </Modal>
  );
};
