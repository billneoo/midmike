
import React, { useEffect, useState, useRef } from 'react';
import { useTour } from '../contexts/TourContext';
import { X, ArrowRight, ArrowLeft } from 'lucide-react';

export const SpotlightTour: React.FC = () => {
  const { isTourActive, currentStepIndex, steps, nextStep, prevStep, endTour } = useTour();
  const [targetRect, setTargetRect] = useState<DOMRect | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  
  const currentStep = steps[currentStepIndex];

  useEffect(() => {
    if (!isTourActive) {
      setIsVisible(false);
      return;
    }

    const updatePosition = () => {
      const element = document.getElementById(currentStep.targetId);
      if (element) {
        const rect = element.getBoundingClientRect();
        // Add some padding
        const padding = 8;
        setTargetRect(new DOMRect(
            rect.x - padding, 
            rect.y - padding, 
            rect.width + (padding * 2), 
            rect.height + (padding * 2)
        ));
        setIsVisible(true);
      } else {
        // If element not found (e.g. mobile hidden), maybe skip or wait?
        console.warn(`Tour target #${currentStep.targetId} not found`);
      }
    };

    // Initial positioning
    updatePosition();
    
    // Update on resize/scroll
    window.addEventListener('resize', updatePosition);
    window.addEventListener('scroll', updatePosition, true);

    // Slight delay to allow UI to settle if opening menus
    const timer = setTimeout(updatePosition, 100);

    return () => {
      window.removeEventListener('resize', updatePosition);
      window.removeEventListener('scroll', updatePosition, true);
      clearTimeout(timer);
    };
  }, [isTourActive, currentStepIndex, currentStep]);

  if (!isTourActive || !targetRect) return null;

  // Calculate Tooltip Position
  const getTooltipStyle = () => {
    const gap = 20;
    const tooltipWidth = 320; // Approx max width
    
    let top = 0;
    let left = 0;

    // Basic logic - can be improved with collision detection
    if (currentStep.position === 'right') {
        top = targetRect.top;
        left = targetRect.right + gap;
    } else if (currentStep.position === 'bottom') {
        top = targetRect.bottom + gap;
        // Center horizontally relative to target, but keep within viewport
        left = targetRect.left + (targetRect.width / 2) - (tooltipWidth / 2);
    } else if (currentStep.position === 'left') {
        top = targetRect.top;
        left = targetRect.left - tooltipWidth - gap;
    }

    // Boundary checks (very basic)
    if (left < 10) left = 10;
    if (left + tooltipWidth > window.innerWidth - 10) left = window.innerWidth - tooltipWidth - 10;
    if (top < 10) top = 10;
    
    return { top, left };
  };

  const { top: tooltipTop, left: tooltipLeft } = getTooltipStyle();

  return (
    <div className={`fixed inset-0 z-[200] transition-opacity duration-500 ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
        
        {/* 
            The Spotlight Effect using box-shadow on a dummy element.
            This creates a huge shadow around the "hole". 
        */}
        <div 
            className="absolute transition-all duration-500 ease-[cubic-bezier(0.25,1,0.5,1)] pointer-events-none"
            style={{
                top: targetRect.top,
                left: targetRect.left,
                width: targetRect.width,
                height: targetRect.height,
                borderRadius: '12px',
                boxShadow: '0 0 0 9999px rgba(0, 0, 0, 0.85), 0 0 0 4px rgba(23, 84, 216, 0.6)' // Dark overlay + Blue glow ring
            }}
        />

        {/* The Tooltip Card */}
        <div 
            className="absolute transition-all duration-500 ease-out flex flex-col gap-4 p-6 bg-white dark:bg-[#191919] border border-white/10 rounded-2xl shadow-2xl max-w-[320px] backdrop-blur-xl"
            style={{
                top: tooltipTop,
                left: tooltipLeft,
            }}
        >
            <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-bold uppercase tracking-widest text-mid-primary">Step {currentStepIndex + 1} of {steps.length}</span>
                <button onClick={endTour} className="text-slate-400 hover:text-white transition-colors">
                    <X className="w-4 h-4" />
                </button>
            </div>
            
            <div>
                <h3 className="text-lg font-tiempos font-semibold text-slate-900 dark:text-white mb-2">{currentStep.title}</h3>
                <p className="text-sm text-slate-500 dark:text-mid-text-muted leading-relaxed">
                    {currentStep.content}
                </p>
            </div>

            <div className="flex items-center justify-between pt-2">
                <div className="flex gap-2">
                    <div className="flex gap-1">
                        {steps.map((_, i) => (
                            <div key={i} className={`w-1.5 h-1.5 rounded-full transition-colors ${i === currentStepIndex ? 'bg-mid-primary' : 'bg-slate-200 dark:bg-white/10'}`} />
                        ))}
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    {currentStepIndex > 0 && (
                        <button 
                            onClick={prevStep}
                            className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/5 text-slate-500 dark:text-white transition-colors"
                        >
                            <ArrowLeft className="w-4 h-4" />
                        </button>
                    )}
                    <button 
                        onClick={nextStep}
                        className="flex items-center gap-2 px-4 py-2 rounded-lg bg-mid-primary text-white text-xs font-bold uppercase tracking-wider hover:bg-mid-primary/90 transition-all shadow-glow-blue"
                    >
                        {currentStepIndex === steps.length - 1 ? 'Finish' : 'Next'}
                        {currentStepIndex < steps.length - 1 && <ArrowRight className="w-3.5 h-3.5" />}
                    </button>
                </div>
            </div>
        </div>

    </div>
  );
};
