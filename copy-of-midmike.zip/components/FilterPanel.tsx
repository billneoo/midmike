import React, { useState, useEffect, useRef } from 'react';
import { 
  X, Check, RotateCcw, Star, Music, Mic, 
  Users, Briefcase, Camera, 
  Speaker, Shield, Truck, Zap, SlidersHorizontal,
  ChevronDown, Calendar, Tent, Heart, Rocket, Sparkles
} from 'lucide-react';

export type FilterType = 'artist' | 'venue' | 'technician' | 'agency' | 'provider' | 'event';

export interface FilterState {
  categories: string[];
  tags: string[];
  rating: number | null;
  verifiedOnly: boolean;
  location: string | null;
  capacity?: number | string;
  date?: string;
  availability?: string;
  venueTypes?: string[];
  equipment?: string[];
  contentFormats?: string[];
}

interface FilterPanelProps {
  isOpen: boolean;
  onClose: () => void;
  type: FilterType;
  currentFilters: FilterState;
  onApply: (filters: FilterState) => void;
  resultsCount: number;
}

// --- Configuration Data ---

const VISUAL_CATEGORIES: Record<FilterType, { id: string; label: string; icon: any }[]> = {
  artist: [
    { id: 'Singer', label: 'Singer', icon: Mic },
    { id: 'DJ', label: 'DJ', icon: Music },
    { id: 'Musician', label: 'Musician', icon: Music },
    { id: 'Band', label: 'Band', icon: Users },
  ],
  venue: [
    { id: 'Rooftop', label: 'Rooftop', icon: Zap },
    { id: 'Club', label: 'Club', icon: Music },
    { id: 'Beach Bar', label: 'Beach', icon: Camera },
    { id: 'Luxury Hotel', label: 'Hotel', icon: Briefcase },
  ],
  technician: [
    { id: 'Sound', label: 'Sound', icon: Speaker },
    { id: 'Lighting', label: 'Light', icon: Zap },
    { id: 'Visuals', label: 'Visuals', icon: Camera },
    { id: 'Stage', label: 'Stage', icon: Briefcase },
  ],
  agency: [
    { id: 'Talent Agency', label: 'Talent', icon: Users },
    { id: 'PR & Marketing', label: 'Marketing', icon: Briefcase },
    { id: 'Management', label: 'Mgmt', icon: Shield },
  ],
  provider: [
    { id: 'Food & Drink', label: 'Catering', icon: Briefcase },
    { id: 'Security', label: 'Security', icon: Shield },
    { id: 'Transport', label: 'Transport', icon: Truck },
  ],
  event: [
    { id: 'Concert', label: 'Concert', icon: Music },
    { id: 'Festival', label: 'Festival', icon: Tent },
    { id: 'Mariage', label: 'Wedding', icon: Heart },
    { id: 'Séminaire', label: 'Seminar', icon: Briefcase },
    { id: 'Soirée à thème', label: 'Theme Party', icon: Sparkles },
    { id: 'Lancement produit', label: 'Launch', icon: Rocket },
    { id: 'Team building', label: 'Team Building', icon: Users },
  ]
};

const MOOD_TAGS: Record<FilterType, string[]> = {
  artist: ['Pop', 'Techno', 'Hip Hop', 'Jazz', 'Rock', 'Oriental', 'Electro', 'Acoustic', 'Chill', 'Party'],
  venue: ['Chill', 'Festive', 'Romantic', 'Corporate', 'Intimate', 'Underground', 'Luxury', 'Outdoor'],
  technician: ['Concerts', 'Weddings', 'Festivals', 'Studio', 'Corporate', 'Streaming'],
  agency: ['Corporate', 'Wedding', 'Festival', 'Digital', 'Logistics'],
  provider: ['Gourmet', 'Safety', 'Licensed', 'VIP', 'Eco-friendly', 'Halal'],
  event: ['Chill', 'Festif', 'Romantique', 'Corporate', 'Intimiste']
};

const EVENT_VENUE_TYPES = ['Salle de concert', 'Bar', 'Lounge', 'Rooftop', 'Hôtel', 'Villa', 'Espace culturel', 'Plage privée'];
const EVENT_CAPACITY_RANGES = ['0-50', '50-200', '200-500', '> 500'];
const EVENT_EQUIPMENT = ['Sono intégrée', 'Éclairage intégré', 'Scène', 'Backline', 'Écran géant', 'Bar', 'Restauration', 'Parking', 'PMR'];
const EVENT_CONTENT_FORMATS = ['Tournage live', 'Captation drone', 'Reportage photo'];

const LOCATIONS = ['Tunis', 'Grand Tunis', 'Sousse', 'Hammamet', 'Djerba', 'Bizerte', 'National'];

const AVAILABILITY_OPTIONS = [
    { value: '', label: 'Any Availability' },
    { value: 'today', label: 'Today / Tonight' },
    { value: 'weekend', label: 'This Weekend' },
    { value: 'next_week', label: 'Next Week' }
];

// --- Sub-Components ---

const SectionHeader = ({ title, reset }: { title: string, reset?: () => void }) => (
  <div className="flex items-center justify-between mb-4 mt-8 first:mt-0">
    <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-slate-900 dark:text-white">{title}</h3>
    {reset && (
      <button onClick={reset} className="text-[10px] text-mid-primary hover:underline cursor-pointer font-medium">Reset</button>
    )}
  </div>
);

interface ChipProps {
  label: string;
  active: boolean;
  onClick: () => void;
  icon?: any;
}

const Chip: React.FC<ChipProps> = ({ label, active, onClick, icon: Icon }) => (
  <button
    onClick={onClick}
    className={`
      flex items-center gap-2 px-4 py-3 rounded-xl text-[11px] font-bold uppercase tracking-wider transition-all duration-300 w-full justify-center sm:justify-start
      ${active 
        ? 'bg-mid-primary text-white shadow-glow-blue scale-[1.02] ring-1 ring-mid-primary' 
        : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-mid-text-subtle hover:bg-slate-200 dark:hover:bg-white/10 border border-transparent'
      }
    `}
  >
    {Icon && <Icon className={`w-4 h-4 ${active ? 'text-white' : 'text-slate-400 dark:text-mid-text-muted'}`} />}
    {label}
  </button>
);

interface TagProps {
  label: string;
  active: boolean;
  onClick: () => void;
}

const Tag: React.FC<TagProps> = ({ label, active, onClick }) => (
  <button
    onClick={onClick}
    className={`
      px-3 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wide transition-all duration-300 border
      ${active 
        ? 'bg-mid-accent/10 border-mid-accent text-mid-accent shadow-sm' 
        : 'bg-transparent border-slate-200 dark:border-white/10 text-slate-500 dark:text-mid-text-muted hover:border-slate-400 dark:hover:border-white/30'
      }
    `}
  >
    {label}
  </button>
);

// --- Main Component ---

export const FilterPanel: React.FC<FilterPanelProps> = ({
  isOpen, onClose, type, currentFilters, onApply, resultsCount
}) => {
  const [localFilters, setLocalFilters] = useState<FilterState>(currentFilters);
  const [isClosing, setIsClosing] = useState(false);
  const [isAvailabilityOpen, setIsAvailabilityOpen] = useState(false);
  
  // Safely get categories and tags
  const categories = VISUAL_CATEGORIES[type] || [];
  const tags = MOOD_TAGS[type] || [];

  // Sync when opening
  useEffect(() => {
    if (isOpen) {
      setLocalFilters(currentFilters);
      setIsClosing(false);
      setIsAvailabilityOpen(false);
    }
  }, [isOpen, currentFilters]);

  const handleClose = () => {
    setIsClosing(true);
    setTimeout(onClose, 300); // Shorter for snappy fade
  };

  const handleApply = () => {
    onApply(localFilters);
    handleClose();
  };

  const toggleCategory = (cat: string) => {
    setLocalFilters(prev => {
      const exists = prev.categories.includes(cat);
      return {
        ...prev,
        categories: exists 
          ? prev.categories.filter(c => c !== cat) 
          : [...prev.categories, cat]
      };
    });
  };

  const toggleTag = (tag: string) => {
    setLocalFilters(prev => {
      const exists = prev.tags.includes(tag);
      return {
        ...prev,
        tags: exists 
          ? prev.tags.filter(t => t !== tag) 
          : [...prev.tags, tag]
      };
    });
  };

  const toggleLocation = (loc: string) => {
    setLocalFilters(prev => ({
        ...prev,
        location: prev.location === loc ? null : loc
    }));
  };

  const toggleArrayFilter = (key: keyof FilterState, value: string) => {
      setLocalFilters(prev => {
          const currentArray = (prev[key] as string[]) || [];
          const exists = currentArray.includes(value);
          return {
              ...prev,
              [key]: exists 
                  ? currentArray.filter(i => i !== value) 
                  : [...currentArray, value]
          };
      });
  };

  const resetAll = () => {
    setLocalFilters({
      categories: [],
      tags: [],
      rating: null,
      verifiedOnly: false,
      location: null,
      capacity: undefined,
      date: undefined,
      venueTypes: [],
      equipment: [],
      contentFormats: []
    });
  };

  if (!isOpen && !isClosing) return null;

  return (
    <>
      {/* Blurred Backdrop */}
      <div 
        onClick={handleClose}
        className={`fixed inset-0 z-[150] bg-black/20 backdrop-blur-sm cursor-default transition-opacity duration-300 ${isClosing ? 'opacity-0' : 'opacity-100'}`}
        aria-hidden="true"
      />

      {/* Panel */}
      <div 
        className={`
            fixed z-[160] transition-all duration-300 ease-out flex flex-col
            bg-white dark:bg-[#191919] border-l border-b border-black/5 dark:border-white/10 shadow-2xl
            
            /* Mobile Layout: Top Sheet */
            top-0 right-0 left-0 h-auto max-h-[90vh] rounded-b-[32px]
            
            /* Desktop Layout: Right Sidebar */
            md:left-auto md:h-full md:max-h-none md:w-[400px] md:rounded-none md:rounded-bl-[32px]

            /* Animation Logic: 
               - Mobile Closing: Fade Out + Slight Slide Up (instead of full slide away)
               - Desktop Closing: Slide Right
            */
            ${isClosing 
                ? 'opacity-0 -translate-y-4 md:opacity-100 md:translate-y-0 md:translate-x-full' 
                : 'opacity-100 translate-y-0 md:translate-x-0 animate-in slide-in-from-top-4 fade-in md:slide-in-from-right-full'
            }
        `}
      >
        {/* Header */}
        <div className="flex-none flex items-center justify-between px-6 py-5 border-b border-black/5 dark:border-white/5 bg-white dark:bg-[#191919] z-20">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-mid-primary/10 flex items-center justify-center">
              <SlidersHorizontal className="w-4 h-4 text-mid-primary" />
            </div>
            <div>
               <h2 className="text-sm font-bold uppercase tracking-widest text-slate-900 dark:text-white">Filters</h2>
               <p className="text-[10px] text-slate-500 dark:text-mid-text-muted">Refine your discovery</p>
            </div>
          </div>
          <button 
            onClick={resetAll}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 dark:bg-white/5 hover:bg-red-50 dark:hover:bg-red-500/10 text-slate-500 dark:text-mid-text-subtle hover:text-red-500 transition-colors text-[10px] font-bold uppercase tracking-wider"
          >
            <RotateCcw className="w-3 h-3" /> Clear
          </button>
          <button 
            onClick={handleClose}
            className="md:hidden p-2 rounded-full bg-slate-100 dark:bg-white/5 text-slate-500 dark:text-white active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-8 no-scrollbar">
            
            {/* 1. Visual Categories */}
            <section>
                <SectionHeader title={type === 'event' ? "Type d'événement" : "Category"} />
                {categories.length > 0 ? (
                  <div className="grid grid-cols-2 gap-3">
                      {categories.map((cat) => (
                          <Chip 
                              key={cat.id} 
                              label={cat.label} 
                              icon={cat.icon} 
                              active={localFilters.categories.includes(cat.id)} 
                              onClick={() => toggleCategory(cat.id)} 
                          />
                      ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 dark:text-mid-text-muted italic">No categories available for this section.</p>
                )}
            </section>

             {/* Event Specific: Venue Type */}
             {type === 'event' && (
                <section>
                    <SectionHeader title="Type de lieu" />
                    <div className="flex flex-wrap gap-2">
                        {EVENT_VENUE_TYPES.map(vt => (
                            <Tag 
                                key={vt} 
                                label={vt} 
                                active={localFilters.venueTypes?.includes(vt) || false} 
                                onClick={() => toggleArrayFilter('venueTypes', vt)} 
                            />
                        ))}
                    </div>
                </section>
            )}

            {/* 2. Location & Date (Universal) */}
            <section className="space-y-4">
                 <SectionHeader title="Location & Timing" />
                 <div className="flex flex-wrap gap-2">
                    {LOCATIONS.map(loc => (
                        <Tag 
                            key={loc} 
                            label={loc} 
                            active={localFilters.location === loc} 
                            onClick={() => toggleLocation(loc)} 
                        />
                    ))}
                 </div>
                 
                 {/* Accordion Style Availability to Prevent Clipping */}
                 <div className="bg-slate-100 dark:bg-white/5 border border-black/5 dark:border-white/10 rounded-xl overflow-hidden transition-all duration-300">
                    <button
                        onClick={() => setIsAvailabilityOpen(!isAvailabilityOpen)}
                        className={`
                            w-full flex items-center justify-between py-3.5 px-4 text-xs font-bold text-slate-700 dark:text-white transition-colors
                            ${isAvailabilityOpen ? 'bg-white/5 dark:bg-black/20' : ''}
                        `}
                    >
                        <div className="flex items-center gap-3">
                            <Calendar className={`w-4 h-4 ${localFilters.availability ? 'text-mid-primary' : 'text-slate-400 dark:text-mid-text-muted'}`} />
                            <span>{AVAILABILITY_OPTIONS.find(o => o.value === (localFilters.availability || ''))?.label || 'Any Availability'}</span>
                        </div>
                        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-300 ${isAvailabilityOpen ? 'rotate-180' : ''}`} />
                    </button>

                    <div className={`
                         overflow-hidden transition-[max-height] duration-300 ease-in-out
                         ${isAvailabilityOpen ? 'max-h-[200px]' : 'max-h-0'}
                    `}>
                        <div className="p-2 space-y-1 border-t border-black/5 dark:border-white/5">
                            {AVAILABILITY_OPTIONS.map((opt) => (
                                <button
                                    key={opt.value}
                                    onClick={() => {
                                        setLocalFilters({...localFilters, availability: opt.value});
                                        setIsAvailabilityOpen(false);
                                    }}
                                    className={`
                                        w-full text-left px-3 py-2.5 rounded-lg text-xs font-medium transition-all flex items-center justify-between
                                        ${localFilters.availability === opt.value 
                                            ? 'bg-mid-primary/10 text-mid-primary font-bold' 
                                            : 'text-slate-500 dark:text-mid-text-subtle hover:bg-black/5 dark:hover:bg-white/5'}
                                    `}
                                >
                                    {opt.label}
                                    {localFilters.availability === opt.value && <Check className="w-3.5 h-3.5" />}
                                </button>
                            ))}
                        </div>
                    </div>
                 </div>
            </section>

            {/* 3. Mood & Tags (Specific) */}
            <section>
                <SectionHeader title={type === 'technician' ? 'Skills & Gear' : type === 'venue' ? 'Ambiance' : (type === 'event' ? 'Ambiance souhaitée' : 'Styles & Genres')} />
                <div className="flex flex-wrap gap-2">
                    {tags.map(tag => (
                        <Tag 
                            key={tag} 
                            label={tag} 
                            active={localFilters.tags.includes(tag)} 
                            onClick={() => toggleTag(tag)} 
                        />
                    ))}
                </div>
            </section>

            {/* Event Specific: Equipment */}
            {type === 'event' && (
                <section>
                    <SectionHeader title="Équipements disponibles" />
                    <div className="flex flex-wrap gap-2">
                        {EVENT_EQUIPMENT.map(eq => (
                            <Tag 
                                key={eq} 
                                label={eq} 
                                active={localFilters.equipment?.includes(eq) || false} 
                                onClick={() => toggleArrayFilter('equipment', eq)} 
                            />
                        ))}
                    </div>
                </section>
            )}

            {/* Event Specific: Content Formats */}
            {type === 'event' && (
                <section>
                    <SectionHeader title="Formats de contenu" />
                    <div className="flex flex-wrap gap-2">
                        {EVENT_CONTENT_FORMATS.map(fmt => (
                            <Tag 
                                key={fmt} 
                                label={fmt} 
                                active={localFilters.contentFormats?.includes(fmt) || false} 
                                onClick={() => toggleArrayFilter('contentFormats', fmt)} 
                            />
                        ))}
                    </div>
                </section>
            )}

            {/* 4. Capacity (Venues & Events) */}
            {(type === 'venue' || type === 'event') && (
                <section>
                    <SectionHeader title={type === 'event' ? "Capacité d’accueil" : "Capacity"} />
                    
                    {type === 'event' ? (
                         <div className="grid grid-cols-2 gap-2">
                            {EVENT_CAPACITY_RANGES.map(range => (
                                <button
                                    key={range}
                                    onClick={() => setLocalFilters(prev => ({ ...prev, capacity: prev.capacity === range ? undefined : range }))}
                                    className={`
                                        px-4 py-3 rounded-xl text-[11px] font-bold uppercase tracking-wider transition-all border
                                        ${localFilters.capacity === range 
                                            ? 'bg-mid-primary/10 border-mid-primary text-mid-primary shadow-sm' 
                                            : 'bg-slate-100 dark:bg-white/5 border-transparent text-slate-500 dark:text-mid-text-subtle hover:bg-slate-200 dark:hover:bg-white/10'}
                                    `}
                                >
                                    {range}
                                </button>
                            ))}
                         </div>
                    ) : (
                        <div className="bg-slate-100 dark:bg-white/5 rounded-2xl p-6 border border-black/5 dark:border-white/5">
                            <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-slate-500 mb-4">
                                <span>Intimate</span>
                                <span>Massive</span>
                            </div>
                            <input 
                                type="range" 
                                min="50" 
                                max="1000" 
                                step="50"
                                value={typeof localFilters.capacity === 'number' ? localFilters.capacity : 500}
                                onChange={(e) => setLocalFilters({...localFilters, capacity: parseInt(e.target.value)})}
                                className="w-full h-2 bg-slate-300 dark:bg-white/10 rounded-full appearance-none cursor-pointer accent-mid-primary"
                            />
                            <div className="text-center mt-3 font-tiempos text-lg text-slate-900 dark:text-white">
                                Up to {localFilters.capacity || 500} guests
                            </div>
                        </div>
                    )}
                </section>
            )}

            {/* 5. Rating & Verification */}
            <section className="space-y-5">
                <SectionHeader title={type === 'event' ? "Qualité & Note" : "Quality Assurance"} />
                
                <div className="flex items-center justify-between p-4 rounded-xl bg-slate-100 dark:bg-white/5 border border-black/5 dark:border-white/5 cursor-pointer hover:bg-slate-200 dark:hover:bg-white/10 transition-colors"
                     onClick={() => setLocalFilters(prev => ({ ...prev, verifiedOnly: !prev.verifiedOnly }))}
                >
                     <div className="flex items-center gap-3">
                         <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${localFilters.verifiedOnly ? 'bg-mid-secondary text-white' : 'bg-slate-300 dark:bg-white/10 text-slate-500'}`}>
                             <Shield className="w-4 h-4" />
                         </div>
                         <div className="flex flex-col">
                             <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Verified Only</span>
                             <span className="text-[9px] text-slate-500 dark:text-mid-text-subtle">MidMike Guarantee Badge</span>
                         </div>
                     </div>
                     <div className={`w-10 h-5 rounded-full relative transition-colors duration-300 ${localFilters.verifiedOnly ? 'bg-mid-secondary' : 'bg-slate-300 dark:bg-white/10'}`}>
                        <div className={`absolute top-1 left-1 w-3 h-3 rounded-full bg-white transition-transform duration-300 shadow-sm ${localFilters.verifiedOnly ? 'translate-x-5' : 'translate-x-0'}`} />
                    </div>
                </div>

                <div className="space-y-3">
                   <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-muted">Minimum Rating</h4>
                   <div className="grid grid-cols-5 gap-1.5 sm:gap-2">
                        {[1, 2, 3, 4, 5].map(rating => (
                            <button
                               key={rating}
                               onClick={() => setLocalFilters(prev => ({ ...prev, rating: prev.rating === rating ? null : rating }))}
                               className={`flex flex-col py-3 rounded-xl border items-center justify-center gap-1 transition-all ${localFilters.rating === rating ? 'bg-mid-highlight/10 border-mid-highlight text-mid-highlight shadow-glow-highlight' : 'bg-transparent border-slate-200 dark:border-white/10 text-slate-500 dark:text-mid-text-muted hover:border-slate-400 dark:hover:border-white/30'}`}
                            >
                                <Star className={`w-4 h-4 ${localFilters.rating === rating ? 'fill-current' : ''}`} />
                                <span className="text-[10px] font-bold uppercase">{rating}</span>
                            </button>
                        ))}
                   </div>
                </div>

                {/* Apply Button Inside Content */}
                <div className="pt-4 pb-2">
                  <button 
                      onClick={handleApply}
                      className="w-full py-4 rounded-2xl bg-mid-primary text-white text-[11px] font-bold uppercase tracking-[0.25em] shadow-glow-blue hover:bg-mid-primary/90 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
                  >
                      Show {resultsCount} Results <Check className="w-4 h-4" />
                  </button>
                </div>
            </section>

        </div>
      </div>
    </>
  );
};