
import React from 'react';
import { X } from 'lucide-react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  fullScreen?: boolean;
  floatingClose?: boolean;
}

export const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children, fullScreen = false, floatingClose = false }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-0">
      {/* Cinematic Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/40 dark:bg-black/60 backdrop-blur-sm transition-opacity duration-500 animate-in fade-in"
        onClick={onClose}
      />
      
      {/* Modal Content - Adaptive Glass */}
      <div className={`
        relative flex flex-col 
        bg-white/70 dark:bg-[#121212]/70 backdrop-blur-[40px] 
        border border-slate-200 dark:border-white/10 shadow-2xl overflow-hidden 
        animate-in fade-in zoom-in-95 duration-300 ring-1 ring-black/5 dark:ring-white/5
        ${fullScreen ? 'w-full h-full border-0' : 'w-full max-w-2xl rounded-[24px] md:rounded-[32px] max-h-[85vh] md:max-h-[90vh]'}
      `}>
        
        {/* Top Gradient Line */}
        <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-mid-primary to-transparent opacity-40 z-20" />

        {floatingClose ? (
           <button 
             onClick={onClose} 
             className="absolute top-6 right-6 z-50 p-2 rounded-full bg-white/10 hover:bg-white/20 text-slate-500 dark:text-white/60 hover:text-slate-900 dark:hover:text-white transition-colors backdrop-blur-md border border-white/5"
           >
             <X className="w-5 h-5" />
           </button>
        ) : (
          <div className="flex items-center justify-between px-6 py-5 md:px-8 md:py-6 border-b border-slate-100 dark:border-white/5 bg-slate-50/50 dark:bg-white/[0.02] flex-shrink-0">
            <h2 className="text-lg md:text-xl font-inter font-semibold text-slate-900 dark:text-white tracking-wide truncate pr-4">{title}</h2>
            <button onClick={onClose} className="p-2 hover:bg-slate-200 dark:hover:bg-white/5 rounded-full text-slate-500 dark:text-mid-text-subtle hover:text-slate-900 dark:hover:text-white transition-colors flex-shrink-0">
              <X className="w-5 h-5" />
            </button>
          </div>
        )}
        
        <div className="flex-1 overflow-y-auto custom-scrollbar bg-transparent">
          {children}
        </div>
      </div>
    </div>
  );
};
