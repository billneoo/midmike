
import React from 'react';
import { BookingRequest } from '../types';
import { Calendar, Clock, MapPin, Check, X, User, ArrowRight } from 'lucide-react';

interface BookingCardProps {
    booking: BookingRequest;
    onAccept: (id: string) => void;
    onDecline: (id: string) => void;
}

export const BookingCard: React.FC<BookingCardProps> = ({ booking, onAccept, onDecline }) => {
    const isPending = booking.status === 'pending';
    const isConfirmed = booking.status === 'confirmed';
    const isDeclined = booking.status === 'declined';

    return (
        <div className={`
            p-5 rounded-3xl border transition-all duration-300 group
            ${isConfirmed 
                ? 'bg-green-500/5 border-green-500/20' 
                : isDeclined 
                    ? 'bg-slate-50 dark:bg-white/5 border-slate-200 dark:border-white/10 opacity-70'
                    : 'bg-white dark:bg-white/[0.03] border-slate-200 dark:border-white/10 hover:border-mid-primary/30 shadow-sm hover:shadow-md'
            }
        `}>
            <div className="flex flex-col gap-5">
                {/* Header Section */}
                <div className="flex justify-between items-start gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                        <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-slate-100 dark:bg-white/10 flex items-center justify-center overflow-hidden border border-slate-200 dark:border-white/10 shrink-0">
                            {booking.clientAvatar ? (
                                <img src={booking.clientAvatar} alt={booking.clientName} className="w-full h-full object-cover" />
                            ) : (
                                <User className="w-5 h-5 text-slate-400" />
                            )}
                        </div>
                        <div className="min-w-0 pt-0.5">
                            <h4 className="text-sm font-bold text-slate-900 dark:text-white leading-tight truncate pr-2">
                                {booking.eventName}
                            </h4>
                            <div className="flex items-center gap-2 mt-1 flex-wrap">
                                <span className="text-[11px] text-slate-500 dark:text-slate-400 truncate max-w-[100px] sm:max-w-none">
                                    {booking.clientName}
                                </span>
                                <span className="w-1 h-1 bg-slate-300 rounded-full shrink-0" />
                                <span className="text-[11px] font-bold text-mid-primary whitespace-nowrap">
                                    {booking.price}
                                </span>
                            </div>
                        </div>
                    </div>

                    {/* Status Badge - Relative Layout */}
                    <span className={`
                        shrink-0 px-2.5 py-1 rounded-full text-[9px] font-bold uppercase tracking-widest border
                        ${isPending ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' : 
                          isConfirmed ? 'bg-green-500/10 text-green-500 border-green-500/20' : 
                          'bg-slate-200 dark:bg-white/10 text-slate-500 dark:text-slate-400 border-transparent'}
                    `}>
                        {booking.status}
                    </span>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-2 gap-3 text-[11px] text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-white/[0.02] p-3 rounded-xl border border-slate-100 dark:border-white/5">
                    <div className="flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{booking.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{booking.time}</span>
                    </div>
                    <div className="flex items-center gap-2 col-span-2 pt-1 border-t border-slate-200 dark:border-white/5 mt-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{booking.location}</span>
                    </div>
                </div>

                {/* Message Preview */}
                {booking.message && (
                    <div className="p-3 bg-slate-50 dark:bg-black/20 rounded-xl text-[10px] text-slate-500 italic border border-slate-100 dark:border-white/5 leading-relaxed">
                        "{booking.message}"
                    </div>
                )}

                {/* Actions */}
                {isPending && (
                    <div className="flex gap-3">
                        <button 
                            onClick={() => onDecline(booking.id)}
                            className="px-4 py-3 border border-slate-200 dark:border-white/10 text-slate-500 hover:text-red-500 hover:border-red-500/30 hover:bg-red-500/5 rounded-xl transition-all flex items-center justify-center"
                            aria-label="Decline"
                        >
                            <X className="w-4 h-4" />
                        </button>
                        <button 
                            onClick={() => onAccept(booking.id)}
                            className="flex-1 py-3 bg-slate-900 dark:bg-white text-white dark:text-black rounded-xl text-[10px] font-bold uppercase tracking-widest hover:opacity-90 transition-all flex items-center justify-center gap-2 shadow-lg active:scale-[0.98]"
                        >
                            Accept Request <Check className="w-3.5 h-3.5" />
                        </button>
                    </div>
                )}
                
                {isConfirmed && (
                    <button className="w-full py-3 border border-green-500/20 bg-green-500/5 text-green-600 rounded-xl text-[10px] font-bold uppercase tracking-widest flex items-center justify-center gap-2 cursor-default">
                        View Contract <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                )}
            </div>
        </div>
    );
};
