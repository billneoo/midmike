
import React, { useState } from 'react';
import { 
  ArrowLeft, Upload, Check, Music, Mic2, Users, 
  Sparkles, Monitor, Mic, Camera, MapPin, Globe, 
  DollarSign, Calendar, Clock, ShieldCheck, AlertCircle,
  Instagram, Youtube, CloudLightning, FileText, CheckCircle2,
  Image as ImageIcon
} from 'lucide-react';

interface ArtistOnboardingProps {
  onBack: () => void;
  onComplete: (data: any) => void;
  initialData: { name: string; email: string; phone: string };
}

const STEPS = [
  'Role & Identity',
  'Contact & Location',
  'Service Details',
  'Rates & Terms',
  'Media & Portfolio',
  'Availability',
  'Validation'
];

const ROLES = [
  { id: 'singer', label: 'Singer', icon: Mic2 },
  { id: 'musician', label: 'Musician', icon: Music },
  { id: 'band', label: 'Band / Group', icon: Users },
  { id: 'dancer', label: 'Dancer / Visuals', icon: Sparkles },
  { id: 'magician', label: 'Magician', icon: CloudLightning },
  { id: 'host', label: 'Host / MC', icon: Mic },
];

const SPECIALTIES_SUGGESTIONS = ['Jazz', 'Pop', 'Rock', 'Techno', 'Classical', 'Acoustic', 'DJ Set', 'Improvisation'];

export const ArtistOnboarding: React.FC<ArtistOnboardingProps> = ({ onBack, onComplete, initialData }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    // Step 1
    roles: [] as string[],
    stageName: initialData.name || '',
    bio: '',
    profileImage: null as File | null,
    
    // Step 2
    proEmail: initialData.email || '',
    proPhone: initialData.phone || '',
    country: 'Tunisia',
    city: '',
    website: '',
    socials: { instagram: '', youtube: '', soundcloud: '' },

    // Step 3
    specialties: [] as string[],
    hasEquipment: false,
    equipmentDetails: '',

    // Step 4
    priceRange: '',
    cancellationPolicy: '',

    // Step 5
    mediaFiles: [] as File[],
    audioLink: '',

    // Step 6
    availability: [] as string[], // e.g., 'weekends', 'evenings'
    responseTime: '24h',

    // Step 7
    acceptedTerms: false,
    certifiedAccurate: false
  });

  const handleNext = () => {
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      onComplete(formData);
    }
  };

  const handleBackStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    } else {
      onBack();
    }
  };

  const toggleRole = (roleId: string) => {
    setFormData(prev => ({
      ...prev,
      roles: prev.roles.includes(roleId) 
        ? prev.roles.filter(r => r !== roleId) 
        : [...prev.roles, roleId]
    }));
  };

  const toggleSpecialty = (tag: string) => {
    setFormData(prev => ({
      ...prev,
      specialties: prev.specialties.includes(tag)
        ? prev.specialties.filter(t => t !== tag)
        : [...prev.specialties, tag]
    }));
  };

  const toggleAvailability = (slot: string) => {
    setFormData(prev => ({
      ...prev,
      availability: prev.availability.includes(slot)
        ? prev.availability.filter(s => s !== slot)
        : [...prev.availability, slot]
    }));
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0: // Role & Identity
        return (
          <div className="space-y-8 animate-cinematic-fade">
            <div className="text-center space-y-2">
              <h3 className="text-2xl font-tiempos font-normal text-slate-900 dark:text-white">Define your Artistry</h3>
              <p className="text-xs text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Select all that apply</p>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {ROLES.map(role => (
                <button
                  key={role.id}
                  onClick={() => toggleRole(role.id)}
                  className={`
                    p-4 rounded-2xl border flex flex-col items-center justify-center gap-3 transition-all duration-300
                    ${formData.roles.includes(role.id)
                      ? 'bg-mid-accent/10 border-mid-accent text-slate-900 dark:text-white shadow-glow-accent'
                      : 'bg-white dark:bg-white/[0.03] border-slate-200 dark:border-white/5 text-slate-500 dark:text-mid-text-subtle hover:bg-slate-50 dark:hover:bg-white/[0.05] hover:border-slate-300 dark:hover:border-white/10'}
                  `}
                >
                  <role.icon className={`w-6 h-6 ${formData.roles.includes(role.id) ? 'text-mid-accent' : 'text-current'}`} />
                  <span className="text-[10px] font-bold uppercase tracking-widest">{role.label}</span>
                </button>
              ))}
            </div>

            <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-white/5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <div className="space-y-2">
                    <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Stage Name *</label>
                    <input 
                      type="text" 
                      value={formData.stageName}
                      onChange={e => setFormData({...formData, stageName: e.target.value})}
                      className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm text-slate-900 dark:text-white focus:border-mid-accent/50 focus:outline-none"
                      placeholder="e.g. The Midnight Trio"
                    />
                 </div>
                 <div className="space-y-2">
                    <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Profile Photo</label>
                    <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-white/[0.05] flex items-center justify-center border border-slate-200 dark:border-white/10">
                            <Camera className="w-5 h-5 text-slate-400 dark:text-mid-text-subtle" />
                        </div>
                        <button className="px-4 py-2 rounded-lg bg-slate-100 dark:bg-white/[0.05] hover:bg-slate-200 dark:hover:bg-white/[0.1] text-[10px] font-bold uppercase tracking-widest text-slate-700 dark:text-white transition-colors border border-slate-200 dark:border-white/10">
                            Upload
                        </button>
                    </div>
                 </div>
              </div>
              <div className="space-y-2">
                 <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Short Bio (Max 200 chars) *</label>
                 <textarea 
                    value={formData.bio}
                    onChange={e => setFormData({...formData, bio: e.target.value})}
                    maxLength={200}
                    rows={3}
                    className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm text-slate-900 dark:text-white focus:border-mid-accent/50 focus:outline-none resize-none"
                    placeholder="Describe your style and performance..."
                 />
                 <div className="text-right text-[9px] text-slate-400 dark:text-mid-text-subtle">{formData.bio.length}/200</div>
              </div>
            </div>
          </div>
        );

      case 1: // Contact & Location
        return (
          <div className="space-y-8 animate-cinematic-fade">
             <div className="text-center space-y-2">
              <h3 className="text-2xl font-tiempos font-normal text-slate-900 dark:text-white">Contact & Presence</h3>
              <p className="text-xs text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">How can clients reach you?</p>
            </div>

            <div className="bg-mid-surface/5 dark:bg-mid-surface/50 rounded-2xl p-6 border border-slate-200 dark:border-white/5 space-y-4">
               <div className="flex items-center gap-2 mb-2">
                  <ShieldCheck className="w-4 h-4 text-green-500" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-green-500">Private Details</span>
                  <span className="text-[9px] text-slate-400 dark:text-mid-text-subtle ml-auto opacity-60">Visible only on confirmed booking</span>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <div className="space-y-2">
                      <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Pro Email *</label>
                      <input type="email" value={formData.proEmail} onChange={e => setFormData({...formData, proEmail: e.target.value})} className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm text-slate-900 dark:text-white focus:outline-none" />
                   </div>
                   <div className="space-y-2">
                      <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Phone Number *</label>
                      <input type="tel" value={formData.proPhone} onChange={e => setFormData({...formData, proPhone: e.target.value})} className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm text-slate-900 dark:text-white focus:outline-none" />
                   </div>
               </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                   <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Country</label>
                   <div className="relative">
                      <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle" />
                      <input type="text" value={formData.country} readOnly className="w-full bg-slate-100 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 pl-10 text-sm text-slate-500 dark:text-white/50 cursor-not-allowed" />
                   </div>
                </div>
                <div className="space-y-2">
                   <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">City *</label>
                   <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle" />
                      <input 
                        type="text" 
                        value={formData.city} 
                        onChange={e => setFormData({...formData, city: e.target.value})} 
                        className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 pl-10 text-sm text-slate-900 dark:text-white focus:border-mid-accent/50 focus:outline-none"
                        placeholder="e.g. Tunis, Sousse"
                      />
                   </div>
                </div>
            </div>

            <div className="space-y-4">
                <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Social Presence</label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div className="relative">
                        <Instagram className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle" />
                        <input type="text" placeholder="@username" className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-2.5 pl-10 text-xs text-slate-900 dark:text-white focus:outline-none" />
                    </div>
                    <div className="relative">
                        <Youtube className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle" />
                        <input type="text" placeholder="Channel Link" className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-2.5 pl-10 text-xs text-slate-900 dark:text-white focus:outline-none" />
                    </div>
                    <div className="relative">
                        <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle" />
                        <input type="text" placeholder="Website" className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-2.5 pl-10 text-xs text-slate-900 dark:text-white focus:outline-none" />
                    </div>
                </div>
            </div>
          </div>
        );

      case 2: // Service Description
        return (
          <div className="space-y-8 animate-cinematic-fade">
             <div className="text-center space-y-2">
              <h3 className="text-2xl font-tiempos font-normal text-slate-900 dark:text-white">The Craft</h3>
              <p className="text-xs text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Skills & Equipment</p>
            </div>

            <div className="space-y-4">
               <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Specialties / Skills *</label>
               <div className="flex flex-wrap gap-2">
                  {SPECIALTIES_SUGGESTIONS.map(tag => (
                     <button
                        key={tag}
                        onClick={() => toggleSpecialty(tag)}
                        className={`px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-wider border transition-all ${formData.specialties.includes(tag) ? 'bg-mid-accent text-white border-mid-accent' : 'bg-transparent border-slate-200 dark:border-white/10 text-slate-500 dark:text-mid-text-subtle hover:border-slate-400 dark:hover:border-white/30'}`}
                     >
                        {tag}
                     </button>
                  ))}
                  <button className="px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-wider border border-slate-200 dark:border-white/10 text-slate-500 dark:text-mid-text-subtle hover:border-slate-400 dark:hover:border-white/30 border-dashed">
                    + Add Custom
                  </button>
               </div>
            </div>

            <div className="bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-2xl p-6">
                <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-mid-primary/10 flex items-center justify-center">
                            <Monitor className="w-5 h-5 text-mid-primary" />
                        </div>
                        <div>
                            <h4 className="text-sm font-bold text-slate-900 dark:text-white">Equipment Available?</h4>
                            <p className="text-[10px] text-slate-500 dark:text-mid-text-subtle">Do you provide your own technical gear?</p>
                        </div>
                    </div>
                    <button 
                        onClick={() => setFormData({...formData, hasEquipment: !formData.hasEquipment})}
                        className={`w-12 h-6 rounded-full relative transition-colors duration-300 ${formData.hasEquipment ? 'bg-mid-primary' : 'bg-slate-300 dark:bg-white/10'}`}
                    >
                        <div className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform duration-300 shadow-sm ${formData.hasEquipment ? 'translate-x-6' : 'translate-x-0'}`} />
                    </button>
                </div>
                
                {formData.hasEquipment && (
                    <div className="animate-in fade-in slide-in-from-top-2">
                         <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest mb-2 block">Describe Equipment</label>
                         <textarea 
                            value={formData.equipmentDetails}
                            onChange={e => setFormData({...formData, equipmentDetails: e.target.value})}
                            className="w-full bg-white dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm text-slate-900 dark:text-white focus:outline-none h-24 resize-none"
                            placeholder="e.g. Full PA system for 200 pax, Shure microphones..."
                        />
                    </div>
                )}
            </div>
          </div>
        );

      case 3: // Rates & Conditions
        return (
          <div className="space-y-8 animate-cinematic-fade">
            <div className="text-center space-y-2">
              <h3 className="text-2xl font-tiempos font-normal text-slate-900 dark:text-white">Valuation</h3>
              <p className="text-xs text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Define your worth</p>
            </div>

            <div className="space-y-4">
                <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Price Range (Solo Performance) *</label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {['< 300 TND', '300 - 500 TND', '> 500 TND'].map(range => (
                        <button
                            key={range}
                            onClick={() => setFormData({...formData, priceRange: range})}
                            className={`
                                py-4 rounded-2xl border transition-all duration-300 flex flex-col items-center gap-2
                                ${formData.priceRange === range 
                                    ? 'bg-mid-accent text-white border-mid-accent shadow-glow-accent' 
                                    : 'bg-white dark:bg-white/[0.03] border-slate-200 dark:border-white/10 text-slate-500 dark:text-mid-text-subtle hover:bg-slate-50 dark:hover:bg-white/[0.05]'}
                            `}
                        >
                            <DollarSign className="w-5 h-5" />
                            <span className="text-sm font-bold tracking-wider">{range}</span>
                        </button>
                    ))}
                </div>
            </div>

            <div className="space-y-2">
                 <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Cancellation Policy / Deposit Terms *</label>
                 <textarea 
                    value={formData.cancellationPolicy}
                    onChange={e => setFormData({...formData, cancellationPolicy: e.target.value})}
                    rows={4}
                    className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm text-slate-900 dark:text-white focus:border-mid-accent/50 focus:outline-none resize-none"
                    placeholder="e.g. 50% deposit required on booking. Free cancellation up to 48h before event."
                 />
            </div>
          </div>
        );

      case 4: // Media & Proofs
        return (
           <div className="space-y-8 animate-cinematic-fade">
             <div className="text-center space-y-2">
              <h3 className="text-2xl font-tiempos font-normal text-slate-900 dark:text-white">Showcase</h3>
              <p className="text-xs text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Your visual & audio identity</p>
            </div>

            <div className="space-y-6">
                <div className="border-2 border-dashed border-slate-300 dark:border-white/10 rounded-3xl p-8 flex flex-col items-center justify-center gap-4 hover:bg-slate-50 dark:hover:bg-white/[0.02] transition-colors cursor-pointer group">
                    <div className="w-16 h-16 rounded-full bg-mid-surface flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                        <Upload className="w-6 h-6 text-mid-text-subtle group-hover:text-white" />
                    </div>
                    <div className="text-center space-y-1">
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">Upload Visuals</h4>
                        <p className="text-[10px] text-slate-500 dark:text-mid-text-subtle">3 to 5 Photos or Demo Video</p>
                    </div>
                </div>

                <div className="space-y-2">
                   <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Audio / Playlist Link</label>
                   <div className="relative">
                      <Music className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle" />
                      <input 
                        type="url" 
                        value={formData.audioLink} 
                        onChange={e => setFormData({...formData, audioLink: e.target.value})}
                        placeholder="SoundCloud, Spotify, or YouTube link..."
                        className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 pl-10 text-sm text-slate-900 dark:text-white focus:border-mid-accent/50 focus:outline-none"
                      />
                   </div>
                </div>
            </div>
           </div>
        );

      case 5: // Availability
        return (
           <div className="space-y-8 animate-cinematic-fade">
             <div className="text-center space-y-2">
              <h3 className="text-2xl font-tiempos font-normal text-slate-900 dark:text-white">Availability</h3>
              <p className="text-xs text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">When can you perform?</p>
            </div>

            <div className="space-y-4">
                 <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">General Schedule</label>
                 <div className="grid grid-cols-2 gap-3">
                    {['Weekdays (Day)', 'Weekdays (Evening)', 'Weekends (Day)', 'Weekends (Evening)'].map(slot => (
                        <button
                            key={slot}
                            onClick={() => toggleAvailability(slot)}
                            className={`
                                p-4 rounded-xl border flex items-center gap-3 transition-all
                                ${formData.availability.includes(slot) 
                                    ? 'bg-mid-primary/20 border-mid-primary text-slate-900 dark:text-white' 
                                    : 'bg-white dark:bg-white/[0.03] border-slate-200 dark:border-white/10 text-slate-500 dark:text-mid-text-subtle hover:border-slate-300 dark:hover:border-white/20'}
                            `}
                        >
                            <Calendar className="w-4 h-4" />
                            <span className="text-xs font-bold uppercase tracking-wider">{slot}</span>
                            {formData.availability.includes(slot) && <Check className="w-4 h-4 ml-auto text-mid-primary" />}
                        </button>
                    ))}
                 </div>
            </div>

            <div className="space-y-2">
                 <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Average Response Time</label>
                 <div className="relative">
                    <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle" />
                    <select 
                        value={formData.responseTime}
                        onChange={e => setFormData({...formData, responseTime: e.target.value})}
                        className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 pl-10 text-sm text-slate-900 dark:text-white focus:outline-none appearance-none"
                    >
                        <option value="1h">Within 1 hour</option>
                        <option value="24h">Within 24 hours</option>
                        <option value="48h">Within 48 hours</option>
                    </select>
                 </div>
            </div>
           </div>
        );

      case 6: // Validation
        return (
           <div className="space-y-8 animate-cinematic-fade">
             <div className="text-center space-y-2">
              <h3 className="text-2xl font-tiempos font-normal text-slate-900 dark:text-white">Final Steps</h3>
              <p className="text-xs text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Review and certify</p>
            </div>
            
            <div className="bg-slate-100 dark:bg-mid-surface/50 border border-slate-200 dark:border-white/10 rounded-2xl p-8 space-y-6">
                <div className="flex items-start gap-4 p-4 bg-mid-primary/10 rounded-xl border border-mid-primary/20">
                    <AlertCircle className="w-6 h-6 text-mid-primary shrink-0" />
                    <div className="space-y-1">
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white">Quality Assurance</h4>
                        <p className="text-[10px] text-slate-600 dark:text-mid-text-subtle leading-relaxed">
                            MidMike maintains high standards for all listed artists. Your profile will be reviewed by our curation team within 48 hours.
                        </p>
                    </div>
                </div>

                <div className="space-y-4">
                     <label className="flex items-center gap-3 cursor-pointer group">
                        <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${formData.acceptedTerms ? 'bg-mid-accent border-mid-accent' : 'border-slate-300 dark:border-white/20 group-hover:border-slate-400 dark:group-hover:border-white/40'}`}>
                            {formData.acceptedTerms && <Check className="w-3.5 h-3.5 text-white" />}
                        </div>
                        <input type="checkbox" className="hidden" checked={formData.acceptedTerms} onChange={() => setFormData({...formData, acceptedTerms: !formData.acceptedTerms})} />
                        <span className="text-xs text-slate-600 dark:text-mid-text-muted">I accept the Terms of Service & Quality Charter.</span>
                     </label>

                     <label className="flex items-center gap-3 cursor-pointer group">
                        <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${formData.certifiedAccurate ? 'bg-mid-accent border-mid-accent' : 'border-slate-300 dark:border-white/20 group-hover:border-slate-400 dark:group-hover:border-white/40'}`}>
                            {formData.certifiedAccurate && <Check className="w-3.5 h-3.5 text-white" />}
                        </div>
                        <input type="checkbox" className="hidden" checked={formData.certifiedAccurate} onChange={() => setFormData({...formData, certifiedAccurate: !formData.certifiedAccurate})} />
                        <span className="text-xs text-slate-600 dark:text-mid-text-muted">I certify the accuracy of my information.</span>
                     </label>
                </div>
            </div>
           </div>
        );
        
      default:
        return null;
    }
  };

  return (
    <div className="w-full h-full flex flex-col relative max-w-2xl mx-auto py-8 px-6 md:px-0">
        
        {/* Back Button - Top Left */}
        <button 
            onClick={handleBackStep}
            className="absolute top-0 left-0 z-50 group flex items-center gap-3 px-6 py-2.5 rounded-[10px] border border-black/5 dark:border-white/10 bg-white/20 dark:bg-black/20 backdrop-blur-md hover:border-mid-primary/50 hover:bg-mid-primary/5 transition-all duration-500 shadow-sm"
        >
            <ArrowLeft className="w-4 h-4 text-slate-600 dark:text-slate-300 group-hover:text-mid-primary group-hover:-translate-x-1 transition-all" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-600 dark:text-slate-300 group-hover:text-mid-primary transition-colors">Back</span>
        </button>

        {/* Progress Header */}
        <div className="flex items-center justify-between mb-12 mt-12">
            {STEPS.map((_, idx) => (
                <div key={idx} className="flex flex-col items-center gap-2 flex-1 relative">
                    <div className={`w-full h-1 rounded-full ${idx <= currentStep ? 'bg-mid-accent' : 'bg-slate-200 dark:bg-white/10'}`} />
                </div>
            ))}
        </div>

        {/* Step Counter */}
        <div className="absolute top-6 right-0 text-[10px] font-bold text-slate-400 dark:text-mid-text-subtle uppercase tracking-widest">
            Step {currentStep + 1} / {STEPS.length}
        </div>

        <div className="flex-1 overflow-y-auto no-scrollbar pb-24">
            {renderStepContent()}
        </div>

        {/* Footer Actions */}
        <div className="mt-auto pt-6 border-t border-slate-100 dark:border-white/5 flex justify-end">
            <button
                onClick={handleNext}
                disabled={currentStep === 6 && (!formData.acceptedTerms || !formData.certifiedAccurate)}
                className="px-8 py-3 rounded-xl bg-mid-primary hover:bg-mid-primary/90 text-white text-xs font-bold uppercase tracking-[0.2em] shadow-glow-blue transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
                {currentStep === 6 ? 'Submit Application' : 'Continue'}
                {currentStep < 6 && <ArrowLeft className="w-3 h-3 rotate-180" />}
            </button>
        </div>
    </div>
  );
};
