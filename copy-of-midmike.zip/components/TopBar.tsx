
import React, { useState, useEffect, useRef } from 'react';
import { Search, Bell, PanelLeft, User, Plus, Sun, Moon, Radio, ChevronDown, Settings, LogOut, X, Sparkles, Languages, Repeat, Check, ArrowRight, ArrowLeftRight, ShieldAlert, MessageSquare, Clock, AlertTriangle, CheckCircle2, Ticket, Play } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Role } from '../types';

interface TopBarProps {
  onCreateEvent: () => void;
  onMenuClick?: () => void;
  onNavigate: (route: string) => void;
  sidebarExpanded: boolean;
}

// Mock Notifications
const MOCK_NOTIFICATIONS = [
    { id: 1, title: 'Booking Confirmed', message: 'DJ Black accepted your request.', time: '2m ago', type: 'success', read: false },
    { id: 2, title: 'New Message', message: 'Sarah: "Are we still on for tomorrow?"', time: '15m ago', type: 'message', read: false },
    { id: 3, title: 'System Alert', message: 'Please update your payment method.', time: '1h ago', type: 'alert', read: true },
    { id: 4, title: 'Event Reminder', message: 'Techno Night starts in 2 hours.', time: '2h ago', type: 'info', read: true },
];

export const TopBar: React.FC<TopBarProps> = ({ onCreateEvent, onMenuClick, onNavigate, sidebarExpanded }) => {
  const { 
    user, 
    logout, 
    setAuthModalOpen, 
    theme, 
    setTheme, 
    language, 
    setLanguage,
    isLive,
    setIsLive,
    switchRole,
    openAddRole
  } = useAuth();

  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isRoleSelectorOpen, setIsRoleSelectorOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [hasDraft, setHasDraft] = useState(false);
  
  const notifRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  // Mock counts
  const messageCount = 3;
  const unreadNotifications = MOCK_NOTIFICATIONS.filter(n => !n.read).length;

  const availableRoles = user?.availableRoles ? user.availableRoles.filter(r => r !== user.role) : [];
  const isOrganizer = user && (user.role === 'Venue' || user.role === 'Agency');

  // Simple translation dictionary for TopBar
  const t = {
    EN: { create: 'Create Event', live: 'Live Now', search: 'Search events...', join: 'Join', login: 'Log In' },
    FR: { create: 'Créer Événement', live: 'En Direct', search: 'Rechercher...', join: 'Rejoindre', login: 'Connexion' },
    AR: { create: 'إنشاء حدث', live: 'مباشر الآن', search: 'بحث...', join: 'انضم', login: 'دخول' }
  }[language] || { create: 'Create Event', live: 'Live Now', search: 'Search events...', join: 'Join', login: 'Log In' };

  const isRTL = language === 'AR';

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    
    // Check Draft on Mount
    const checkDraft = () => {
        const draft = localStorage.getItem('booking_wizard_draft');
        if (draft) {
            try {
                const parsed = JSON.parse(draft);
                // Only consider it a valid draft if it has a title or date
                if (parsed.eventTitle || parsed.date) {
                    setHasDraft(true);
                } else {
                    setHasDraft(false);
                }
            } catch (e) { setHasDraft(false); }
        } else {
            setHasDraft(false);
        }
    };
    checkDraft();
    
    // Click outside handler
    const handleClickOutside = (event: MouseEvent) => {
        if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
            setIsNotificationsOpen(false);
        }
        if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
            setIsProfileMenuOpen(false);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
        window.removeEventListener('scroll', handleScroll);
        document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  useEffect(() => {
    if (!isProfileMenuOpen) {
        setIsRoleSelectorOpen(false);
    }
  }, [isProfileMenuOpen]);

  const handleCreateEventClick = () => {
    if (!user) {
      setAuthModalOpen(true);
      return;
    }
    onCreateEvent();
  };

  const handleBookTalentClick = () => {
    if (!user) {
        setAuthModalOpen(true);
        return;
    }
    onNavigate('booking-wizard');
  };

  const cycleLanguage = () => {
    const langs: ('EN' | 'FR' | 'AR')[] = ['EN', 'FR', 'AR'];
    const currentIndex = langs.indexOf(language);
    const nextIndex = (currentIndex + 1) % langs.length;
    setLanguage(langs[nextIndex]);
  };

  const handleRoleSwitch = (targetRole: Role) => {
      switchRole(targetRole);
      setIsProfileMenuOpen(false);
      setIsRoleSelectorOpen(false);
  };

  return (
    <header 
      className={`
        fixed top-0 right-0 left-0 z-[100] h-20 px-2 md:px-8 flex items-center justify-between transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)]
        ${sidebarExpanded ? 'md:left-64' : 'md:left-16'}
        left-0
        ${isScrolled 
            ? 'bg-white/60 dark:bg-[#121212]/60 backdrop-blur-xl border-b border-slate-200 dark:border-white/10 shadow-[0_4px_20px_rgba(0,0,0,0.03)] dark:shadow-lg' 
            : 'bg-transparent border-b border-transparent'
        }
        ${isRTL ? 'flex-row-reverse' : ''}
      `}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      
      {/* Left Group: Mobile Menu & Search */}
      <div className="flex items-center gap-4 flex-1">
        <button 
            onClick={onMenuClick}
            className="md:hidden p-2 text-slate-700 dark:text-white transition-all active:scale-95 hover:bg-slate-100 dark:hover:bg-white/5 rounded-xl"
            aria-label="Open Menu"
        >
            <PanelLeft className="w-6 h-6" />
        </button>

        <div className="hidden md:flex w-full max-w-sm lg:max-w-md" id="global-search">
            <div className="relative group w-full">
                <Search className={`absolute top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 dark:text-mid-text-subtle transition-colors group-focus-within:text-mid-primary ${isRTL ? 'right-4' : 'left-4'}`} />
                <input
                    type="text"
                    className={`w-full py-2.5 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-full text-[11px] font-medium text-slate-800 dark:text-white placeholder-slate-400 dark:placeholder-mid-text-subtle focus:outline-none focus:border-mid-primary/40 transition-all backdrop-blur-md shadow-sm hover:shadow-md ${isRTL ? 'pr-12 pl-6' : 'pl-12 pr-6'}`}
                    placeholder={t.search}
                />
            </div>
        </div>
      </div>

      {/* Right Side Actions */}
      <div className="flex items-center gap-1 sm:gap-2 md:gap-4 shrink-0">
        
        {/* Draft-Aware CTA Button */}
        <button 
          onClick={handleBookTalentClick}
          className={`
            cta-shimmer flex items-center justify-center text-white h-8 px-3 gap-1.5 md:px-5 md:py-2.5 rounded-full text-[9px] font-bold uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-glow-blue shrink-0
            ${hasDraft ? 'bg-mid-accent' : 'bg-mid-primary'}
          `}
        >
            {hasDraft ? <Play className="w-3.5 h-3.5 fill-current" /> : <Ticket className="w-3.5 h-3.5" />}
            <span className="whitespace-nowrap">{hasDraft ? 'Resume Booking' : 'Book Talent'}</span>
        </button>

        {/* Mobile Search Icon Trigger */}
        <button 
            className="md:hidden p-1 text-slate-500 dark:text-mid-text-subtle hover:text-slate-900 dark:hover:text-white transition-colors"
            aria-label="Search"
        >
            <Search className="w-5 h-5" />
        </button>

        {/* Language & Theme - Compact on Mobile */}
        <div className={`flex items-center gap-1 md:gap-2 ${isRTL ? 'border-r pr-1 md:pr-4' : 'border-l pl-1 md:pl-4'} border-slate-200 dark:border-white/10`}>
            <button 
              onClick={cycleLanguage}
              title={`Switch Language (${language})`}
              className="p-1 md:p-2 rounded-xl text-slate-500 dark:text-mid-text-muted hover:text-slate-900 dark:hover:text-white bg-transparent md:bg-white md:dark:bg-transparent hover:bg-slate-50 dark:hover:bg-white/5 border border-transparent transition-all flex items-center gap-1"
            >
                <Languages className="w-4 h-4" />
                <span className="text-[9px] font-bold hidden md:inline">{language}</span>
            </button>

            <button 
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-1 md:p-2 rounded-xl text-slate-500 dark:text-mid-text-muted hover:text-slate-900 dark:hover:text-white bg-transparent md:bg-white md:dark:bg-transparent hover:bg-slate-50 dark:hover:bg-white/5 border border-transparent transition-all shadow-none md:shadow-sm"
              aria-label="Toggle Theme"
            >
                {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
        </div>

        {/* User Menu - Compact on Mobile */}
        <div className={`flex items-center gap-1 md:gap-1 pl-0 md:pl-4 ${isRTL ? 'border-r pr-0 md:pr-4' : 'border-l pl-0 md:pl-4'} border-slate-200 dark:border-white/10`} id="user-menu">
            {user ? (
              <>
                <button 
                  onClick={() => onNavigate('messages')}
                  className="relative p-1 md:p-2 text-slate-500 dark:text-mid-text-subtle hover:text-slate-900 dark:hover:text-white transition-all group"
                  aria-label="Messages"
                >
                  <MessageSquare className="w-5 h-5" />
                  {messageCount > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 flex h-3.5 min-w-[14px] items-center justify-center rounded-full bg-mid-primary px-0.5 text-[8px] font-bold text-white border border-white dark:border-[#191919] group-hover:scale-110 transition-transform leading-none">
                      {messageCount}
                    </span>
                  )}
                </button>

                <div className="relative" ref={notifRef}>
                    <button 
                      onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                      className={`relative p-1 md:p-2 transition-all group ${isNotificationsOpen ? 'text-slate-900 dark:text-white' : 'text-slate-500 dark:text-mid-text-subtle hover:text-slate-900 dark:hover:text-white'}`}
                      aria-label="Notifications"
                    >
                      <Bell className="w-5 h-5" />
                      {unreadNotifications > 0 && (
                        <span className="absolute -top-0.5 -right-0.5 flex h-3.5 min-w-[14px] items-center justify-center rounded-full bg-red-500 px-0.5 text-[8px] font-bold text-white border border-white dark:border-[#191919] group-hover:scale-110 transition-transform leading-none">
                          {unreadNotifications}
                        </span>
                      )}
                    </button>

                    {/* Notifications Dropdown - Sized for Mobile */}
                    {isNotificationsOpen && (
                        <div className={`absolute top-full mt-3 w-[85vw] max-w-[320px] bg-white/70 dark:bg-[#191919]/70 border border-slate-200 dark:border-white/10 rounded-2xl shadow-2xl dark:shadow-glass-deep overflow-hidden backdrop-blur-3xl animate-in fade-in zoom-in-95 duration-200 z-[120] ${isRTL ? 'left-0' : 'right-0'}`}>
                            <div className="px-4 py-3 border-b border-slate-100 dark:border-white/5 flex items-center justify-between bg-slate-50/50 dark:bg-white/[0.02]">
                                <h4 className="text-[11px] font-bold uppercase tracking-widest text-slate-900 dark:text-white">Notifications</h4>
                                <button className="text-[9px] font-bold text-mid-primary hover:underline">Mark all read</button>
                            </div>
                            <div className="max-h-[300px] overflow-y-auto custom-scrollbar">
                                {MOCK_NOTIFICATIONS.map((notif) => (
                                    <div key={notif.id} className={`p-4 border-b border-slate-100 dark:border-white/5 hover:bg-slate-50 dark:hover:bg-white/[0.03] transition-colors cursor-pointer group relative ${!notif.read ? 'bg-mid-primary/[0.02]' : ''}`}>
                                        {!notif.read && (
                                            <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-mid-primary" />
                                        )}
                                        <div className="flex gap-3">
                                            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                                                notif.type === 'success' ? 'bg-green-500/10 text-green-500' :
                                                notif.type === 'alert' ? 'bg-red-500/10 text-red-500' :
                                                notif.type === 'message' ? 'bg-blue-500/10 text-blue-500' :
                                                'bg-slate-200 dark:bg-white/10 text-slate-500 dark:text-slate-400'
                                            }`}>
                                                {notif.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> :
                                                 notif.type === 'alert' ? <AlertTriangle className="w-4 h-4" /> :
                                                 notif.type === 'message' ? <MessageSquare className="w-4 h-4" /> :
                                                 <Bell className="w-4 h-4" />}
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <div className="flex justify-between items-start mb-0.5">
                                                    <h5 className={`text-xs font-bold truncate ${!notif.read ? 'text-slate-900 dark:text-white' : 'text-slate-600 dark:text-slate-300'}`}>{notif.title}</h5>
                                                    <span className="text-[9px] text-slate-400 whitespace-nowrap ml-2">{notif.time}</span>
                                                </div>
                                                <p className="text-[10px] text-slate-500 dark:text-mid-text-subtle line-clamp-2 leading-relaxed">{notif.message}</p>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <button className="w-full py-2.5 text-center text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                                View Activity Log
                            </button>
                        </div>
                    )}
                </div>

                <div className="relative ml-1" ref={profileRef}>
                  <button 
                    onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                    className="flex items-center gap-2 p-0.5 rounded-full border border-transparent hover:border-slate-200 dark:hover:border-white/10 transition-all"
                  >
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-mid-primary to-mid-accent p-[1px]">
                      <div className="w-full h-full rounded-full bg-slate-100 dark:bg-mid-bg flex items-center justify-center overflow-hidden">
                        {user.avatarUrl ? (
                          <img src={user.avatarUrl} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <User className="w-4 h-4 text-slate-700 dark:text-white" />
                        )}
                      </div>
                    </div>
                  </button>

                  {isProfileMenuOpen && (
                      <div className={`absolute top-full mt-3 w-64 bg-white/70 dark:bg-[#191919]/70 border border-slate-200 dark:border-white/10 rounded-2xl shadow-2xl dark:shadow-glass-deep overflow-hidden backdrop-blur-3xl animate-in fade-in zoom-in-95 duration-200 ${isRTL ? 'left-0' : 'right-0'}`}>
                        
                        <div className="p-4 border-b border-slate-100 dark:border-white/5 space-y-3">
                          <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-mid-primary/10 flex items-center justify-center shrink-0">
                                  <User className="w-5 h-5 text-mid-primary" />
                              </div>
                              <div className="flex flex-col overflow-hidden min-w-0 flex-1">
                                  <span className="text-xs font-bold text-slate-900 dark:text-white truncate">{user.name}</span>
                                  <span className="text-[9px] text-slate-500 uppercase tracking-widest truncate text-mid-primary">{user.role}</span>
                              </div>
                          </div>
                        </div>

                        {/* Moved Create Event Button Here - Only for Organizers */}
                        {isOrganizer && (
                            <div className="p-2 border-b border-slate-100 dark:border-white/5">
                                <button 
                                    id="create-event-btn-dropdown"
                                    onClick={() => { handleCreateEventClick(); setIsProfileMenuOpen(false); }}
                                    className="w-full flex items-center gap-3 px-3 py-2.5 bg-slate-900 text-white dark:bg-white dark:text-black rounded-xl hover:opacity-90 transition-all group shadow-lg"
                                >
                                    <div className="w-8 h-8 rounded-lg bg-white/20 dark:bg-black/10 flex items-center justify-center">
                                        <Plus className="w-4 h-4" />
                                    </div>
                                    <div className="flex flex-col items-start">
                                        <span className="text-[9px] font-bold uppercase tracking-widest leading-none mb-0.5 opacity-80">Host</span>
                                        <span className="text-[11px] font-bold leading-none">{t.create}</span>
                                    </div>
                                </button>
                            </div>
                        )}

                        <div className="p-2 border-b border-slate-100 dark:border-white/5">
                            <button 
                                onClick={() => { onNavigate('admin'); setIsProfileMenuOpen(false); }}
                                className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-slate-100 dark:hover:bg-white/5 rounded-xl transition-all group"
                            >
                                <div className="w-8 h-8 rounded-lg bg-slate-200 dark:bg-white/10 flex items-center justify-center group-hover:bg-slate-300 dark:group-hover:bg-white/20 transition-colors">
                                    <ShieldAlert className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                                </div>
                                <div className="flex flex-col items-start">
                                    <span className="text-[9px] font-bold uppercase tracking-widest leading-none mb-0.5 opacity-60">System</span>
                                    <span className="text-[11px] font-bold leading-none text-slate-900 dark:text-white">Admin Panel</span>
                                </div>
                            </button>
                        </div>

                        {availableRoles.length > 0 && (
                          <div className="p-2 border-b border-slate-100 dark:border-white/5">
                              {availableRoles.length === 1 ? (
                                  <button 
                                      onClick={() => handleRoleSwitch(availableRoles[0])}
                                      className="w-full flex items-center justify-between px-3 py-2.5 bg-mid-primary/5 hover:bg-mid-primary hover:text-white text-mid-primary rounded-xl transition-all group"
                                  >
                                      <div className="flex items-center gap-3">
                                          <div className="w-8 h-8 rounded-lg bg-white dark:bg-white/10 flex items-center justify-center group-hover:bg-white/20 shadow-sm dark:shadow-none">
                                            <ArrowLeftRight className="w-4 h-4" />
                                          </div>
                                          <div className="flex flex-col items-start">
                                              <span className="text-[9px] font-bold uppercase tracking-widest leading-none mb-0.5 opacity-80">Switch Profile</span>
                                              <span className="text-[11px] font-bold leading-none">{availableRoles[0]}</span>
                                          </div>
                                      </div>
                                      <ArrowRight className="w-3.5 h-3.5 opacity-50 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
                                  </button>
                              ) : (
                                  <div className="space-y-1">
                                      <button
                                          onClick={() => setIsRoleSelectorOpen(!isRoleSelectorOpen)}
                                          className={`
                                              w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all
                                              ${isRoleSelectorOpen 
                                                  ? 'bg-mid-primary/10 text-mid-primary' 
                                                  : 'bg-slate-50 dark:bg-white/5 text-slate-700 dark:text-mid-text-subtle hover:bg-slate-100 dark:hover:bg-white/10'}
                                          `}
                                      >
                                          <div className="flex items-center gap-3">
                                              <div className="w-8 h-8 rounded-lg bg-current opacity-10 flex items-center justify-center">
                                                <ArrowLeftRight className="w-4 h-4" />
                                              </div>
                                              <span className="text-[10px] font-bold uppercase tracking-widest">Switch Account</span>
                                          </div>
                                          <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-300 ${isRoleSelectorOpen ? 'rotate-180' : ''}`} />
                                      </button>

                                      {isRoleSelectorOpen && (
                                          <div className="pl-2 pr-1 space-y-1 animate-in fade-in slide-in-from-top-1">
                                              {availableRoles.map(role => (
                                                  <button
                                                      key={role}
                                                      onClick={() => handleRoleSwitch(role)}
                                                      className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-mid-primary hover:text-white text-slate-500 dark:text-mid-text-muted text-[10px] font-bold uppercase tracking-wider transition-all group ml-1"
                                                  >
                                                      <span className="pl-2 border-l-2 border-transparent group-hover:border-white/40">{role}</span>
                                                      <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                                                  </button>
                                              ))}
                                          </div>
                                      )}
                                  </div>
                              )}
                          </div>
                        )}
                        
                        <div className="px-2 pt-2">
                          <button
                              onClick={() => {
                                  setIsProfileMenuOpen(false);
                                  openAddRole();
                              }}
                              className="w-full flex items-center gap-3 px-3 py-2 rounded-xl border border-dashed border-slate-300 dark:border-white/20 text-slate-500 dark:text-mid-text-subtle hover:text-slate-900 dark:hover:text-white hover:border-slate-400 dark:hover:border-white/40 hover:bg-slate-50 dark:hover:bg-white/5 transition-all group"
                          >
                              <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-white/5 flex items-center justify-center group-hover:bg-slate-200 dark:group-hover:bg-white/10 transition-colors">
                                  <Plus className="w-4 h-4" />
                              </div>
                              <span className="text-[10px] font-bold uppercase tracking-widest">+ Add Role</span>
                          </button>
                        </div>

                        <div className="p-2">
                          <button onClick={() => { onNavigate('profile'); setIsProfileMenuOpen(false); }} className="w-full flex items-center gap-3 px-4 py-3 text-[10px] font-bold text-slate-600 dark:text-mid-text-muted hover:bg-slate-50 dark:hover:bg-white/5 rounded-xl transition-all">
                              <Settings className="w-4 h-4" /> Account Settings
                          </button>
                          <button onClick={() => { logout(); setIsProfileMenuOpen(false); }} className="w-full flex items-center gap-3 px-4 py-3 text-[10px] font-bold text-red-500 hover:bg-red-500/10 rounded-xl transition-all">
                              <LogOut className="w-4 h-4" /> Sign Out
                          </button>
                        </div>
                      </div>
                    )}
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2">
                 <button 
                  onClick={() => setAuthModalOpen(true)}
                  className="hidden sm:inline-block text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle hover:text-slate-900 dark:hover:text-white px-3 transition-colors"
                >
                  {t.login}
                </button>
                <button 
                  onClick={() => setAuthModalOpen(true)}
                  className="flex items-center gap-2 bg-slate-900 dark:bg-white text-white dark:text-black px-4 py-2 md:px-5 md:py-2.5 rounded-full text-[9px] font-bold uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-lg"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{t.join}</span>
                </button>
              </div>
            )}
        </div>
      </div>
    </header>
  );
};
