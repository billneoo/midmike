
import React, { useRef, useEffect, useState } from 'react';
import { Star, CheckCircle, Ticket, MapPin, Calendar, ArrowRight, Clock, Image as ImageIcon, ShoppingBasket, Heart, AlertCircle, Bookmark } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

// Refined OptimizedImage component with robust error handling and shimmer
export const OptimizedImage: React.FC<{ 
  src?: string; 
  alt: string; 
  className?: string; 
  containerClass?: string;
  fallbackInitials?: string;
}> = ({ src, alt, className, containerClass, fallbackInitials }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState(false);
  const [shouldLoad, setShouldLoad] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!src) {
      setError(true);
      return;
    }

    setIsLoaded(false);
    setError(false);

    if (typeof window === 'undefined' || !('IntersectionObserver' in window)) {
      setShouldLoad(true);
      return;
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          setShouldLoad(true);
          observer.disconnect();
        }
      });
    }, { rootMargin: '300px' });

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, [src]);

  return (
    <div ref={containerRef} className={`relative overflow-hidden bg-slate-200 dark:bg-mid-panel ${containerClass}`}>
      {/* Loading Shimmer State */}
      {!isLoaded && !error && (
        <div className="absolute inset-0 z-10">
          <div className="w-full h-full bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full animate-[shimmer_2s_infinite] bg-[length:200%_100%]" />
          <div className="absolute inset-0 flex items-center justify-center">
             <ImageIcon className="w-6 h-6 text-slate-400 dark:text-mid-text-subtle/20" />
          </div>
        </div>
      )}
      
      {/* Error / Fallback State */}
      {error ? (
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-mid-bg to-mid-panel z-10 p-4 text-center">
          {fallbackInitials ? (
            <span className="text-4xl font-tiempos font-bold text-mid-primary/30 uppercase select-none">{fallbackInitials.substring(0, 2)}</span>
          ) : (
            <AlertCircle className="w-6 h-6 text-mid-text-subtle/20" />
          )}
        </div>
      ) : (
        shouldLoad && (
          <img 
            src={src} 
            alt={alt} 
            loading="lazy"
            className={`${className} transition-all duration-700 ease-in-out ${isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-105'}`}
            onLoad={() => setIsLoaded(true)}
            onError={() => setError(true)}
          />
        )
      )}
    </div>
  );
};

interface CardProps {
  image?: string;
  title: string;
  subtitle?: string;
  badge?: string;
  price?: string | number;
  rating?: number;
  verified?: boolean;
  date?: string;
  location?: string;
  index?: number;
  variant?: 'featured-split' | 'portrait-action' | 'list-row' | 'compact';
  actionLabel?: string;
  onClick?: () => void;
  onBook?: () => void;
  tags?: string[];
  imageAspectRatio?: '3/4' | '16/9' | 'square';
  showBookingAction?: boolean;
  showLoveAction?: boolean;
  initialLovedCount?: number;
}

export const Card: React.FC<CardProps> = ({
  image,
  title,
  subtitle,
  badge,
  price,
  rating,
  verified,
  date,
  location,
  index,
  variant = 'portrait-action',
  actionLabel = 'View Details',
  onClick,
  onBook,
  imageAspectRatio = '3/4',
  showBookingAction = false,
  showLoveAction = false,
  initialLovedCount = 0
}) => {
  const parallaxRef = useRef<HTMLDivElement>(null);
  const { requireAuth } = useAuth();
  
  // Interactive State
  const [lovedCount, setLovedCount] = useState(initialLovedCount || Math.floor(Math.random() * 500) + 50);
  const [isLoved, setIsLoved] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    if (variant === 'featured-split' && window.innerWidth > 768) {
      const handleScroll = () => {
        if (parallaxRef.current) {
          const scrolled = window.scrollY;
          if (scrolled > 800) return;
          parallaxRef.current.style.transform = `translate3d(0, ${scrolled * 0.15}px, 0)`;
        }
      };
      window.addEventListener('scroll', handleScroll, { passive: true });
      return () => window.removeEventListener('scroll', handleScroll);
    }
  }, [variant]);
  
  const aspectClass = imageAspectRatio === '16/9' ? 'aspect-[16/9]' : imageAspectRatio === 'square' ? 'aspect-square' : 'aspect-[3/4]';

  const handleActionClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    requireAuth(() => {
      if (onClick) onClick();
      else alert(`Performing action: ${actionLabel} for ${title}`);
    });
  };

  const handleBookClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    requireAuth(() => {
      if (onBook) onBook();
      else alert(`Initiating booking for: ${title}`);
    });
  };

  const handleLoveClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsLoved(!isLoved);
    setLovedCount(prev => isLoved ? prev - 1 : prev + 1);
  };

  const handleSaveClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsSaved(!isSaved);
  };

  const CardActionsOverlay = () => (
    <div className="absolute top-2 right-2 z-20 flex flex-col gap-2">
        <button 
            onClick={handleLoveClick}
            className={`
                w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md transition-all duration-300 shadow-lg
                ${isLoved 
                    ? 'bg-pink-500 text-white' 
                    : 'bg-black/20 text-white hover:bg-white hover:text-pink-500'
                }
            `}
        >
            <Heart className={`w-4 h-4 ${isLoved ? 'fill-current' : ''}`} strokeWidth={2.5} />
        </button>
        <button 
            onClick={handleSaveClick}
            className={`
                w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md transition-all duration-300 shadow-lg
                ${isSaved 
                    ? 'bg-mid-primary text-white' 
                    : 'bg-black/20 text-white hover:bg-white hover:text-mid-primary'
                }
            `}
        >
            <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} strokeWidth={2.5} />
        </button>
    </div>
  );

  if (variant === 'featured-split') {
    return (
      <div 
        onClick={onClick}
        className="group relative w-full h-full rounded-[10px] overflow-hidden flex flex-col md:flex-row transition-all duration-700 cursor-pointer items-stretch featured-cinematic-layer hover:scale-[1.005] hover:shadow-glow-blue border border-transparent shadow-lg dark:shadow-none"
      >
        <style>{`
          @keyframes border-spin { to { --gradient-angle: 360deg; } }
          .featured-cinematic-layer { background: var(--card-bg); isolation: isolate; z-index: 0; }
          .featured-cinematic-layer::before {
            content: ''; position: absolute; inset: -4px;
            background: conic-gradient(from 0deg, #1d4ed8, #8484ff, transparent 50%, #1d4ed8);
            animation: border-spin 6s linear infinite; z-index: -2; filter: blur(10px); opacity: 0.8;
          }
          .featured-cinematic-layer::after {
            content: ''; position: absolute; inset: 0px; background: var(--card-bg);
            background-image: linear-gradient(90deg, transparent, rgba(132, 132, 255, 0.04), transparent);
            background-size: 200% 100%; border-radius: inherit; z-index: -1;
          }
        `}</style>

        <div className="w-full md:w-[60%] px-6 md:px-10 py-6 flex flex-col justify-center relative z-20 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-white via-white/80 to-transparent dark:from-mid-bg dark:via-mid-bg/60 -z-10 hidden md:block" />
            <div className="max-w-xl space-y-3">
                <div className="flex items-center gap-2">
                   <div className="px-3 py-1 bg-mid-accent/10 border border-mid-accent/20 text-mid-accent rounded-full flex items-center gap-2">
                        <span className="w-1.5 h-1.5 bg-mid-accent rounded-full animate-pulse shadow-glow-accent" />
                        <span className="text-[8px] font-inter font-bold tracking-[0.25em] uppercase">Spotlight</span>
                   </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center flex-wrap gap-x-4 gap-y-2">
                    <h1 className="text-3xl sm:text-4xl md:text-4xl lg:text-5xl font-tiempos font-normal text-slate-800 dark:text-white leading-[0.95] tracking-tighter drop-shadow-2xl">
                        {title}
                    </h1>
                  </div>
                  <p className="text-slate-500 dark:text-mid-text-muted text-[12px] leading-relaxed opacity-80 max-w-md font-inter line-clamp-2">{subtitle}</p>
                </div>
                <div className="flex flex-wrap gap-3 pt-1">
                    <button onClick={handleActionClick} className="flex items-center justify-center gap-2.5 bg-mid-primary text-white hover:bg-mid-primary/90 px-5 py-2 rounded-full text-[8px] font-inter font-bold tracking-[0.2em] uppercase transition-all duration-500 shadow-glow-blue hover:scale-[1.02]"><Ticket className="w-3.5 h-3.5" /> Tickets</button>
                    {showBookingAction && <button onClick={handleBookClick} className="flex items-center justify-center w-[36px] h-[36px] bg-slate-100 dark:bg-white/5 border border-transparent dark:border-white/10 text-mid-secondary hover:bg-mid-secondary hover:text-white hover:border-mid-secondary rounded-full transition-all duration-500 shadow-sm hover:shadow-glow-secondary"><ShoppingBasket className="w-3.5 h-3.5" /></button>}
                </div>
            </div>
        </div>
        <div className="relative z-20 w-full md:w-[40%] flex items-center justify-center p-[15px] md:p-[20px]">
            <div className="w-full aspect-square relative group-hover:scale-[1.02] transition-transform duration-700">
               <OptimizedImage src={image} alt={title} fallbackInitials={title} containerClass="w-full h-full rounded-[10px] shadow-2xl" className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" />
               <CardActionsOverlay />
            </div>
        </div>
      </div>
    );
  }

  if (variant === 'list-row') {
    return (
      <div onClick={onClick} className="group relative z-0 hover:z-10 flex items-center gap-4 px-3 py-2 w-full h-full rounded-[12px] border border-slate-200 dark:border-white/5 bg-white dark:bg-[#191919]/80 hover:bg-white dark:hover:bg-[#202022] transition-all duration-500 cursor-pointer shadow-[0_2px_8px_rgba(0,0,0,0.04)] hover:-translate-y-[2px]">
        <div className="flex items-center justify-center w-3 text-[9px] font-inter font-bold text-slate-400 dark:text-mid-text-subtle group-hover:text-mid-accent transition-colors opacity-30 group-hover:opacity-100">{index ? `0${index}` : '--'}</div>
        <OptimizedImage src={image} alt={title} fallbackInitials={title} containerClass="h-12 w-12 md:h-14 md:w-14 aspect-square rounded-[10px] flex-shrink-0" className="h-full w-full object-cover group-hover:scale-110 transition-all" />
        <div className="flex-1 min-w-0 flex flex-col justify-center gap-0.5">
           <div className="flex items-center gap-2 mb-0.5">
               <div className="px-1.5 py-0.5 bg-mid-accent/10 border border-mid-accent/20 text-mid-accent rounded-full flex items-center gap-1.5 scale-[0.75] origin-left shadow-glow-accent/10">
                    <span className="text-[7px] font-inter font-bold tracking-[0.1em] uppercase">{badge}</span>
               </div>
               {verified && <CheckCircle className="w-2.5 h-2.5 text-mid-secondary fill-current" />}
           </div>
           <h4 className="text-slate-800 dark:text-white font-tiempos font-normal text-[16px] truncate group-hover:text-mid-accent transition-colors tracking-tight leading-tight">{title}</h4>
        </div>
        <div className="flex items-center gap-2">
            <button onClick={handleLoveClick} className={`p-1.5 rounded-full transition-colors ${isLoved ? 'text-pink-500' : 'text-slate-300 hover:text-pink-400'}`}>
                <Heart className={`w-4 h-4 ${isLoved ? 'fill-current' : ''}`} />
            </button>
            <button onClick={handleActionClick} className="w-7 h-7 rounded-full border border-slate-200 dark:border-white/10 flex items-center justify-center text-slate-400 group-hover:text-white group-hover:bg-mid-primary transition-all duration-300"><ArrowRight className="w-3.5 h-3.5" /></button>
        </div>
      </div>
    );
  }

  if (variant === 'portrait-action') {
    return (
        <div onClick={onClick} className="group relative z-0 hover:z-10 flex flex-col h-full bg-white dark:bg-[#222224] border border-slate-200 dark:border-white/[0.08] rounded-[16px] overflow-hidden transition-all duration-500 cursor-pointer shadow-[0_2px_8px_rgba(0,0,0,0.04)] hover:-translate-y-2">
          
          {/* Image Section */}
          <div className={`relative ${aspectClass} w-full overflow-hidden flex-shrink-0`}>
            <OptimizedImage src={image} alt={title} fallbackInitials={title} containerClass="w-full h-full" className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" />
            
            {/* Top Left Badges */}
            <div className="absolute top-2 left-2 flex flex-col gap-1 items-start">
                {badge && <span className="px-2 py-1 text-[8px] font-inter font-bold text-white bg-black/40 backdrop-blur-md rounded-full uppercase tracking-wider">{badge}</span>}
            </div>

            {/* Actions Top Right */}
            <CardActionsOverlay />

            {/* Verified Badge */}
            {verified && <div className="absolute bottom-2 right-2 bg-mid-secondary text-white p-1 rounded-full shadow-lg"><CheckCircle className="w-3 h-3" /></div>}
          </div>

          {/* Content Section */}
          <div className="p-5 flex flex-col flex-grow relative">
            
            {/* Header Row: Title + Rating */}
            <div className="flex justify-between items-start gap-2 mb-1">
                 <div className="flex flex-col gap-0.5 min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                       <h3 className="text-lg md:text-xl font-tiempos font-medium text-slate-900 dark:text-white leading-tight group-hover:text-mid-accent transition-colors line-clamp-2">{title}</h3>
                    </div>
                 </div>
                 {rating && (
                   <div className="flex items-center gap-1 bg-slate-100 dark:bg-white/10 px-2 py-1 rounded text-xs font-bold text-slate-700 dark:text-white shrink-0">
                     <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" /> 
                     {rating}
                   </div>
                 )}
            </div>

            {/* Subtitle (Profession/Category) */}
            {subtitle && (
                <div className="text-sm font-medium text-slate-500 dark:text-mid-text-subtle mb-1 line-clamp-1">{subtitle}</div>
            )}

            {/* Location Line */}
            {location && (
                <div className="flex items-center gap-1 text-xs text-slate-400 dark:text-mid-text-muted mb-4">
                    <MapPin className="w-3 h-3" />
                    <span className="truncate">{location}</span>
                </div>
            )}
            
            {/* Spacer if no location to push buttons down */}
            {!location && <div className="mt-auto"></div>}

            {/* Footer: Big Buttons */}
            <div className="mt-3 flex items-center gap-2 pt-0">
              <button onClick={handleActionClick} className="flex-1 py-3 rounded-xl bg-slate-5 dark:bg-white/[0.04] text-[10px] font-inter font-bold text-slate-700 dark:text-white group-hover:bg-mid-primary group-hover:text-white transition-all uppercase tracking-widest shadow-sm">{actionLabel}</button>
              {showBookingAction && <button onClick={handleBookClick} className="w-[42px] h-[42px] flex items-center justify-center rounded-xl bg-slate-5 dark:bg-white/[0.04] text-mid-secondary hover:bg-mid-secondary hover:text-white transition-all shadow-sm"><ShoppingBasket className="w-4 h-4" /></button>}
            </div>
          </div>
        </div>
    );
  }
  return null;
};
