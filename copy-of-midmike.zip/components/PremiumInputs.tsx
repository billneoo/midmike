
import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Calendar, Clock } from 'lucide-react';

interface Option {
  value: string;
  label: string;
}

interface SelectProps {
  options: (string | Option)[];
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  label?: string;
  className?: string;
  icon?: any;
}

export const PremiumSelect: React.FC<SelectProps> = ({ 
  options, value, onChange, placeholder = "Select", label, className = "", icon: Icon 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getLabel = (opt: string | Option) => typeof opt === 'string' ? opt : opt.label;
  const getValue = (opt: string | Option) => typeof opt === 'string' ? opt : opt.value;

  const displayValue = value 
    ? getLabel(options.find(o => getValue(o) === value) || value)
    : placeholder;

  return (
    <div className={`relative ${className}`} ref={containerRef}>
      {label && <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle mb-2 block">{label}</label>}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`
            w-full flex items-center justify-between px-4 py-3.5 
            bg-white dark:bg-white/[0.03] border transition-all duration-300 rounded-xl
            ${isOpen 
                ? 'border-mid-primary ring-1 ring-mid-primary/50 shadow-glow-blue' 
                : 'border-slate-200 dark:border-white/10 hover:border-slate-300 dark:hover:border-white/20 hover:bg-slate-50 dark:hover:bg-white/[0.05]'
            }
        `}
      >
        <div className="flex items-center gap-3 overflow-hidden">
            {Icon && <Icon className={`w-4 h-4 ${value ? 'text-mid-primary' : 'text-slate-400'}`} />}
            <span className={`text-xs font-bold truncate ${value ? 'text-slate-900 dark:text-white' : 'text-slate-400'}`}>
                {displayValue}
            </span>
        </div>
        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-300 flex-shrink-0 ${isOpen ? 'rotate-180 text-mid-primary' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-2 z-50 bg-white dark:bg-[#1a1a1a] border border-slate-200 dark:border-white/10 rounded-xl shadow-2xl max-h-60 overflow-y-auto custom-scrollbar animate-in fade-in zoom-in-95 origin-top p-1">
          {options.map((opt, idx) => {
            const optVal = getValue(opt);
            const optLabel = getLabel(opt);
            const isSelected = value === optVal;
            return (
              <button
                key={idx}
                type="button"
                onClick={() => { onChange(optVal); setIsOpen(false); }}
                className={`
                    w-full text-left px-4 py-2.5 text-xs font-medium rounded-lg transition-colors
                    ${isSelected 
                        ? 'bg-mid-primary text-white font-bold' 
                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5'
                    }
                `}
              >
                {optLabel}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};

export const PremiumDateSelect: React.FC<{ value: string; onChange: (val: string) => void; label?: string }> = ({ value, onChange, label }) => {
    // value format YYYY-MM-DD
    const [year, month, day] = value ? value.split('-') : ['', '', ''];
    
    const currentYear = new Date().getFullYear();
    const years = Array.from({ length: 5 }, (_, i) => (currentYear + i).toString());
    const months = [
        { value: '01', label: 'Jan' }, { value: '02', label: 'Feb' }, { value: '03', label: 'Mar' }, 
        { value: '04', label: 'Apr' }, { value: '05', label: 'May' }, { value: '06', label: 'Jun' },
        { value: '07', label: 'Jul' }, { value: '08', label: 'Aug' }, { value: '09', label: 'Sep' }, 
        { value: '10', label: 'Oct' }, { value: '11', label: 'Nov' }, { value: '12', label: 'Dec' }
    ];
    const days = Array.from({ length: 31 }, (_, i) => (i + 1).toString().padStart(2, '0'));

    const updateDate = (type: 'y' | 'm' | 'd', val: string) => {
        let newY = type === 'y' ? val : (year || currentYear.toString());
        let newM = type === 'm' ? val : (month || '01');
        let newD = type === 'd' ? val : (day || '01');
        onChange(`${newY}-${newM}-${newD}`);
    }

    return (
        <div className="space-y-2">
            {label && <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle mb-2 block">{label}</label>}
            <div className="flex gap-2">
                <div className="w-[80px]">
                    <PremiumSelect options={days} value={day} onChange={v => updateDate('d', v)} placeholder="DD" />
                </div>
                <div className="flex-1">
                    <PremiumSelect options={months} value={month} onChange={v => updateDate('m', v)} placeholder="Month" />
                </div>
                <div className="w-[90px]">
                    <PremiumSelect options={years} value={year} onChange={v => updateDate('y', v)} placeholder="Year" />
                </div>
            </div>
        </div>
    );
};

export const PremiumTimeSelect: React.FC<{ value: string; onChange: (val: string) => void; label?: string }> = ({ value, onChange, label }) => {
    // Generate time slots
    const slots = [];
    for (let i = 0; i < 24; i++) {
        for (let j = 0; j < 60; j += 30) {
            const h = i.toString().padStart(2, '0');
            const m = j.toString().padStart(2, '0');
            const period = i < 12 ? 'AM' : 'PM';
            const displayH = i === 0 ? 12 : i > 12 ? i - 12 : i;
            slots.push({ value: `${h}:${m}`, label: `${displayH}:${m} ${period}` });
        }
    }

    return (
        <PremiumSelect 
            label={label}
            options={slots} 
            value={value} 
            onChange={onChange} 
            placeholder="--:--" 
            icon={Clock}
        />
    );
};
