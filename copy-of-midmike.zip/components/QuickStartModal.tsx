
import React from 'react';
import { Modal } from './Modal';
import { Play, Zap, ArrowRight, Monitor, Mic2, Calendar, User } from 'lucide-react';
import { useTour } from '../contexts/TourContext';

interface QuickStartModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const TUTORIALS = [
    {
        id: 1,
        title: "Creating Your First Event",
        duration: "2:15",
        category: "Basics",
        thumbnail: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?q=80&w=400&auto=format&fit=crop",
        icon: Calendar
    },
    {
        id: 2,
        title: "Managing Professional Roles",
        duration: "1:45",
        category: "Profile",
        thumbnail: "https://images.unsplash.com/photo-1551818255-e6e10975bc17?q=80&w=400&auto=format&fit=crop",
        icon: User
    },
    {
        id: 3,
        title: "Booking Artists & Techs",
        duration: "3:20",
        category: "Pro Tools",
        thumbnail: "https://images.unsplash.com/photo-1598387993441-a364f854c3e1?q=80&w=400&auto=format&fit=crop",
        icon: Mic2
    },
    {
        id: 4,
        title: "Using the Studio Booking System",
        duration: "1:30",
        category: "Services",
        thumbnail: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=400&auto=format&fit=crop",
        icon: Monitor
    }
];

export const QuickStartModal: React.FC<QuickStartModalProps> = ({ isOpen, onClose }) => {
  const { startTour } = useTour();

  const handleStartTour = () => {
      onClose();
      // Slight delay to allow modal close animation
      setTimeout(() => {
          startTour();
      }, 300);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Help & Resources">
      <div className="p-5 md:p-8 space-y-6 md:space-y-8 pb-8">
        
        {/* Interactive Tour CTA */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-mid-primary via-blue-600 to-mid-primary p-[1px]">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20 mix-blend-overlay"></div>
            <div className="relative bg-[#121212] rounded-[15px] p-5 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="space-y-3 text-center md:text-left w-full">
                    <div className="flex items-center justify-center md:justify-start gap-2 text-mid-highlight">
                        <Zap className="w-4 h-4 md:w-5 md:h-5 fill-current animate-pulse" />
                        <span className="text-[10px] font-bold uppercase tracking-widest">New to MidMike?</span>
                    </div>
                    <h3 className="text-xl md:text-2xl font-tiempos font-normal text-white">Take the Interactive Tour</h3>
                    <p className="text-xs md:text-sm text-slate-400 max-w-md mx-auto md:mx-0 leading-relaxed">
                        Let us guide you through the interface. We'll highlight key features like the Event Creator, Search, and Profile tools directly on your screen.
                    </p>
                </div>
                <button 
                    onClick={handleStartTour}
                    className="w-full md:w-auto shrink-0 px-6 py-3.5 bg-white text-black hover:bg-mid-highlight transition-all duration-300 rounded-full font-bold text-[10px] md:text-xs uppercase tracking-[0.2em] shadow-lg hover:scale-105 active:scale-95 flex items-center justify-center gap-3"
                >
                    Start Tour <ArrowRight className="w-4 h-4" />
                </button>
            </div>
        </div>

        {/* Video Tutorials Grid */}
        <div className="space-y-4">
            <div className="flex items-center justify-between px-1">
                <h4 className="text-xs md:text-sm font-bold text-white uppercase tracking-widest flex items-center gap-2">
                    <Monitor className="w-4 h-4 text-mid-secondary" />
                    Video Tutorials
                </h4>
                {/* View All Button Removed */}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {TUTORIALS.map((video) => (
                    <div key={video.id} className="group relative bg-white/[0.02] border border-white/5 hover:border-white/20 rounded-xl overflow-hidden transition-all duration-300 cursor-pointer block">
                        {/* Thumbnail - Always 16:9 Aspect Video on all devices */}
                        <div className="relative w-full aspect-video overflow-hidden shrink-0">
                            <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-80 group-hover:opacity-100" />
                            <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 shadow-lg">
                                    <Play className="w-4 h-4 text-white fill-current ml-0.5" />
                                </div>
                            </div>
                            <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/80 rounded text-[9px] font-bold text-white uppercase tracking-wider">
                                {video.duration}
                            </div>
                        </div>
                        <div className="p-4 w-full">
                            <div className="flex items-start gap-3">
                                <div className="p-2 rounded-lg bg-white/5 border border-white/5 text-mid-text-subtle group-hover:text-white transition-colors shrink-0">
                                    <video.icon className="w-4 h-4" />
                                </div>
                                <div className="min-w-0">
                                    <span className="text-[9px] font-bold text-mid-primary uppercase tracking-wider block mb-1">{video.category}</span>
                                    <h5 className="text-sm font-bold text-white leading-tight group-hover:text-mid-highlight transition-colors">{video.title}</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>

      </div>
    </Modal>
  );
};
