
import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, Upload, Check, Camera, MapPin, Globe, 
  DollarSign, Calendar, Clock, ShieldCheck, AlertCircle,
  Instagram, Youtube, Briefcase, LayoutGrid, Monitor,
  Music, Mic2, Users, Sparkles, CloudLightning, Mic,
  Coffee, Shield, Truck, Utensils, Flag
} from 'lucide-react';
import { Role } from '../types';

interface RoleOnboardingProps {
  role: Role;
  onBack: () => void;
  onComplete: (data: any) => void;
  initialData: { name: string; email: string; phone: string };
}

// --- Configuration Data ---

const TECH_ROLES = [
  { id: 'sound_tech', label: 'Sound Technician', icon: Music },
  { id: 'light_tech', label: 'Lighting Technician', icon: CloudLightning },
  { id: 'display_tech', label: 'Display/Video Tech', icon: Monitor },
  { id: 'photographer', label: 'Photographer', icon: Camera },
  { id: 'videographer', label: 'Videographer', icon: Camera },
  { id: 'catering', label: 'Catering', icon: Coffee },
  { id: 'security', label: 'Security', icon: Shield },
  { id: 'server', label: 'Server/Waiter', icon: Utensils },
  { id: 'bartender', label: 'Bartender', icon: Utensils },
  { id: 'decorator', label: 'Decorator', icon: Sparkles },
  { id: 'host', label: 'Host/Hostess', icon: Flag },
  { id: 'other', label: 'Other', icon: Briefcase },
];

const VENUE_TYPES = [
  { id: 'hotel', label: 'Hotel' },
  { id: 'lounge', label: 'Lounge' },
  { id: 'bar', label: 'Bar' },
  { id: 'concert_hall', label: 'Concert Hall' },
  { id: 'multi_use', label: 'Multi-use Space' },
];

const AGENCY_SERVICES = [
  { id: 'production', label: 'Production & Organization', description: 'Turnkey events, Logistics, Planning' },
  { id: 'booking', label: 'Animation & Booking', description: 'Artists, DJs, Hosts, Performers' },
  { id: 'technical', label: 'Technical Services', description: 'Sound, Light, Stage, Screens' },
  { id: 'av', label: 'Audiovisual & Content', description: 'Video, Streaming, Photography' },
  { id: 'decor', label: 'Decor & Ambiance', description: 'Scenography, Furniture, Floral' },
  { id: 'catering', label: 'Catering & Drinks', description: 'Food, Bar, Buffet' },
  { id: 'corporate', label: 'Corporate Services', description: 'Seminars, Launches, Stands' },
  { id: 'comms', label: 'Marketing & Comms', description: 'Visuals, Social Media, PR' },
  { id: 'security', label: 'Security & Logistics', description: 'Guards, Access Control, Transport' },
  { id: 'other', label: 'Other Services', description: 'Kids, VR, Fireworks' },
];

// --- Helper Components ---

const StepHeader = ({ title, subtitle, step, total }: { title: string, subtitle: string, step: number, total: number }) => (
  <div className="text-center space-y-2 mb-8">
    <div className="flex justify-center mb-4">
        <div className="flex gap-2">
            {Array.from({ length: total }).map((_, i) => (
                <div key={i} className={`h-1 rounded-full transition-all duration-500 ${i <= step ? 'w-8 bg-mid-primary' : 'w-4 bg-slate-200 dark:bg-white/10'}`} />
            ))}
        </div>
    </div>
    <h3 className="text-2xl font-tiempos font-normal text-slate-900 dark:text-white">{title}</h3>
    <p className="text-xs text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">{subtitle}</p>
  </div>
);

const InputGroup = ({ label, children, error }: { label: string, children?: React.ReactNode, error?: string }) => (
  <div className="space-y-2">
    <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">{label}</label>
    {children}
    {error && <span className="text-[9px] text-red-500 font-medium">{error}</span>}
  </div>
);

const TextInput = ({ ...props }: React.InputHTMLAttributes<HTMLInputElement>) => (
  <input 
    className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm text-slate-900 dark:text-white focus:border-mid-primary/50 focus:outline-none transition-all placeholder-slate-400 dark:placeholder-white/20"
    {...props}
  />
);

// --- Main Component ---

export const RoleOnboarding: React.FC<RoleOnboardingProps> = ({ role, onBack, onComplete, initialData }) => {
  // Determine Flow based on Role
  const flowType = role === 'Venue' ? 'venue' : role === 'Agency' ? 'agency' : 'technician';
  
  const [step, setStep] = useState(0);
  const [data, setData] = useState<any>({
    // Shared
    name: initialData.name || '',
    email: initialData.email || '',
    phone: initialData.phone || '',
    desc: '',
    website: '',
    address: '',
    city: '',
    country: 'Tunisia',
    logo: null,
    legalId: '',
    
    // Tech Specific
    subRole: '',
    specialties: [] as string[],
    hasEquipment: false,
    equipmentDesc: '',
    priceRange: '',
    billingMode: '',
    
    // Venue Specific
    venueType: '',
    capacity: '',
    venueServices: [] as string[],
    
    // Agency Specific
    agencyServices: [] as string[],
    
    // Media & Terms
    gallery: [],
    termsAccepted: false,
    gdprAccepted: false,
    certified: false,
  });

  // Define Steps based on Flow
  const getSteps = () => {
    if (flowType === 'technician') return 7;
    if (flowType === 'venue') return 7;
    if (flowType === 'agency') return 7;
    return 5;
  };
  
  const totalSteps = getSteps();

  const handleNext = () => {
    if (step < totalSteps - 1) setStep(s => s + 1);
    else onComplete(data);
  };

  const updateData = (key: string, value: any) => {
    setData((prev: any) => ({ ...prev, [key]: value }));
  };

  const toggleItem = (listKey: string, item: string) => {
    setData((prev: any) => {
        const list = prev[listKey] || [];
        return {
            ...prev,
            [listKey]: list.includes(item) ? list.filter((i: string) => i !== item) : [...list, item]
        };
    });
  };

  // --- Render Steps ---

  const renderContent = () => {
    // --- TECHNICIAN / PROVIDER FLOW ---
    if (flowType === 'technician') {
        switch(step) {
            case 0: return (
                <div className="space-y-6 animate-cinematic-fade">
                    <div className="grid grid-cols-2 gap-3">
                        {TECH_ROLES.map(r => (
                            <button key={r.id} onClick={() => updateData('subRole', r.id)} className={`p-4 rounded-xl border flex flex-col items-center gap-2 transition-all ${data.subRole === r.id ? 'bg-mid-primary/20 border-mid-primary text-slate-900 dark:text-white' : 'bg-white dark:bg-white/[0.02] border-slate-200 dark:border-white/5 text-slate-500 dark:text-mid-text-subtle hover:bg-slate-50 dark:hover:bg-white/5'}`}>
                                <r.icon className="w-5 h-5" />
                                <span className="text-[10px] font-bold uppercase tracking-wide text-center">{r.label}</span>
                            </button>
                        ))}
                    </div>
                    <InputGroup label="Full Name / Stage Name *">
                        <TextInput value={data.name} onChange={e => updateData('name', e.target.value)} />
                    </InputGroup>
                    <InputGroup label="Short Bio (Max 200 chars) *">
                        <textarea value={data.desc} onChange={e => updateData('desc', e.target.value)} maxLength={200} className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm text-slate-900 dark:text-white focus:outline-none h-24 resize-none" />
                    </InputGroup>
                </div>
            );
            case 1: return (
                <div className="space-y-6 animate-cinematic-fade">
                    <div className="p-4 rounded-xl bg-mid-primary/10 border border-mid-primary/20 flex gap-3">
                        <ShieldCheck className="w-5 h-5 text-mid-primary shrink-0" />
                        <p className="text-[10px] text-slate-600 dark:text-mid-text-subtle">Your email and phone are kept private and only shared upon confirmed booking.</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <InputGroup label="Pro Email *"><TextInput type="email" value={data.email} onChange={e => updateData('email', e.target.value)} /></InputGroup>
                        <InputGroup label="Phone *"><TextInput type="tel" value={data.phone} onChange={e => updateData('phone', e.target.value)} /></InputGroup>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <InputGroup label="Country *"><TextInput value={data.country} readOnly /></InputGroup>
                        <InputGroup label="City *"><TextInput value={data.city} onChange={e => updateData('city', e.target.value)} /></InputGroup>
                    </div>
                    <InputGroup label="Portfolio / Website"><TextInput value={data.website} onChange={e => updateData('website', e.target.value)} placeholder="https://" /></InputGroup>
                </div>
            );
            case 2: return (
                <div className="space-y-6 animate-cinematic-fade">
                    <InputGroup label="Specialties / Skills (Tags) *">
                        <TextInput placeholder="e.g. Sound Mixing, Cable Management, 4K Video..." onBlur={e => e.target.value && toggleItem('specialties', e.target.value)} />
                        <div className="flex flex-wrap gap-2 mt-2">
                            {data.specialties.map((s: string) => (
                                <span key={s} className="px-3 py-1 bg-mid-accent/10 border border-mid-accent/20 rounded-full text-[10px] text-mid-accent flex items-center gap-1">
                                    {s} <button onClick={() => toggleItem('specialties', s)}><ArrowLeft className="w-2 h-2 rotate-180" /></button>
                                </span>
                            ))}
                        </div>
                    </InputGroup>
                    <div className="bg-slate-50 dark:bg-white/[0.03] p-4 rounded-xl border border-slate-200 dark:border-white/5">
                        <label className="flex items-center gap-3 cursor-pointer mb-3">
                            <input type="checkbox" checked={data.hasEquipment} onChange={e => updateData('hasEquipment', e.target.checked)} className="accent-mid-primary" />
                            <span className="text-sm font-medium text-slate-900 dark:text-white">I have my own equipment</span>
                        </label>
                        {data.hasEquipment && (
                            <textarea value={data.equipmentDesc} onChange={e => updateData('equipmentDesc', e.target.value)} placeholder="List your gear..." className="w-full bg-white dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-xl p-3 text-xs text-slate-900 dark:text-white h-20" />
                        )}
                    </div>
                </div>
            );
            case 3: return (
                <div className="space-y-6 animate-cinematic-fade">
                    <InputGroup label="Price Range *">
                        <div className="grid grid-cols-3 gap-3">
                            {['< 300 €', '300 - 800 €', '> 800 €'].map(p => (
                                <button key={p} onClick={() => updateData('priceRange', p)} className={`py-3 rounded-xl border text-xs font-bold ${data.priceRange === p ? 'bg-mid-primary text-white border-mid-primary' : 'bg-white dark:bg-white/[0.02] border-slate-200 dark:border-white/5 text-slate-500 dark:text-mid-text-subtle'}`}>{p}</button>
                            ))}
                        </div>
                    </InputGroup>
                    <InputGroup label="Billing Mode *">
                        <div className="grid grid-cols-3 gap-3">
                            {['Flat Rate', 'Hourly', '% Fee'].map(m => (
                                <button key={m} onClick={() => updateData('billingMode', m)} className={`py-3 rounded-xl border text-xs font-bold ${data.billingMode === m ? 'bg-mid-primary text-white border-mid-primary' : 'bg-white dark:bg-white/[0.02] border-slate-200 dark:border-white/5 text-slate-500 dark:text-mid-text-subtle'}`}>{m}</button>
                            ))}
                        </div>
                    </InputGroup>
                    <InputGroup label="Cancellation Policy / Deposit"><textarea className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl p-3 text-sm text-slate-900 dark:text-white h-24" placeholder="e.g. 30% deposit upfront..." /></InputGroup>
                </div>
            );
            case 4: return (
                <div className="space-y-6 animate-cinematic-fade text-center py-10">
                    <div className="border-2 border-dashed border-slate-300 dark:border-white/10 rounded-2xl p-10 hover:bg-slate-50 dark:hover:bg-white/[0.02] transition-colors cursor-pointer">
                        <Upload className="w-8 h-8 text-slate-400 dark:text-mid-text-subtle mx-auto mb-4" />
                        <h4 className="text-slate-900 dark:text-white font-bold text-sm">Upload Portfolio</h4>
                        <p className="text-slate-500 dark:text-mid-text-subtle text-xs mt-2">Upload 3 to 5 photos or a demo video to showcase your work.</p>
                    </div>
                </div>
            );
            case 5: return (
                <div className="space-y-6 animate-cinematic-fade">
                    <div className="grid grid-cols-7 gap-2">
                        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(d => (
                            <div key={d} className="aspect-square rounded-lg bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/5 flex flex-col items-center justify-center cursor-pointer hover:bg-mid-primary/20">
                                <span className="text-[10px] font-bold text-slate-500 dark:text-mid-text-subtle">{d}</span>
                                <div className="w-1.5 h-1.5 rounded-full bg-green-500 mt-1" />
                            </div>
                        ))}
                    </div>
                    <p className="text-center text-xs text-slate-500 dark:text-mid-text-subtle">Select your typical availability (Mock Calendar)</p>
                </div>
            );
            case 6: return (
                <div className="space-y-6 animate-cinematic-fade">
                    <div className="p-6 bg-slate-100 dark:bg-mid-surface border border-slate-200 dark:border-white/5 rounded-2xl space-y-4">
                        <label className="flex gap-3 cursor-pointer">
                            <input type="checkbox" checked={data.termsAccepted} onChange={e => updateData('termsAccepted', e.target.checked)} className="mt-1 accent-mid-primary" />
                            <span className="text-xs text-slate-600 dark:text-mid-text-muted">I accept the Terms of Service and Quality Charter.</span>
                        </label>
                        <label className="flex gap-3 cursor-pointer">
                            <input type="checkbox" checked={data.certified} onChange={e => updateData('certified', e.target.checked)} className="mt-1 accent-mid-primary" />
                            <span className="text-xs text-slate-600 dark:text-mid-text-muted">I certify that the information provided is accurate and true.</span>
                        </label>
                    </div>
                </div>
            );
        }
    }

    // --- VENUE FLOW ---
    if (flowType === 'venue') {
        switch(step) {
            case 0: return (
                <div className="space-y-6 animate-cinematic-fade">
                    <InputGroup label="Venue Name *"><TextInput value={data.name} onChange={e => updateData('name', e.target.value)} /></InputGroup>
                    <div className="flex items-center gap-4 p-4 border border-slate-200 dark:border-white/10 rounded-xl bg-slate-50 dark:bg-white/[0.02]">
                        <div className="w-12 h-12 bg-slate-200 dark:bg-white/10 rounded-lg flex items-center justify-center"><Camera className="w-5 h-5 text-slate-500 dark:text-white" /></div>
                        <button className="text-xs font-bold uppercase text-mid-primary">Upload Logo/Photo</button>
                    </div>
                    <InputGroup label="Short Description *"><textarea value={data.desc} onChange={e => updateData('desc', e.target.value)} className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl p-3 text-sm text-slate-900 dark:text-white h-24" /></InputGroup>
                </div>
            );
            case 1: return (
                <div className="space-y-6 animate-cinematic-fade">
                    <div className="grid grid-cols-2 gap-4">
                        <InputGroup label="Pro Email *"><TextInput type="email" value={data.email} onChange={e => updateData('email', e.target.value)} /></InputGroup>
                        <InputGroup label="Phone *"><TextInput type="tel" value={data.phone} onChange={e => updateData('phone', e.target.value)} /></InputGroup>
                    </div>
                    <InputGroup label="Full Address *"><TextInput value={data.address} onChange={e => updateData('address', e.target.value)} placeholder="Street, Zip, City" /></InputGroup>
                    <div className="h-32 bg-slate-100 dark:bg-white/[0.05] rounded-xl flex items-center justify-center text-xs text-slate-400 dark:text-mid-text-subtle">[Map Preview]</div>
                </div>
            );
            case 2: return (
                <div className="space-y-6 animate-cinematic-fade">
                    <InputGroup label="Venue Type *">
                        <div className="grid grid-cols-2 gap-3">
                            {VENUE_TYPES.map(t => (
                                <button key={t.id} onClick={() => updateData('venueType', t.id)} className={`p-3 rounded-xl border text-xs font-bold ${data.venueType === t.id ? 'bg-mid-primary text-white border-mid-primary' : 'bg-white dark:bg-white/[0.02] border-slate-200 dark:border-white/5 text-slate-500 dark:text-mid-text-subtle'}`}>{t.label}</button>
                            ))}
                        </div>
                    </InputGroup>
                    <InputGroup label="Capacity (Pax) *"><TextInput type="number" value={data.capacity} onChange={e => updateData('capacity', e.target.value)} /></InputGroup>
                    <InputGroup label="Services Available">
                        <div className="flex flex-wrap gap-2">
                            {['Sound', 'Light', 'Catering', 'Lodging', 'Security'].map(s => (
                                <button key={s} onClick={() => toggleItem('venueServices', s)} className={`px-4 py-2 rounded-full border text-[10px] font-bold uppercase ${data.venueServices.includes(s) ? 'bg-mid-secondary/20 border-mid-secondary text-mid-secondary' : 'border-slate-200 dark:border-white/10 text-slate-500 dark:text-mid-text-subtle'}`}>{s}</button>
                            ))}
                        </div>
                    </InputGroup>
                </div>
            );
            case 3: return ( // Pricing 
                <div className="space-y-6 animate-cinematic-fade">
                    <InputGroup label="Booking Method">
                        <div className="flex flex-col gap-2">
                            {['Online Booking', 'Phone Inquiry', 'Email Request'].map(m => (
                                <button key={m} onClick={() => updateData('bookingMode', m)} className={`p-4 rounded-xl border text-left text-xs font-bold ${data.bookingMode === m ? 'bg-mid-primary/20 border-mid-primary text-slate-900 dark:text-white' : 'border-slate-200 dark:border-white/10 text-slate-500 dark:text-mid-text-subtle'}`}>{m}</button>
                            ))}
                        </div>
                    </InputGroup>
                </div>
            );
            case 4: return ( // Media
                 <div className="space-y-6 animate-cinematic-fade py-10">
                    <div className="border-2 border-dashed border-slate-300 dark:border-white/10 rounded-2xl p-10 hover:bg-slate-50 dark:hover:bg-white/[0.02] transition-colors cursor-pointer text-center">
                        <Upload className="w-8 h-8 text-slate-400 dark:text-mid-text-subtle mx-auto mb-4" />
                        <h4 className="text-slate-900 dark:text-white font-bold text-sm">Venue Gallery</h4>
                        <p className="text-slate-500 dark:text-mid-text-subtle text-xs mt-2">Upload 3 to 8 high-quality images of your space.</p>
                    </div>
                </div>
            );
            case 5: return ( // Availability
                <div className="space-y-6 animate-cinematic-fade">
                    <p className="text-center text-xs text-slate-500 dark:text-mid-text-subtle">Define opening hours and available dates.</p>
                    <div className="space-y-2">
                        {['Mon-Fri', 'Sat-Sun'].map(d => (
                            <div key={d} className="flex items-center justify-between p-4 bg-slate-50 dark:bg-white/[0.03] rounded-xl">
                                <span className="text-sm text-slate-900 dark:text-white">{d}</span>
                                <span className="text-xs text-slate-500 dark:text-mid-text-muted">09:00 - 23:00</span>
                            </div>
                        ))}
                    </div>
                </div>
            );
            case 6: return ( // Validation
                <div className="space-y-6 animate-cinematic-fade">
                    <div className="p-6 bg-slate-100 dark:bg-mid-surface border border-slate-200 dark:border-white/5 rounded-2xl space-y-4">
                        <label className="flex gap-3 cursor-pointer">
                            <input type="checkbox" checked={data.termsAccepted} onChange={e => updateData('termsAccepted', e.target.checked)} className="mt-1 accent-mid-primary" />
                            <span className="text-xs text-slate-600 dark:text-mid-text-muted">I accept the Terms of Service.</span>
                        </label>
                        <label className="flex gap-3 cursor-pointer">
                            <input type="checkbox" checked={data.gdprAccepted} onChange={e => updateData('gdprAccepted', e.target.checked)} className="mt-1 accent-mid-primary" />
                            <span className="text-xs text-slate-600 dark:text-mid-text-muted">I consent to GDPR data processing.</span>
                        </label>
                    </div>
                </div>
            );
        }
    }

    // --- AGENCY FLOW ---
    if (flowType === 'agency') {
        switch(step) {
            case 0: return (
                <div className="space-y-6 animate-cinematic-fade">
                    <InputGroup label="Agency Name *"><TextInput value={data.name} onChange={e => updateData('name', e.target.value)} /></InputGroup>
                    <div className="flex items-center gap-4 p-4 border border-slate-200 dark:border-white/10 rounded-xl bg-slate-50 dark:bg-white/[0.02]">
                        <div className="w-12 h-12 bg-slate-200 dark:bg-white/10 rounded-lg flex items-center justify-center"><Briefcase className="w-5 h-5 text-slate-500 dark:text-white" /></div>
                        <button className="text-xs font-bold uppercase text-mid-primary">Upload Identity</button>
                    </div>
                    <InputGroup label="Agency Description *"><textarea value={data.desc} onChange={e => updateData('desc', e.target.value)} className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl p-3 text-sm text-slate-900 dark:text-white h-24" /></InputGroup>
                </div>
            );
            case 1: return (
                <div className="space-y-6 animate-cinematic-fade">
                    <div className="grid grid-cols-2 gap-4">
                        <InputGroup label="Contact Email *"><TextInput type="email" value={data.email} onChange={e => updateData('email', e.target.value)} /></InputGroup>
                        <InputGroup label="Office Phone *"><TextInput type="tel" value={data.phone} onChange={e => updateData('phone', e.target.value)} /></InputGroup>
                    </div>
                    <InputGroup label="Website"><TextInput value={data.website} onChange={e => updateData('website', e.target.value)} /></InputGroup>
                    <InputGroup label="HQ Address *"><TextInput value={data.address} onChange={e => updateData('address', e.target.value)} /></InputGroup>
                </div>
            );
            case 2: return (
                <div className="space-y-6 animate-cinematic-fade">
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-widest mb-4">Services Offered</h4>
                    <div className="grid grid-cols-1 gap-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                        {AGENCY_SERVICES.map(s => (
                            <button 
                                key={s.id} 
                                onClick={() => toggleItem('agencyServices', s.id)} 
                                className={`flex items-start gap-4 p-4 rounded-xl border text-left transition-all ${data.agencyServices.includes(s.id) ? 'bg-mid-primary/10 border-mid-primary' : 'bg-white dark:bg-white/[0.02] border-slate-200 dark:border-white/5 hover:bg-slate-50 dark:hover:bg-white/[0.05]'}`}
                            >
                                <div className={`w-5 h-5 rounded border mt-0.5 flex items-center justify-center ${data.agencyServices.includes(s.id) ? 'bg-mid-primary border-mid-primary' : 'border-slate-300 dark:border-white/20'}`}>
                                    {data.agencyServices.includes(s.id) && <Check className="w-3 h-3 text-white" />}
                                </div>
                                <div>
                                    <span className={`block text-xs font-bold uppercase tracking-wider ${data.agencyServices.includes(s.id) ? 'text-slate-900 dark:text-white' : 'text-slate-500 dark:text-mid-text-subtle'}`}>{s.label}</span>
                                    <span className="text-[10px] text-slate-500 dark:text-mid-text-muted mt-1 block">{s.description}</span>
                                </div>
                            </button>
                        ))}
                    </div>
                </div>
            );
            case 3: return ( // Pricing
                <div className="space-y-6 animate-cinematic-fade">
                    <InputGroup label="Pricing Policy *">
                        <div className="flex gap-4">
                            {['Flat Rate Packages', 'Quote Based'].map(p => (
                                <button key={p} onClick={() => updateData('billingMode', p)} className={`flex-1 py-4 rounded-xl border text-xs font-bold ${data.billingMode === p ? 'bg-mid-primary text-white border-mid-primary' : 'bg-white dark:bg-white/[0.02] border-slate-200 dark:border-white/5 text-slate-500 dark:text-mid-text-subtle'}`}>{p}</button>
                            ))}
                        </div>
                    </InputGroup>
                </div>
            );
            case 4: return ( // Media
                 <div className="space-y-6 animate-cinematic-fade py-10">
                    <div className="border-2 border-dashed border-slate-300 dark:border-white/10 rounded-2xl p-10 hover:bg-slate-50 dark:hover:bg-white/[0.02] transition-colors cursor-pointer text-center">
                        <Upload className="w-8 h-8 text-slate-400 dark:text-mid-text-subtle mx-auto mb-4" />
                        <h4 className="text-slate-900 dark:text-white font-bold text-sm">Project Portfolio</h4>
                        <p className="text-slate-500 dark:text-mid-text-subtle text-xs mt-2">Upload case studies or event photos.</p>
                    </div>
                </div>
            );
            case 5: return ( // Zones
                <div className="space-y-6 animate-cinematic-fade">
                    <InputGroup label="Operating Zones">
                        <div className="flex flex-wrap gap-2">
                            {['Tunis', 'Sousse', 'Hammamet', 'Djerba', 'National', 'International'].map(z => (
                                <button key={z} className="px-4 py-2 rounded-full border border-slate-200 dark:border-white/10 text-xs text-slate-500 dark:text-mid-text-subtle hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white">{z}</button>
                            ))}
                        </div>
                    </InputGroup>
                </div>
            );
            case 6: return ( // Validation
                <div className="space-y-6 animate-cinematic-fade">
                    <div className="p-6 bg-slate-100 dark:bg-mid-surface border border-slate-200 dark:border-white/5 rounded-2xl space-y-4">
                        <label className="flex gap-3 cursor-pointer">
                            <input type="checkbox" checked={data.termsAccepted} onChange={e => updateData('termsAccepted', e.target.checked)} className="mt-1 accent-mid-primary" />
                            <span className="text-xs text-slate-600 dark:text-mid-text-muted">I accept the Terms of Service.</span>
                        </label>
                        <label className="flex gap-3 cursor-pointer">
                            <input type="checkbox" checked={data.gdprAccepted} onChange={e => updateData('gdprAccepted', e.target.checked)} className="mt-1 accent-mid-primary" />
                            <span className="text-xs text-slate-600 dark:text-mid-text-muted">I consent to GDPR data processing.</span>
                        </label>
                    </div>
                </div>
            );
        }
    }

    return null;
  };

  const getStepTitle = () => {
      const titles = flowType === 'agency' 
        ? ['Identification', 'Contact Info', 'Services', 'Pricing', 'Portfolio', 'Zones', 'Validation']
        : flowType === 'venue'
            ? ['Venue Info', 'Location', 'Services', 'Booking', 'Gallery', 'Availability', 'Validation']
            : ['Role & Identity', 'Contact Info', 'Service Details', 'Rates & Terms', 'Media & Proofs', 'Availability', 'Validation'];
            
      return titles[step] || 'Onboarding';
  };

  return (
    <div className="w-full h-full flex flex-col relative max-w-2xl mx-auto py-8 px-6 md:px-0">
        
        {/* Back Button */}
        <button 
            onClick={step === 0 ? onBack : () => setStep(s => s - 1)}
            className="absolute top-0 left-0 z-50 group flex items-center gap-3 px-6 py-2.5 rounded-[10px] border border-black/5 dark:border-white/10 bg-white/20 dark:bg-black/20 backdrop-blur-md hover:border-mid-primary/50 hover:bg-mid-primary/5 transition-all duration-500 shadow-sm"
        >
            <ArrowLeft className="w-4 h-4 text-slate-600 dark:text-slate-300 group-hover:text-mid-primary group-hover:-translate-x-1 transition-all" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-600 dark:text-slate-300 group-hover:text-mid-primary transition-colors">{step === 0 ? 'Cancel' : 'Back'}</span>
        </button>

        {/* Header */}
        <div className="mt-12">
            <StepHeader 
                title={getStepTitle()} 
                subtitle={`Step ${step + 1} of ${totalSteps}`} 
                step={step} 
                total={totalSteps} 
            />
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto no-scrollbar pb-24">
            {renderContent()}
        </div>

        {/* Footer */}
        <div className="mt-auto pt-6 border-t border-slate-100 dark:border-white/5 flex justify-end">
            <button
                onClick={handleNext}
                disabled={step === totalSteps - 1 && (!data.termsAccepted && (flowType === 'venue' || flowType === 'agency' ? !data.gdprAccepted : !data.certified))}
                className="px-8 py-3 rounded-xl bg-mid-primary hover:bg-mid-primary/90 text-white text-xs font-bold uppercase tracking-[0.2em] shadow-glow-blue transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
                {step === totalSteps - 1 ? 'Submit Application' : 'Continue'}
                {step < totalSteps - 1 && <ArrowLeft className="w-3 h-3 rotate-180" />}
            </button>
        </div>
    </div>
  );
};
