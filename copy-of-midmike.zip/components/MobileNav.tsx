
import React from 'react';
import { Home, Search, List, User, Compass } from 'lucide-react';
import { useBasket } from '../contexts/BasketContext';

interface MobileNavProps {
  currentRoute: string;
  onNavigate: (route: string) => void;
  onOpenBasket: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({ currentRoute, onNavigate, onOpenBasket }) => {
  const { totalItems } = useBasket();

  const navItems = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'events', icon: Compass, label: 'Explore' },
    { id: 'basket', icon: List, label: 'Shortlist', action: onOpenBasket },
    { id: 'profile', icon: User, label: 'Profile' },
  ];

  return (
    <div className="md:hidden fixed bottom-5 left-10 right-10 z-[90]">
      {/* Ultra Glass Container: Low opacity background, high blur, capsule shape */}
      <div className="absolute inset-0 bg-white/20 dark:bg-black/20 backdrop-blur-2xl rounded-full shadow-[0_8px_32px_rgba(0,0,0,0.1)] border border-white/20 dark:border-white/10" />
      
      <div className="relative flex items-center justify-evenly h-14 px-1">
        {navItems.map((item) => {
          const isActive = currentRoute === item.id;
          return (
            <button
              key={item.id}
              onClick={() => item.action ? item.action() : onNavigate(item.id)}
              className={`group flex items-center justify-center w-12 h-12 rounded-full transition-all duration-300 relative`}
            >
              {/* Active Indicator: Subtle Glow from behind */}
              <div className={`absolute inset-0 rounded-full bg-white/30 dark:bg-white/10 blur-lg transition-opacity duration-300 ${isActive ? 'opacity-100' : 'opacity-0'}`} />
              
              <div className={`
                relative transition-all duration-300 flex items-center justify-center
                ${isActive 
                    ? 'text-slate-900 dark:text-white scale-110 drop-shadow-[0_0_8px_rgba(255,255,255,0.4)]' 
                    : 'text-slate-600 dark:text-white/60 hover:text-slate-800 dark:hover:text-white'
                }
              `}>
                <item.icon className={`w-5 h-5 ${isActive ? 'fill-current' : ''}`} strokeWidth={isActive ? 2.5 : 2} />
                
                {/* Badge for Shortlist */}
                {item.id === 'basket' && totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-red-500 rounded-full text-[8px] font-bold text-white flex items-center justify-center border border-white/20 shadow-sm animate-in zoom-in">
                    {totalItems}
                  </span>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
