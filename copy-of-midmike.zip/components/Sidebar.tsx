
import React from 'react';
import { 
  LayoutGrid, User, Calendar, Wrench, MapPin, 
  Briefcase, Star, Globe, Settings, LogOut, X, Disc, Truck,
  Info, Sparkles, Zap, PanelLeft, Instagram, Twitter, Linkedin, Smartphone,
  PlayCircle, MessageSquare
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Role } from '../types';

interface SidebarProps {
  currentRoute: string;
  onNavigate: (route: string) => void;
  isMobileOpen?: boolean;
  onMobileClose?: () => void;
  isExpanded: boolean;
  onToggle: () => void;
  onQuickStart: () => void;
}

const SECTIONS = [
  {
    title: 'Navigation',
    color: 'primary',
    items: [
      { id: 'home', label: 'Home', icon: LayoutGrid },
      { id: 'messages', label: 'Inbox', icon: MessageSquare },
      { id: 'events', label: 'Explore Events', icon: Calendar },
      { id: 'artists', label: 'Artists', icon: User },
      { id: 'technicians', label: 'Technicians', icon: Wrench },
      { id: 'venues', label: 'Venues', icon: MapPin },
      { id: 'agencies', label: 'Agencies', icon: Briefcase },
      { id: 'providers', label: 'Service Providers', icon: Truck },
    ]
  },
  {
    title: 'Professional',
    color: 'accent',
    items: [
      { id: 'opportunities', label: 'Find Opportunities', icon: Star, requiresPro: true },
    ]
  },
  {
    title: 'Platform',
    color: 'secondary',
    items: [
      { id: 'studio', label: 'Studio Services', icon: Sparkles },
      { id: 'content', label: 'Content Hub', icon: Globe },
      { id: 'about', label: 'About', icon: Info },
    ]
  }
];

export const Sidebar: React.FC<SidebarProps> = ({ 
  currentRoute, 
  onNavigate, 
  isMobileOpen = false, 
  onMobileClose,
  isExpanded,
  onToggle,
  onQuickStart
}) => {
  const { user, setAuthModalOpen, openAddRole } = useAuth();

  const isPro = (role?: Role) => {
    if (!role) return false;
    const proRoles: Role[] = ['Artist', 'Technician', 'Venue', 'Agency', 'ServiceProvider'];
    return proRoles.includes(role);
  };

  const getColorClass = (sectionColor: string, isActive: boolean) => {
    if (!isActive) return 'text-slate-500 dark:text-mid-text-muted group-hover:text-slate-900 dark:group-hover:text-white';
    switch (sectionColor) {
      case 'secondary': return 'text-mid-secondary drop-shadow-[0_0_12px_rgba(0,135,109,0.6)]';
      case 'accent': return 'text-mid-accent drop-shadow-[0_0_12px_rgba(232,102,68,0.6)]';
      default: return 'text-mid-primary drop-shadow-[0_0_12px_rgba(23,84,216,0.6)]';
    }
  };

  const getIndicatorColor = (sectionColor: string) => {
    switch (sectionColor) {
      case 'secondary': return 'bg-mid-secondary shadow-glow-secondary';
      case 'accent': return 'bg-mid-accent shadow-glow-accent';
      default: return 'bg-mid-primary shadow-glow-blue';
    }
  };

  const handleMobileClose = () => {
    if (isMobileOpen && onMobileClose) {
      onMobileClose();
    }
  };

  const showLabels = isMobileOpen || isExpanded;

  return (
    <>
      <div 
        className={`fixed inset-0 bg-black/60 backdrop-blur-sm z-[105] transition-opacity duration-500 md:hidden ${isMobileOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
        onClick={handleMobileClose}
        aria-hidden="true"
      />

      <aside 
        id="sidebar" 
        className={`
          fixed top-0 left-0 h-screen z-[110]
          flex flex-col overflow-hidden transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)]
          bg-white/70 dark:bg-[#121212]/60 backdrop-blur-2xl
          border-r border-slate-200 dark:border-white/10
          shadow-[2px_0_30px_rgba(0,0,0,0.03)] dark:shadow-[4px_0_24px_rgba(0,0,0,0.5)]
          ${isMobileOpen ? 'w-[280px] translate-x-0' : '-translate-x-full md:translate-x-0'}
          ${isExpanded ? 'md:w-64' : 'md:w-16'}
        `}
      >
        <div className={`h-20 flex items-center flex-shrink-0 transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] ${showLabels ? 'px-6' : 'justify-center px-0'}`}>
          <div className="flex items-center gap-4 w-full">
            <button 
              onClick={isMobileOpen ? onMobileClose : onToggle}
              className={`
                p-2.5 rounded-xl transition-all duration-300
                text-slate-700 dark:text-white 
                hover:bg-slate-100 dark:hover:bg-white/5 
                ${!showLabels ? 'w-10 h-10 flex items-center justify-center' : ''}
              `}
              aria-label="Toggle Sidebar"
            >
              {isMobileOpen ? <X className="w-5 h-5" /> : <PanelLeft className="w-5 h-5" />}
            </button>

            {showLabels && (
              <div className="flex items-center gap-3 animate-in fade-in slide-in-from-left-2 duration-500">
                <div className="w-7 h-7 rounded-lg relative flex-shrink-0 flex items-center justify-center overflow-hidden shadow-lg group">
                  <div className="absolute inset-0 bg-gradient-to-br from-mid-primary via-mid-accent to-mid-secondary animate-pulse-glow opacity-80" />
                  <div className="absolute inset-[1.5px] bg-white dark:bg-[#0a0a0a] rounded-[6px] flex items-center justify-center z-10 border border-white/5">
                    <Disc className="text-slate-900 dark:text-white w-3 h-3 animate-spin-slow" />
                  </div>
                </div>
                <span className="font-tiempos font-semibold text-base tracking-tight text-slate-800 dark:text-white whitespace-nowrap">
                  MidMike
                </span>
              </div>
            )}
          </div>
        </div>

        <nav className="flex-1 py-4 flex flex-col gap-6 overflow-y-auto no-scrollbar">
          {SECTIONS.map((section) => (
            <div key={section.title} className="flex flex-col gap-1">
              {showLabels && (
                <div className="px-6 mb-1">
                  <span className="text-[9px] font-bold text-slate-400 dark:text-mid-text-subtle uppercase tracking-[0.25em]">
                    {section.title}
                  </span>
                </div>
              )}
              {section.items.map((item) => {
                const isActive = currentRoute === item.id;
                const hasProAccess = isPro(user?.role);
                const isLocked = item.requiresPro && !hasProAccess;

                return (
                  <button
                    key={item.id}
                    onClick={() => {
                        if (isLocked) {
                            if (user) openAddRole();
                            else setAuthModalOpen(true);
                        } else {
                            onNavigate(item.id);
                        }
                        handleMobileClose();
                    }}
                    className={`
                      group flex items-center h-10 transition-all duration-300 relative w-full 
                      ${showLabels ? 'px-6 gap-4' : 'justify-center px-0'} 
                      ${isActive ? 'text-slate-800 dark:text-white' : 'text-slate-500 dark:text-mid-text-muted hover:text-slate-800 dark:hover:text-white'}
                      cursor-pointer
                    `}
                  >
                    <div className={`relative flex-shrink-0 flex items-center justify-center w-5 h-5 ${isLocked ? 'opacity-40 group-hover:opacity-60 transition-opacity' : ''}`}>
                      <item.icon 
                        strokeWidth={isActive ? 2.5 : 1.5} 
                        className={`w-full h-full transition-all duration-300 ${getColorClass(section.color, isActive)}`} 
                      />
                    </div>
                    {showLabels && (
                      <div className="flex-1 flex items-center justify-between min-w-0 animate-in fade-in slide-in-from-left-2 duration-500">
                          <span className={`text-[13px] font-medium tracking-wide whitespace-nowrap ${isLocked ? 'opacity-40 group-hover:opacity-60 transition-opacity' : ''}`}>
                          {item.label}
                          </span>
                          {isLocked && (
                              <div className="opacity-100 px-2 py-0.5 rounded-full border border-mid-accent/30 bg-mid-accent/10 text-mid-accent text-[8px] font-bold shadow-[0_0_12px_rgba(232,102,68,0.4)] animate-pulse tracking-widest flex items-center gap-1">
                                  PRO
                              </div>
                          )}
                          {item.id === 'messages' && !isActive && (
                              <div className="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)] animate-pulse" />
                          )}
                      </div>
                    )}
                    {isActive && !showLabels && (
                      <div className={`absolute left-0 w-1 h-5 rounded-r-full ${getIndicatorColor(section.color)}`} />
                    )}
                    {isActive && showLabels && (
                      <div className={`absolute right-4 w-1 h-1 rounded-full ${getIndicatorColor(section.color)}`} />
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        <div className={`mt-auto p-4 transition-all duration-500 ${showLabels ? 'px-6 space-y-4' : 'flex flex-col items-center space-y-4'}`}>
           <button 
             onClick={() => {
                 onQuickStart();
                 handleMobileClose();
             }}
             className={`
               group flex items-center h-10 rounded-xl transition-all duration-500 relative overflow-hidden border border-slate-200 dark:border-white/5 bg-slate-50 dark:bg-transparent hover:bg-slate-100 dark:hover:bg-white/5
               ${showLabels ? 'px-4 gap-4 w-full shadow-sm' : 'justify-center w-10'}
             `}
           >
             <PlayCircle className="w-4 h-4 text-mid-primary" />
             {showLabels && <span className="text-[10px] font-bold uppercase tracking-widest text-slate-600 dark:text-mid-text-subtle">Quick Start</span>}
           </button>

           <button 
             onClick={() => {
                 alert('Mobile App download coming soon via App Store & Google Play');
                 handleMobileClose();
             }}
             className={`
               group flex items-center h-10 rounded-xl transition-all duration-500 relative overflow-hidden border border-slate-200 dark:border-white/5 bg-slate-50 dark:bg-transparent hover:bg-slate-100 dark:hover:bg-white/5
               ${showLabels ? 'px-4 gap-4 w-full shadow-sm' : 'justify-center w-10'}
             `}
           >
             <Smartphone className="w-4 h-4 text-mid-accent" />
             {showLabels && <span className="text-[10px] font-bold uppercase tracking-widest text-slate-600 dark:text-mid-text-subtle">Get App</span>}
           </button>

           {showLabels && (
              <div className="flex items-center justify-center gap-4 opacity-60">
                  <button className="text-slate-500 dark:text-mid-text-muted hover:text-pink-500 transition-colors"><Instagram className="w-4 h-4" /></button>
                  <button className="text-slate-500 dark:text-mid-text-muted hover:text-blue-400 transition-colors"><Twitter className="w-4 h-4" /></button>
                  <button className="text-slate-500 dark:text-mid-text-muted hover:text-blue-600 transition-colors"><Linkedin className="w-4 h-4" /></button>
              </div>
           )}
        </div>
      </aside>
    </>
  );
};
