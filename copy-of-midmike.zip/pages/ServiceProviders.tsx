
import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { ProfessionalEntity } from '../types';
import { Card } from '../components/Card';
import { Search, SlidersHorizontal, Truck } from 'lucide-react';
import { useBasket } from '../contexts/BasketContext';
import { FilterPanel, FilterState } from '../components/FilterPanel';

export const ServiceProviders: React.FC<{ onNavigate: (route: string, params?: any) => void }> = ({ onNavigate }) => {
  const [providers, setProviders] = useState<ProfessionalEntity[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [filters, setFilters] = useState<FilterState>({
    categories: [],
    tags: [],
    rating: null,
    verifiedOnly: false,
    location: null
  });

  const { addToBasket } = useBasket();

  useEffect(() => {
    const load = async () => {
      try {
        const data = await api.getFeaturedServiceProviders();
        setProviders(data);
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, []);

  const filtered = providers.filter(p => {
    if (searchQuery && !p.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    
    if (filters.categories.length > 0) {
       const matchesCategory = filters.categories.some(c => p.category.includes(c) || p.profession.includes(c));
       if (!matchesCategory) return false;
    }

    if (filters.tags.length > 0) {
        const matchesTag = filters.tags.some(t => p.tags?.some(pt => pt.includes(t)));
        if (!matchesTag) return false;
    }

    if (filters.rating && (p.rating || 0) < filters.rating) return false;
    if (filters.verifiedOnly && !p.verified) return false;
    if (filters.location && !p.location?.includes(filters.location)) return false;

    return true;
  });

  const activeFilterCount = 
    filters.categories.length + 
    filters.tags.length + 
    (filters.rating ? 1 : 0) + 
    (filters.verifiedOnly ? 1 : 0) +
    (filters.location ? 1 : 0);

  return (
    <div className="animate-cinematic-fade pb-24">
      {/* Aesthetic Header */}
      <header className="mt-8 mb-8 px-4 md:px-0">
        <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-black/5 dark:border-white/[0.08] pb-6 gap-6">
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-3">
              <span className="w-8 h-[2px] bg-mid-accent/60"></span>
              <span className="text-[10px] font-bold uppercase tracking-[0.4em] text-mid-accent">Infrastructure</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-inter font-normal text-slate-900 dark:text-white tracking-tight">
              Service Providers
            </h1>
          </div>
          
          <div className="flex flex-col gap-4 w-full md:w-auto">
             <div className="flex items-center gap-2 w-full md:w-auto">
                <div className="relative group flex-1 md:w-64">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle group-focus-within:text-mid-accent transition-colors" />
                    <input 
                        type="text" 
                        placeholder="Search logistical support..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full bg-slate-200/50 dark:bg-white/5 border border-black/5 dark:border-white/10 rounded-full py-2.5 pl-10 pr-4 text-xs font-medium text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-mid-text-subtle focus:outline-none focus:border-mid-accent/40 transition-all shadow-inner"
                    />
                </div>

                <button 
                    onClick={() => setIsFilterOpen(true)}
                    className={`
                        flex items-center gap-2 rounded-full border transition-all duration-300 shrink-0
                        px-4 py-2.5 md:px-6 md:py-3 
                        ${activeFilterCount > 0 
                            ? 'bg-mid-accent text-white border-mid-accent shadow-glow-accent' 
                            : 'bg-white dark:bg-white/5 border-black/5 dark:border-white/10 text-slate-600 dark:text-mid-text-subtle hover:bg-slate-50 dark:hover:bg-white/10'}
                    `}
                >
                    <SlidersHorizontal className="w-3.5 h-3.5 md:w-4 md:h-4" />
                    <span className="text-[9px] md:text-[10px] font-bold uppercase tracking-widest">Filters</span>
                    {activeFilterCount > 0 && (
                        <span className="ml-1 w-4 h-4 md:w-5 md:h-5 flex items-center justify-center bg-white text-mid-accent rounded-full text-[8px] md:text-[9px] font-bold">{activeFilterCount}</span>
                    )}
                </button>
             </div>
          </div>
        </div>
      </header>

      {/* Active Filters Summary (Desktop Only) */}
      {activeFilterCount > 0 && (
         <div className="hidden md:flex flex-wrap gap-2 mb-8 px-4 md:px-0">
            {filters.categories.map(c => <span key={c} className="px-3 py-1 rounded-full bg-mid-accent/10 text-mid-accent text-[10px] font-bold uppercase border border-mid-accent/20">{c}</span>)}
            {filters.tags.map(t => <span key={t} className="px-3 py-1 rounded-full bg-slate-100 dark:bg-white/10 text-slate-600 dark:text-mid-text-subtle text-[10px] font-bold uppercase border border-black/5 dark:border-white/20">{t}</span>)}
            <button onClick={() => setFilters({categories: [], tags: [], rating: null, verifiedOnly: false, location: null})} className="text-[10px] text-slate-400 hover:text-white underline decoration-dashed underline-offset-4 ml-2">Clear All</button>
         </div>
      )}

      {isLoading ? (
        <div className="h-60 flex flex-col items-center justify-center gap-4">
          <div className="w-10 h-10 border-2 border-mid-accent/20 border-t-mid-accent rounded-full animate-spin"></div>
          <span className="text-[10px] text-mid-text-subtle font-bold uppercase tracking-widest animate-pulse">Inventory Loading...</span>
        </div>
      ) : (
        /* Flex Layout: Single Column Mobile (Centered, Not Full Width), Grid Desktop */
        <div className="flex flex-wrap justify-center gap-8 pb-12 px-4 md:px-0">
          {filtered.map(provider => (
            <div key={provider.id} className="w-[300px] md:w-[340px] animate-in fade-in slide-in-from-bottom-2 duration-500">
                <Card 
                  variant="portrait-action"
                  image={provider.imageUrl}
                  title={provider.title}
                  subtitle={provider.profession}
                  badge={provider.category}
                  verified={provider.verified}
                  rating={provider.rating}
                  imageAspectRatio="square"
                  showBookingAction={true}
                  onBook={() => addToBasket(provider)}
                  onClick={() => onNavigate('provider-details', { id: provider.id })}
                />
            </div>
          ))}
          {filtered.length === 0 && (
            <div className="w-full py-20 text-center opacity-40">
                <Truck className="w-12 h-12 text-slate-300 dark:text-white/20 mx-auto mb-4" />
                <p className="text-lg font-inter text-slate-900 dark:text-white">No logistical partners matching your query.</p>
                <button onClick={() => setFilters({categories: [], tags: [], rating: null, verifiedOnly: false, location: null})} className="mt-4 text-xs font-bold uppercase tracking-widest text-mid-accent">Clear Filters</button>
            </div>
          )}
        </div>
      )}

      <FilterPanel 
        isOpen={isFilterOpen}
        onClose={() => setIsFilterOpen(false)}
        type="provider"
        currentFilters={filters}
        onApply={setFilters}
        resultsCount={filtered.length}
      />
    </div>
  );
};
