
import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, Send, Paperclip, MoreVertical, Phone, Video, 
  CheckCheck, ArrowLeft, Mic, MessageSquare, Image as ImageIcon,
  MoreHorizontal, Gift, Smile
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface Message {
  id: string;
  sender: 'me' | 'them';
  text: string;
  time: string;
  type: 'text' | 'image' | 'audio';
  status: 'sent' | 'delivered' | 'read';
  isFirstInGroup?: boolean;
}

interface Conversation {
  id: string;
  user: {
    name: string;
    avatar: string;
    role: string;
    online: boolean;
    mutuals?: number;
    community?: string;
  };
  lastMessage: string;
  lastTime: string;
  unread: number;
  messages: Message[];
}

const MOCK_CONVERSATIONS: Conversation[] = [
  {
    id: 'c1',
    user: { name: 'Brendan Jowett', avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?q=80&w=200', role: 'Artist', online: true, mutuals: 4, community: "Brendan's AI Community" },
    lastMessage: 'Glad to have you here!',
    lastTime: '10:59pm',
    unread: 1,
    messages: [
        { id: 'm1', sender: 'them', text: 'Hey Bilel, welcome to the community! 👋', time: '10:59pm', type: 'text', status: 'read', isFirstInGroup: true },
        { id: 'm2', sender: 'them', text: "We'd love to get to know you, when you've got a minute, make a quick intro post and share a bit about who you are, what you're building, and what you're hoping to get from this group.", time: '10:59pm', type: 'text', status: 'read' },
        { id: 'm3', sender: 'them', text: 'Glad to have you here!\nBrendan', time: '10:59pm', type: 'text', status: 'read' },
    ]
  },
  {
    id: 'c2',
    user: { name: 'Ethan Shaw', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200', role: 'Artist', online: false },
    lastMessage: "Hey Bilel, welcome to Catalyst! I'd love to...",
    lastTime: '16d',
    unread: 0,
    messages: [
        { id: 'm1', sender: 'them', text: "Hey Bilel, welcome to Catalyst! I'd love for you to introduce yourself.", time: 'Oct 24', type: 'text', status: 'read', isFirstInGroup: true },
    ]
  },
  {
    id: 'c3',
    user: { name: 'Eric Thayne', avatar: 'https://images.unsplash.com/photo-1566492031773-4fbc7e7323f9?q=80&w=200', role: 'Venue', online: true },
    lastMessage: 'Hey Bilel, welcome to CREATE! This com...',
    lastTime: 'Nov 25',
    unread: 1,
    messages: []
  },
  {
    id: 'c4',
    user: { name: 'Austin Coldiron', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200', role: 'Agency', online: false },
    lastMessage: "Bilel - Here's the sign up for the Content ...",
    lastTime: 'Nov 25',
    unread: 6,
    messages: []
  },
  {
    id: 'c5',
    user: { name: 'Chantelle Lovell', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200', role: 'Client', online: true },
    lastMessage: "Well Hello there 👋 Hope this message fi...",
    lastTime: 'Nov 25',
    unread: 3,
    messages: []
  }
];

interface MessagesProps {
    onNavigate?: (route: string) => void;
}

export const Messages: React.FC<MessagesProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [conversations, setConversations] = useState(MOCK_CONVERSATIONS);
  const [inputText, setInputText] = useState('');
  const [isMobileView, setIsMobileView] = useState(false);
  
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
      const handleResize = () => setIsMobileView(window.innerWidth < 768);
      handleResize();
      window.addEventListener('resize', handleResize);
      return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
      if (selectedId) {
          chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }
  }, [selectedId, conversations]);

  const activeConv = conversations.find(c => c.id === selectedId);

  const handleSend = (e?: React.FormEvent) => {
      e?.preventDefault();
      if (!inputText.trim() || !selectedId) return;

      const newMessage: Message = {
          id: Date.now().toString(),
          sender: 'me',
          text: inputText,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          type: 'text',
          status: 'sent',
          isFirstInGroup: true
      };

      setConversations(prev => prev.map(c => {
          if (c.id === selectedId) {
              return {
                  ...c,
                  messages: [...c.messages, newMessage],
                  lastMessage: inputText,
                  lastTime: 'Just now'
              };
          }
          return c;
      }));

      setInputText('');
  };

  const handleBack = () => {
      if (onNavigate) {
          onNavigate('home');
      }
  };

  // Mobile Toggles
  const showList = !isMobileView || !selectedId;
  const showChat = !isMobileView || selectedId;

  return (
    // Fixed height layout for desktop, fluid for mobile
    <div className="h-[calc(100dvh-85px)] md:h-[calc(100vh-100px)] animate-cinematic-fade flex overflow-hidden rounded-none md:rounded-3xl border-0 md:border border-slate-200 dark:border-white/10 shadow-none md:shadow-glass bg-[#191919]">
        
        {/* --- Sidebar List --- */}
        <div className={`w-full md:w-[380px] lg:w-[420px] flex flex-col border-r border-white/5 bg-[#191919] ${showList ? 'flex' : 'hidden md:flex'}`}>
            {/* Header */}
            <div className="p-5 border-b border-white/5 space-y-4">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        {/* Replaced menu/3-dots with Back Arrow for mobile navigation */}
                        <button onClick={handleBack} className="md:hidden -ml-2 p-2 text-slate-400 hover:text-white transition-colors">
                            <ArrowLeft className="w-6 h-6" />
                        </button>
                        <h2 className="text-xl font-bold text-white tracking-wide">Chats</h2>
                    </div>
                    <button className="text-slate-400 hover:text-white transition-colors">
                        <MoreHorizontal className="w-5 h-5" />
                    </button>
                </div>
                {/* Search */}
                <div className="relative group">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-white transition-colors" />
                    <input 
                        type="text" 
                        placeholder="Search users" 
                        className="w-full bg-[#252525] border border-transparent focus:border-white/10 rounded-xl py-3 pl-11 pr-4 text-sm font-medium text-slate-200 placeholder-slate-500 focus:outline-none transition-all"
                    />
                </div>
            </div>

            {/* Conversation List */}
            <div className="flex-1 overflow-y-auto custom-scrollbar">
                {conversations.map(conv => (
                    <button
                        key={conv.id}
                        onClick={() => setSelectedId(conv.id)}
                        className={`w-full p-4 flex gap-4 hover:bg-white/[0.03] transition-all border-b border-white/[0.02] ${selectedId === conv.id ? 'bg-white/[0.05]' : ''}`}
                    >
                        <div className="relative shrink-0">
                            <div className="w-12 h-12 rounded-full overflow-hidden bg-[#252525]">
                                <img src={conv.user.avatar} className="w-full h-full object-cover" alt="" />
                            </div>
                            {conv.unread > 0 && (
                                <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 border-2 border-[#191919] rounded-full" />
                            )}
                        </div>
                        <div className="flex-1 min-w-0 text-left pt-0.5">
                            <div className="flex justify-between items-baseline mb-1">
                                <span className="text-[15px] font-bold text-slate-200 truncate pr-2">
                                    {conv.user.name} 
                                    {conv.unread > 0 && <span className="ml-1.5 text-slate-400 font-normal">({conv.unread})</span>}
                                </span>
                                <span className="text-[11px] text-slate-500 font-medium shrink-0">{conv.lastTime}</span>
                            </div>
                            <div className="flex justify-between items-center">
                                <p className={`text-[13px] truncate leading-normal ${conv.unread > 0 ? 'text-slate-300 font-medium' : 'text-slate-500'}`}>
                                    {conv.lastMessage}
                                </p>
                                {conv.unread > 0 && (
                                    <div className="w-2.5 h-2.5 bg-blue-500 rounded-full shrink-0 ml-2 shadow-[0_0_8px_rgba(59,130,246,0.5)]"></div>
                                )}
                            </div>
                        </div>
                    </button>
                ))}
            </div>
        </div>

        {/* --- Chat Area --- */}
        <div className={`flex-1 flex flex-col bg-[#191919] relative ${showChat ? 'flex' : 'hidden md:flex'}`}>
            {activeConv ? (
                <>
                    {/* Header */}
                    <div className="h-[72px] px-4 md:px-6 border-b border-white/5 flex items-center justify-between bg-[#191919] shrink-0 z-20">
                        <div className="flex items-center gap-4">
                            <button onClick={() => setSelectedId(null)} className="md:hidden p-2 -ml-2 text-slate-400 hover:text-white">
                                <ArrowLeft className="w-6 h-6" />
                            </button>
                            <div className="relative">
                                <div className="w-10 h-10 rounded-full overflow-hidden bg-[#252525]">
                                    <img src={activeConv.user.avatar} className="w-full h-full object-cover" alt="" />
                                </div>
                                {activeConv.user.online && (
                                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-[#191919] rounded-full" />
                                )}
                            </div>
                            <div className="flex flex-col">
                                <h3 className="text-[15px] font-bold text-white leading-none mb-1">{activeConv.user.name}</h3>
                                {activeConv.user.online && (
                                    <span className="text-[11px] text-slate-400 font-medium">online now</span>
                                )}
                            </div>
                        </div>
                        <button className="p-2 text-slate-400 hover:text-white transition-colors">
                            <MoreHorizontal className="w-6 h-6" />
                        </button>
                    </div>

                    {/* Messages Body with sufficient padding for fixed bottom bar */}
                    <div className="flex-1 overflow-y-auto p-4 md:p-6 custom-scrollbar bg-[#191919] relative pb-24 md:pb-6">
                        
                        {/* Context / Icebreaker Header */}
                        <div className="flex flex-col items-center justify-center py-8 mb-8 space-y-4 animate-in fade-in zoom-in duration-500">
                            <div className="flex items-center justify-center">
                                <div className="w-16 h-16 rounded-2xl overflow-hidden border-4 border-[#191919] z-10">
                                    <img src={activeConv.user.avatar} className="w-full h-full object-cover" alt="" />
                                </div>
                                <div className="w-16 h-16 rounded-2xl overflow-hidden border-4 border-[#191919] -ml-6 grayscale opacity-60">
                                    <div className="w-full h-full bg-[#252525] flex items-center justify-center text-xs font-bold text-slate-500">YOU</div>
                                </div>
                                <button className="w-8 h-8 rounded-full bg-[#252525] border-4 border-[#191919] flex items-center justify-center -ml-4 -mt-10 z-20 text-slate-400 hover:text-white transition-colors">
                                    <RefreshCw size={14} />
                                </button>
                            </div>
                            <div className="text-center space-y-2 max-w-sm">
                                <p className="text-[13px] text-slate-400 leading-relaxed">
                                    Start a professional conversation with <span className="text-white font-bold">{activeConv.user.name}</span>.
                                </p>
                                <p className="text-[11px] text-slate-500">Discuss collaboration, booking, or technical requirements.</p>
                            </div>
                            <div className="text-[11px] font-bold text-slate-600 uppercase tracking-widest pt-4">Dec 1st 2025</div>
                        </div>

                        {/* Message Stream */}
                        <div className="space-y-1">
                            {activeConv.messages.map((msg, idx) => {
                                const isMe = msg.sender === 'me';
                                const showAvatar = !isMe && msg.isFirstInGroup;
                                const showHeader = !isMe && msg.isFirstInGroup;

                                return (
                                    <div key={msg.id} className={`flex w-full ${isMe ? 'justify-end' : 'justify-start'} ${showHeader ? 'mt-6' : 'mt-1'}`}>
                                        
                                        {!isMe && (
                                            <div className="w-10 mr-3 flex-shrink-0 flex flex-col items-center">
                                                {showAvatar ? (
                                                    <div className="w-10 h-10 rounded-full overflow-hidden bg-[#252525]">
                                                        <img src={activeConv.user.avatar} className="w-full h-full object-cover" alt="" />
                                                    </div>
                                                ) : <div className="w-10" />}
                                            </div>
                                        )}

                                        <div className={`max-w-[85%] md:max-w-[70%] flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                                            {showHeader && (
                                                <div className="flex items-baseline gap-2 mb-1">
                                                    <span className="text-[15px] font-bold text-white">{activeConv.user.name}</span>
                                                    <span className="text-[11px] text-slate-500">{msg.time}</span>
                                                </div>
                                            )}
                                            
                                            <div className={`
                                                relative text-[15px] leading-relaxed whitespace-pre-wrap
                                                ${isMe 
                                                    ? 'bg-[#2A2A2A] text-slate-100 px-4 py-3 rounded-2xl rounded-tr-sm' 
                                                    : 'text-slate-300 pl-0' 
                                                }
                                            `}>
                                                {msg.text}
                                                {isMe && (
                                                    <div className="text-[9px] text-slate-500 text-right mt-1 opacity-60 flex justify-end gap-1 items-center">
                                                        {msg.time} {msg.status === 'read' && <CheckCheck className="w-3 h-3 text-mid-primary" />}
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                        <div ref={chatEndRef} className="h-4" />
                    </div>

                    {/* Input Area - Fixed on Mobile, Sticky/Relative on Desktop */}
                    <div className="fixed bottom-0 left-0 w-full p-4 bg-[#191919] border-t border-white/5 z-50 md:static md:w-auto md:border-t-0 md:bg-transparent md:p-6 pb-[max(1rem,env(safe-area-inset-bottom))]">
                        <form onSubmit={handleSend} className="max-w-4xl mx-auto relative">
                            <div className="w-full bg-[#252525] rounded-full flex items-center pr-3 pl-6 py-1.5 border border-transparent focus-within:border-white/10 transition-all shadow-lg overflow-hidden">
                                <input 
                                    type="text" 
                                    value={inputText}
                                    onChange={(e) => setInputText(e.target.value)}
                                    placeholder={`Message ${activeConv.user.name.split(' ')[0]}`} 
                                    className="flex-1 bg-transparent py-3 text-[15px] text-white placeholder-slate-500 focus:outline-none min-w-0"
                                />
                                <div className="flex items-center gap-1 shrink-0">
                                    <button type="button" className="p-2.5 text-slate-400 hover:text-white transition-colors rounded-full hover:bg-white/5">
                                        <Gift className="w-5 h-5" />
                                    </button>
                                    <button type="button" className="p-2.5 text-slate-400 hover:text-white transition-colors rounded-full hover:bg-white/5">
                                        <Paperclip className="w-5 h-5" />
                                    </button>
                                    {inputText.trim() ? (
                                        <button 
                                            type="submit"
                                            className="p-2.5 bg-white text-black rounded-full hover:bg-slate-200 transition-all"
                                        >
                                            <Send className="w-4 h-4 fill-current ml-0.5" />
                                        </button>
                                    ) : (
                                        <button type="button" className="p-2.5 text-slate-400 hover:text-white transition-colors rounded-full hover:bg-white/5">
                                            <Mic className="w-5 h-5" />
                                        </button>
                                    )}
                                </div>
                            </div>
                        </form>
                    </div>
                </>
            ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-8 opacity-40">
                    <div className="w-24 h-24 bg-[#252525] rounded-full flex items-center justify-center mb-6 shadow-2xl">
                        <MessageSquare className="w-10 h-10 text-slate-500" />
                    </div>
                    <h3 className="text-xl font-tiempos font-bold text-white mb-2">Direct Messages</h3>
                    <p className="text-sm text-slate-500 max-w-xs leading-relaxed">
                        Select a conversation from the list to start chatting with artists and venues.
                    </p>
                </div>
            )}
        </div>
    </div>
  );
};

// Helper for simple icons
function RefreshCw(props: any) {
    return (
        <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        >
        <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
        <path d="M21 3v5h-5" />
        <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
        <path d="M8 16H3v5" />
        </svg>
    )
}
