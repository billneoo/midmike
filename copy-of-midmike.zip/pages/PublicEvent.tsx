
import React, { useEffect, useState, useRef } from 'react';
import { api } from '../services/api';
import { EventEntity } from '../types';
import { 
  Calendar, MapPin, Ticket, Play, 
  CheckCircle2, Sparkles, ImageIcon, Star, 
  HelpCircle, ArrowUpRight, Globe, Instagram, Twitter,
  ShoppingBag, ShieldCheck, Share2, Video, ArrowRight
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface PublicEventProps {
  id?: string;
  onNavigate: (route: string) => void;
}

const PoweredByBadge = () => (
    <div className="flex flex-col items-center justify-center gap-4 py-20 select-none opacity-80 hover:opacity-100 transition-opacity duration-500 border-t border-white/5 mt-16">
        <div className="w-16 h-16 rounded-2xl flex items-center justify-center bg-white text-black shadow-2xl">
            <span className="font-tiempos font-black text-3xl tracking-tighter">M</span>
        </div>
        <div className="flex flex-col items-center">
            <span className="text-[10px] font-bold uppercase tracking-[0.3em] mb-1 text-mid-text-subtle">Powered By</span>
            <span className="text-3xl font-tiempos font-black tracking-tight leading-none text-white">MidMike</span>
        </div>
    </div>
);

export const PublicEvent: React.FC<PublicEventProps> = ({ id }) => {
  const [event, setEvent] = useState<EventEntity | null>(null);
  const [activeMediaIdx, setActiveMediaIdx] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [showFloatingCTA, setShowFloatingCTA] = useState(false);
  const { setAuthModalOpen } = useAuth();
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const load = async () => {
      // In a real app, fetch by ID. Here we mock or get featured.
      try {
        const data = await api.getEventDetails(id || 'e1'); 
        setEvent(data);
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, [id]);

  useEffect(() => {
    const handleScroll = () => {
        if (containerRef.current) {
            setShowFloatingCTA(containerRef.current.scrollTop > 100);
        }
    };
    const ref = containerRef.current;
    ref?.addEventListener('scroll', handleScroll);
    return () => ref?.removeEventListener('scroll', handleScroll);
  }, []);

  const handleShare = () => {
      const url = window.location.href;
      navigator.clipboard.writeText(url);
      alert("Event link copied to clipboard!");
  };

  const handleBook = () => {
      // Force auth for public users
      setAuthModalOpen(true);
  };

  if (isLoading || !event) {
    return (
      <div className="h-screen w-full bg-[#050505] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-mid-primary/20 border-t-mid-primary rounded-full animate-spin" />
      </div>
    );
  }

  const activeMedia = event.media?.[activeMediaIdx] || { type: 'image', url: event.imageUrl };

  const EventInfoBlock = () => (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
        <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-mid-primary/10 border border-mid-primary/20 text-mid-primary text-[9px] font-bold uppercase tracking-widest rounded-full flex items-center gap-1.5">
                <ShieldCheck className="w-3 h-3" /> Official Event
            </span>
        </div>
        <div className="space-y-6">
            <h1 className="text-4xl md:text-6xl font-inter font-semibold text-white leading-[1] tracking-tight">
                {event.title}
            </h1>
            <p className="text-slate-400 text-lg font-light leading-relaxed">
                {event.description}
            </p>
        </div>
        
        {/* Sticky Price Card */}
        <div className="bg-[#151515]/60 backdrop-blur-2xl border border-white/10 rounded-[32px] p-8 shadow-glass-deep space-y-8 relative overflow-hidden group">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 px-3 py-1 bg-red-500/10 border border-red-500/20 rounded-full w-fit">
                    <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(239,68,68,0.5)]" />
                    <span className="text-[9px] font-bold uppercase tracking-widest text-red-500">Selling Fast</span>
                </div>
                <button onClick={handleShare} className="p-2 text-slate-400 hover:text-white transition-colors" title="Share">
                    <Share2 className="w-4 h-4" />
                </button>
            </div>

            <div className="flex justify-between items-baseline border-b border-white/5 pb-6">
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Price</span>
                <span className="text-4xl font-tiempos text-white">{event.price}</span>
            </div>
            <div className="space-y-5">
                <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-white">
                        <Calendar className="w-5 h-5" />
                    </div>
                    <div>
                        <h4 className="text-xs font-bold text-white uppercase tracking-wider">Date</h4>
                        <p className="text-xs text-slate-400">{event.date}</p>
                    </div>
                </div>
                <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-white">
                        <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                        <h4 className="text-xs font-bold text-white uppercase tracking-wider">Location</h4>
                        <p className="text-xs text-slate-400">{event.location}</p>
                    </div>
                </div>
            </div>
            <button onClick={handleBook} className="w-full py-4 bg-mid-primary hover:bg-mid-primary/90 text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-glow-blue transition-all active:scale-95 flex items-center justify-center gap-3">
                <Ticket className="w-4 h-4" /> Secure Tickets
            </button>
            <div className="flex items-center justify-center gap-2 text-[9px] text-slate-400">
                <CheckCircle2 className="w-3 h-3 text-green-500" />
                <span>Login required to purchase</span>
            </div>
        </div>
    </div>
  );

  return (
    <div className="w-full h-screen bg-[#050505] text-white overflow-hidden relative font-inter flex flex-col">
        {/* Top Navigation for Public View */}
        <div className="flex-none bg-[#050505]/80 backdrop-blur-xl border-b border-white/5 px-6 py-4 flex items-center justify-between z-50">
            <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-white text-black flex items-center justify-center font-tiempos font-bold text-sm shadow-[0_0_15px_rgba(255,255,255,0.3)]">M</div>
                <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white">MidMike Live</span>
            </div>
            <div className="flex items-center gap-4">
                <button onClick={handleShare} className="text-slate-400 hover:text-white transition-colors flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest">
                    <Share2 className="w-4 h-4" /> <span className="hidden sm:inline">Share</span>
                </button>
                <button onClick={handleBook} className="px-5 py-2 bg-white text-black rounded-full text-[9px] font-black uppercase tracking-widest hover:bg-slate-200 transition-colors">
                    Sign In
                </button>
            </div>
        </div>

        <div className="flex-1 overflow-y-auto no-scrollbar custom-scrollbar relative scroll-smooth" ref={containerRef}>
            <div className="max-w-7xl mx-auto px-6 md:px-12 py-12 md:py-16 space-y-16 pb-40">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
                    <div className="lg:col-span-7 space-y-12">
                        
                        {/* 1. Media Section */}
                        <div className="space-y-6">
                            <div className="relative w-full aspect-square overflow-hidden bg-black shadow-2xl group border border-white/10 rounded-[32px]">
                                <div className="w-full h-full relative">
                                    {activeMedia.type === 'video' ? (
                                        <div className="w-full h-full bg-black flex items-center justify-center text-white/20">
                                            <Video className="w-16 h-16" />
                                        </div>
                                    ) : (
                                        <img 
                                            src={activeMedia.url} 
                                            className="w-full h-full object-cover" 
                                        />
                                    )}
                                </div>
                                <div className="absolute top-6 left-6 flex items-center gap-2 pointer-events-none">
                                    <span className="px-3 py-1.5 bg-white/10 backdrop-blur-md border border-white/20 text-white text-[9px] font-bold uppercase tracking-widest rounded-full">
                                        {event.category}
                                    </span>
                                    <span className="px-3 py-1.5 bg-black/40 backdrop-blur-md border border-white/10 text-white text-[9px] font-bold uppercase tracking-widest rounded-full">
                                        {event.isIndoor ? 'Indoor' : 'Outdoor'}
                                    </span>
                                </div>
                            </div>

                            {event.media && event.media.length > 1 && (
                                <div className="flex gap-4 overflow-x-auto pb-2 no-scrollbar">
                                    {event.media.map((m: any, i: number) => (
                                        <button key={i} onClick={() => setActiveMediaIdx(i)} className={`relative w-20 h-20 md:w-24 md:h-24 rounded-2xl overflow-hidden shrink-0 transition-all border-2 ${activeMediaIdx === i ? 'border-mid-primary scale-105' : 'border-white/5 opacity-60'}`}>
                                            <img src={m.type === 'video' ? m.thumbnail : m.url} className="w-full h-full object-cover" />
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>

                        <div className="block lg:hidden">
                            <EventInfoBlock />
                        </div>

                        {event.features && event.features.length > 0 && (
                            <div className="space-y-6">
                                <h3 className="text-xl font-bold uppercase tracking-widest text-white">Included</h3>
                                <div className="flex flex-wrap gap-4">
                                    {event.features.map((b: string, i: number) => (
                                        <div key={i} className="px-6 py-3 bg-white/[0.03] border border-white/10 rounded-2xl flex items-center gap-3">
                                            <Sparkles className="w-4 h-4 text-mid-primary" />
                                            <span className="text-xs font-bold uppercase tracking-wider text-white">{b}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {event.lineup && event.lineup.length > 0 && (
                            <div className="space-y-8">
                                <div className="flex items-end justify-between border-b border-white/10 pb-4">
                                    <h2 className="text-3xl font-tiempos text-white">Line-up</h2>
                                    <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Schedule</p>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {event.lineup.map((a: any, i: number) => (
                                        <div key={i} className="p-4 bg-white/[0.03] border border-white/10 rounded-2xl flex items-center gap-4">
                                            <div className="w-16 h-16 rounded-xl overflow-hidden bg-white/5 border border-white/10 shrink-0">
                                                <img src={a.imageUrl} className="w-full h-full object-cover" />
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <h4 className="text-base font-bold text-white truncate">{a.title}</h4>
                                                <div className="flex items-center gap-2 mt-1">
                                                    <span className="text-[9px] px-2 py-0.5 rounded bg-mid-primary/10 text-mid-primary font-bold uppercase">Artist</span>
                                                </div>
                                            </div>
                                            <ArrowUpRight className="w-4 h-4 text-slate-500" />
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {event.testimonials && event.testimonials.length > 0 && (
                            <div className="space-y-8">
                                <h2 className="text-3xl font-tiempos text-white">Vibe Check</h2>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    {event.testimonials.map((t) => (
                                        <div key={t.id} className="p-6 bg-white/[0.03] border border-white/10 rounded-[24px] space-y-4">
                                            <div className="flex items-center gap-3">
                                                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
                                                    <ImageIcon className="w-4 h-4 text-white" />
                                                </div>
                                                <div>
                                                    <h4 className="text-xs font-bold uppercase tracking-widest text-white">{t.name || 'Fan'}</h4>
                                                    <div className="flex text-mid-highlight"><Star className="w-2.5 h-2.5 fill-current" /><Star className="w-2.5 h-2.5 fill-current" /><Star className="w-2.5 h-2.5 fill-current" /><Star className="w-2.5 h-2.5 fill-current" /><Star className="w-2.5 h-2.5 fill-current" /></div>
                                                </div>
                                            </div>
                                            <p className="text-sm text-slate-400 italic">"{t.quote}"</p>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {event.organizer && (
                            <div className="relative overflow-hidden rounded-[40px] bg-[#050520] text-white text-center p-8 md:p-12 shadow-2xl border border-white/5 group mt-8">
                                <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
                                    <div className="w-full h-full bg-gradient-to-br from-mid-primary/40 to-black blur-[80px] opacity-60" />
                                    <div className="absolute inset-0 bg-[#050520]/60 mix-blend-multiply" />
                                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#050520]" />
                                </div>

                                <div className="relative z-10 flex flex-col items-center gap-6">
                                    <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/60">Hosted By</span>
                                    <div className="w-28 h-28 rounded-3xl p-1 bg-white/10 backdrop-blur-md border border-white/20 shadow-2xl overflow-hidden">
                                        <img src={event.organizer.avatar} className="w-full h-full object-cover rounded-2xl" />
                                    </div>
                                    <div className="space-y-2">
                                        <h3 className="text-3xl font-tiempos font-bold text-white tracking-tight">{event.organizer.name}</h3>
                                        <p className="text-[10px] text-white/50 font-medium tracking-widest uppercase">Verified Pro Organizer</p>
                                    </div>
                                    <div className="flex items-center gap-6 text-white/70 py-2">
                                        <Globe className="w-5 h-5 hover:text-white transition-colors cursor-pointer" />
                                        <Instagram className="w-5 h-5 hover:text-white transition-colors cursor-pointer" />
                                        <Twitter className="w-5 h-5 hover:text-white transition-colors cursor-pointer" />
                                    </div>
                                </div>
                            </div>
                        )}
                        
                        <PoweredByBadge />
                    </div>

                    <div className="hidden lg:block lg:col-span-5 relative">
                        <div className="sticky top-10">
                            <EventInfoBlock />
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div className={`absolute bottom-0 left-0 w-full z-[90] transition-all duration-500 bg-[#050505]/80 backdrop-blur-2xl border-t border-white/10 p-4 md:px-8 shadow-[0_-10px_40px_rgba(0,0,0,0.5)] ${showFloatingCTA ? 'translate-y-0 opacity-100' : 'translate-y-full opacity-0 pointer-events-none'}`}>
            <div className="max-w-[1400px] mx-auto flex items-center justify-between">
                <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-0.5">Total</span>
                    <div className="flex items-baseline gap-2">
                        <span className="text-xl font-tiempos font-bold text-white">{event.price}</span>
                        <span className="text-[10px] text-slate-500 font-bold uppercase">/ Person</span>
                    </div>
                </div>
                <button onClick={handleBook} className="px-8 py-3.5 bg-mid-primary hover:bg-mid-primary/90 text-white rounded-full font-bold text-[10px] uppercase tracking-[0.2em] shadow-glow-blue flex items-center gap-3 transition-all hover:scale-105 active:scale-95">
                    Book Now <ShoppingBag className="w-4 h-4" />
                </button>
            </div>
        </div>
    </div>
  );
};
