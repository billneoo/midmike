
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  X, Briefcase, Info, ImageIcon, Monitor, 
  Smartphone, Eye, Check, ChevronDown, Plus, Music, Sparkles,
  Send, Globe, MapPin, Tag, ShieldCheck, ShoppingBag, Zap, Flame, Layout, MessageCircle,
  Save, Calendar, Clock, Users, Mic2, Camera, Speaker, Utensils, Shield, Truck, FileText, 
  CheckCircle2, Star, Trash2, Quote, Globe2, MoreVertical, Play, Volume2, Flag, Languages, Shirt,
  Search, UserPlus, Image as LucideImage, Sofa, Car, MessageSquare, Upload, FileUp, 
  ChevronRight, Activity, TrendingUp, Filter, Heart, Tent, Rocket, User, ListPlus, HelpCircle,
  PlusCircle, CheckCircle, Video, ToggleLeft, ToggleRight, Sun, Cloud, PenTool, Ticket, ArrowUpRight, ArrowUp, Instagram, Twitter,
  PlayCircle, AlertTriangle, Share2, ExternalLink, ArrowRight, Copy
} from 'lucide-react';
import { OptimizedImage } from '../components/Card';
import { useAuth } from '../contexts/AuthContext';
import { mockArtists } from '../services/api';
import { Modal } from '../components/Modal';

// --- Constants ---

const EVENT_TYPES = ['Festival', 'Concert', 'Private Party', 'Wedding', 'Corporate', 'Exhibition'];
const LOCATIONS = ['Tunis', 'Sousse', 'Hammamet', 'Djerba', 'Bizerte', 'International'];
const HOURS = Array.from({ length: 12 }, (_, i) => (i + 1).toString().padStart(2, '0'));
const MINUTES = ['00', '15', '30', '45'];
const AMPM = ['AM', 'PM'];
const TIME_OPTIONS = HOURS.flatMap(h => MINUTES.flatMap(m => AMPM.map(p => `${h}:${m} ${p}`)));

const STEPS = [
  { id: 'media', label: 'Media', icon: LucideImage },
  { id: 'details', label: 'Event Details', icon: FileText },
  { id: 'benefits', label: 'What\'s included', icon: Sparkles },
  { id: 'artists', label: 'Artists & Schedule', icon: Mic2 },
  { id: 'reviews', label: 'Add Review', icon: Star },
  { id: 'creator', label: 'Identity', icon: User },
  { id: 'advanced', label: 'Policy', icon: ShieldCheck },
  { id: 'faq', label: 'FAQ', icon: HelpCircle },
];

const InputLabel = ({ children, required }: { children?: React.ReactNode, required?: boolean }) => (
  <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-[0.2em] mb-3 block">
      {children} {required && <span className="text-mid-accent">*</span>}
  </label>
);

const PoweredByBadge = ({ isPreview = false }: { isPreview?: boolean }) => (
    <div className="flex items-center justify-center gap-5 py-16 select-none opacity-80 hover:opacity-100 transition-opacity duration-500">
        <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-2xl ${isPreview ? 'bg-mid-primary text-white shadow-mid-primary/30' : 'bg-slate-900 dark:bg-white text-white dark:text-black shadow-slate-900/20 dark:shadow-white/20'}`}>
            <span className="font-tiempos font-black text-3xl tracking-tighter">M</span>
        </div>
        <div className="flex flex-col justify-center">
            <span className={`text-[11px] font-bold uppercase tracking-[0.3em] mb-1 ${isPreview ? 'text-white/60' : 'text-slate-500 dark:text-mid-text-subtle'}`}>Powered By</span>
            <span className={`text-4xl font-tiempos font-black tracking-tight leading-none ${isPreview ? 'text-white' : 'text-slate-900 dark:text-white'}`}>MidMike</span>
        </div>
    </div>
);

const CustomDropdown = ({ options, value, onChange, placeholder = "Select..." }: { options: string[], value: string, onChange: (val: string) => void, placeholder?: string }) => {
    const [isOpen, setIsOpen] = useState(false);
    const ref = useRef<HTMLDivElement>(null);
    useEffect(() => {
        const handleClick = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setIsOpen(false); };
        document.addEventListener('mousedown', handleClick);
        return () => document.removeEventListener('mousedown', handleClick);
    }, []);
    return (
        <div className="relative w-full" ref={ref}>
            <button type="button" onClick={() => setIsOpen(!isOpen)} className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-4 text-sm text-slate-900 dark:text-white text-left flex items-center justify-between shadow-inner hover:border-mid-primary/30 transition-all">
                <span className={`truncate ${value ? 'font-medium' : 'opacity-40'}`}>{value || placeholder}</span>
                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-300 flex-shrink-0 ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            {isOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-[#151515] border border-slate-200 dark:border-white/10 rounded-2xl shadow-2xl z-[110] max-h-60 overflow-y-auto no-scrollbar py-2 animate-in fade-in zoom-in-95">
                    {options.map(opt => (
                        <button key={opt} type="button" onClick={() => { onChange(opt); setIsOpen(false); }} className={`w-full text-left px-5 py-3 text-xs font-bold uppercase tracking-wider hover:bg-mid-primary/5 ${value === opt ? 'text-mid-primary bg-mid-primary/5' : 'text-slate-600 dark:text-slate-300'}`}>
                            {opt}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
};

const CustomTimeSelect = ({ value, onChange }: { value: string, onChange: (val: string) => void }) => {
    return <CustomDropdown options={TIME_OPTIONS} value={value} onChange={onChange} placeholder="00:00" />;
};

const CustomDateSelector = ({ value, onChange }: { value: string, onChange: (val: string) => void }) => {
    const today = new Date();
    const dateObj = value ? new Date(value) : today;
    const currentYear = today.getFullYear();
    const years = Array.from({ length: 5 }, (_, i) => (currentYear + i).toString());
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const days = Array.from({ length: 31 }, (_, i) => (i + 1).toString().padStart(2, '0'));
    const [selYear, setSelYear] = useState(dateObj.getFullYear().toString());
    const [selMonth, setSelMonth] = useState(months[dateObj.getMonth()]);
    const [selDay, setSelDay] = useState(dateObj.getDate().toString().padStart(2, '0'));
    useEffect(() => {
        const monthIndex = months.indexOf(selMonth);
        const newDate = new Date(parseInt(selYear), monthIndex, parseInt(selDay));
        const formatted = newDate.toISOString().split('T')[0];
        if (formatted !== value) {
            onChange(formatted);
        }
    }, [selYear, selMonth, selDay]);
    return (
        <div className="flex gap-2">
            <div className="w-[80px] flex-shrink-0">
                <CustomDropdown options={days} value={selDay} onChange={setSelDay} placeholder="DD" />
            </div>
            <div className="flex-1 min-w-0">
                <CustomDropdown options={months} value={selMonth} onChange={setSelMonth} placeholder="Month" />
            </div>
            <div className="w-[90px] flex-shrink-0">
                <CustomDropdown options={years} value={selYear} onChange={setSelYear} placeholder="YYYY" />
            </div>
        </div>
    );
};

const SectionWrapper: React.FC<{ id: string, title: string, subtitle?: string, icon: any, children: React.ReactNode }> = ({ id, title, subtitle, icon: Icon, children }) => (
  <div id={id} className="bg-white dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-[32px] mb-12 shadow-sm scroll-mt-24 transition-all hover:shadow-md relative">
    <div className="px-8 py-6 border-b border-slate-100 dark:border-white/5 flex items-center gap-4 bg-slate-50/50 dark:bg-white/[0.01] rounded-t-[32px]">
        <div className="w-12 h-12 rounded-2xl bg-mid-primary/10 flex items-center justify-center text-mid-primary border border-mid-primary/10">
            <Icon className="w-6 h-6" />
        </div>
        <div>
            <h3 className="text-sm font-black uppercase tracking-[0.2em] text-slate-900 dark:text-white leading-none mb-1.5">{title}</h3>
            {subtitle && <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">{subtitle}</p>}
        </div>
    </div>
    <div className="px-8 py-8 space-y-8">
        {children}
    </div>
  </div>
);

const ToggleSwitch = ({ label, checked, onChange }: { label: string, checked: boolean, onChange: (val: boolean) => void }) => (
    <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/5">
        <span className="text-[10px] font-bold uppercase tracking-widest text-slate-600 dark:text-slate-300">{label}</span>
        <button 
            onClick={() => onChange(!checked)}
            className={`w-12 h-6 rounded-full relative transition-colors duration-300 ${checked ? 'bg-mid-primary' : 'bg-slate-300 dark:bg-white/10'}`}
        >
            <div className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform duration-300 shadow-sm ${checked ? 'translate-x-6' : 'translate-x-0'}`} />
        </button>
    </div>
);

const MediaDropzone = ({ assets, onAdd, onRemove }: { assets: {url: string, type: 'image' | 'video'}[], onAdd: (files: FileList) => void, onRemove: (idx: number) => void }) => {
    const fileRef = useRef<HTMLInputElement>(null);
    return (
        <div className="space-y-6">
            <div 
                onClick={() => fileRef.current?.click()}
                className="border-2 border-dashed border-slate-200 dark:border-white/10 rounded-[32px] h-64 flex flex-col items-center justify-center gap-6 hover:bg-slate-50 dark:hover:bg-white/[0.02] transition-all cursor-pointer group bg-slate-50/30 dark:bg-black/10 hover:border-mid-primary/30"
            >
                <input type="file" multiple ref={fileRef} className="hidden" accept="image/*,video/*" onChange={(e) => e.target.files && onAdd(e.target.files)} />
                <div className="w-20 h-20 rounded-full bg-white dark:bg-white/5 flex items-center justify-center text-slate-300 group-hover:text-mid-primary group-hover:scale-110 transition-all border border-slate-100 dark:border-white/5 shadow-xl">
                    <Upload className="w-8 h-8" />
                </div>
                <div className="text-center space-y-1">
                    <p className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-[0.2em]">Upload High-Res Media</p>
                    <p className="text-[10px] text-slate-400 dark:text-mid-text-subtle uppercase tracking-widest">Supports JPG, PNG, MP4</p>
                </div>
            </div>

            {assets.length > 0 && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                    {assets.map((asset, i) => (
                        <div key={i} className="relative aspect-square rounded-2xl overflow-hidden border border-slate-200 dark:border-white/10 group shadow-lg bg-black">
                            {asset.type === 'video' ? (
                                <div className="w-full h-full flex items-center justify-center text-white/50">
                                    <Video className="w-8 h-8" />
                                </div>
                            ) : (
                                <img src={asset.url} className="w-full h-full object-cover" />
                            )}
                            <button 
                                onClick={(e) => { e.stopPropagation(); onRemove(i); }}
                                className="absolute top-2 right-2 p-2 bg-red-500/80 hover:bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-all backdrop-blur-md scale-90 hover:scale-100"
                            >
                                <Trash2 className="w-3.5 h-3.5" />
                            </button>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

// --- MicrositePreview Component ---

const MicrositePreview = ({ data }: { data: any }) => {
  const [activeMediaIdx, setActiveMediaIdx] = useState(0);
  const [showFloatingCTA, setShowFloatingCTA] = useState(false);
  const priceCardRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const activeMedia = data.media[activeMediaIdx] || (data.media[0] || { url: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?q=80&w=1200", type: 'image' });

  useEffect(() => {
      const handleScroll = () => {
          if (containerRef.current) {
              setShowFloatingCTA(containerRef.current.scrollTop > 100);
          }
      };
      const ref = containerRef.current;
      ref?.addEventListener('scroll', handleScroll);
      return () => ref?.removeEventListener('scroll', handleScroll);
  }, []);

  const EventInfoBlock = () => (
    <div className="space-y-8">
        <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-mid-primary/10 border border-mid-primary/20 text-mid-primary text-[9px] font-bold uppercase tracking-widest rounded-full flex items-center gap-1.5">
                <CheckCircle className="w-3 h-3" /> Draft Event
            </span>
        </div>
        <div className="space-y-6">
            <h1 className="text-4xl md:text-5xl font-tiempos font-medium leading-tight tracking-tight text-white">
                {data.title || "Event Title"}
            </h1>
            <p className="text-slate-400 text-lg font-light leading-relaxed">
                {data.description || "Add a description to preview how your event details will look here."}
            </p>
        </div>
        <div className="bg-[#151515]/80 backdrop-blur-2xl border border-white/10 rounded-[32px] p-8 shadow-glass-deep space-y-8 relative overflow-hidden group">
            <div className="flex items-center gap-2 px-3 py-1 bg-red-500/10 border border-red-500/20 rounded-full w-fit mb-2 animate-in fade-in zoom-in duration-500">
                <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(239,68,68,0.5)]" />
                <span className="text-[9px] font-bold uppercase tracking-widest text-red-500">24 people viewing</span>
            </div>
            <div className="flex justify-between items-baseline border-b border-white/5 pb-6">
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Price</span>
                <span className="text-4xl font-tiempos text-white">{data.price ? `${data.price} TND` : 'Free'}</span>
            </div>
            <div className="space-y-5">
                <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-white">
                        <Calendar className="w-5 h-5" />
                    </div>
                    <div>
                        <h4 className="text-xs font-bold text-white uppercase tracking-wider">Date</h4>
                        <p className="text-xs text-slate-400">{data.startDate || 'TBD'}</p>
                    </div>
                </div>
                <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-white">
                        <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                        <h4 className="text-xs font-bold text-white uppercase tracking-wider">Location</h4>
                        <p className="text-xs text-slate-400">{data.location}</p>
                    </div>
                </div>
                {data.capacity && (
                    <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-white">
                            <Users className="w-5 h-5" />
                        </div>
                        <div>
                            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Capacity</h4>
                            <p className="text-xs text-slate-400">{data.capacity} Guests</p>
                        </div>
                    </div>
                )}
            </div>
            <button className="w-full py-4 bg-mid-primary hover:bg-mid-primary/90 text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-glow-blue transition-all active:scale-95 flex items-center justify-center gap-3">
                <Ticket className="w-4 h-4" /> Secure Pass
            </button>
            <div className="flex items-center justify-center gap-2 text-[9px] text-slate-400">
                <CheckCircle2 className="w-3 h-3 text-green-500" />
                <span>Official Partner Ticket</span>
            </div>
        </div>
    </div>
  );

  return (
    <div className="w-full h-full bg-[#191919] text-white overflow-hidden relative font-inter flex flex-col">
        <div className="flex-none bg-[#191919]/80 backdrop-blur-xl border-b border-white/5 px-6 py-4 flex items-center justify-between z-50">
            <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-mid-primary flex items-center justify-center font-tiempos font-bold text-white text-sm">M</div>
                <div className="flex flex-col">
                    <span className="text-[9px] font-bold uppercase tracking-widest text-white">Preview Mode</span>
                    <span className="text-[7px] text-slate-500 uppercase tracking-widest">Live</span>
                </div>
            </div>
        </div>

        <div className="flex-1 overflow-y-auto no-scrollbar custom-scrollbar relative scroll-smooth" ref={containerRef}>
            <div className="max-w-7xl mx-auto px-6 md:px-12 py-12 md:py-16 space-y-16 pb-40">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
                    <div className="lg:col-span-7 space-y-12">
                        {/* 1. Media Section - Forced 1:1 Aspect Ratio on Container */}
                        <div className="space-y-6">
                            <div className="relative w-full aspect-square overflow-hidden bg-black shadow-2xl group border border-white/10 rounded-[32px]">
                                <div className="w-full h-full relative">
                                    {activeMedia.type === 'video' ? (
                                        <div className="w-full h-full bg-black flex items-center justify-center text-white/20">
                                            <Video className="w-16 h-16" />
                                        </div>
                                    ) : (
                                        <img 
                                            src={activeMedia.url} 
                                            className="w-full h-full object-cover" 
                                        />
                                    )}
                                </div>
                                <div className="absolute top-6 left-6 flex items-center gap-2 pointer-events-none">
                                    <span className="px-3 py-1.5 bg-white/10 backdrop-blur-md border border-white/20 text-white text-[9px] font-bold uppercase tracking-widest rounded-full">
                                        {data.category}
                                    </span>
                                    <span className="px-3 py-1.5 bg-black/40 backdrop-blur-md border border-white/10 text-white text-[9px] font-bold uppercase tracking-widest rounded-full">
                                        {data.isIndoor ? 'Indoor' : 'Outdoor'}
                                    </span>
                                </div>
                            </div>

                            {data.media.length > 1 && (
                                <div className="flex gap-4 overflow-x-auto pb-2 no-scrollbar">
                                    {data.media.map((m: any, i: number) => (
                                        <button key={i} onClick={() => setActiveMediaIdx(i)} className={`relative w-20 h-20 md:w-24 md:h-24 rounded-2xl overflow-hidden shrink-0 transition-all border-2 ${activeMediaIdx === i ? 'border-mid-primary scale-105' : 'border-white/5 opacity-60'}`}>
                                            {m.type === 'video' ? <div className="w-full h-full bg-slate-900 flex items-center justify-center"><Video className="w-4 h-4" /></div> : <img src={m.url} className="w-full h-full object-cover" />}
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>

                        <div className="block lg:hidden">
                            <EventInfoBlock />
                        </div>

                        {data.benefits.length > 0 && (
                            <div className="space-y-6">
                                <h3 className="text-xl font-bold uppercase tracking-widest text-white">Included</h3>
                                <div className="flex flex-wrap gap-4">
                                    {data.benefits.map((b: string, i: number) => (
                                        <div key={i} className="px-6 py-3 bg-white/[0.03] border border-white/10 rounded-2xl flex items-center gap-3">
                                            <Sparkles className="w-4 h-4 text-mid-primary" />
                                            <span className="text-xs font-bold uppercase tracking-wider text-white">{b}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {data.selectedArtists.length > 0 && (
                            <div className="space-y-8">
                                <div className="flex items-end justify-between border-b border-white/10 pb-4">
                                    <h2 className="text-3xl font-tiempos text-white">Line-up</h2>
                                    <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Schedule</p>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {data.selectedArtists.map((a: any, i: number) => (
                                        <div key={i} className="p-4 bg-white/[0.03] border border-white/10 rounded-2xl flex items-center gap-4">
                                            <div className="w-16 h-16 rounded-xl overflow-hidden bg-white/5 border border-white/10 shrink-0">
                                                {a.image ? (
                                                    <img src={a.image} className="w-full h-full object-cover" />
                                                ) : (
                                                    <div className="w-full h-full flex items-center justify-center font-bold text-xs">IMG</div>
                                                )}
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <h4 className="text-base font-bold text-white truncate">{a.name}</h4>
                                                <div className="flex items-center gap-2 mt-1">
                                                    <span className="text-[9px] px-2 py-0.5 rounded bg-mid-primary/10 text-mid-primary font-bold uppercase">Set: {a.setTime}</span>
                                                </div>
                                            </div>
                                            <ArrowUpRight className="w-4 h-4 text-slate-500" />
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {data.testimonials.length > 0 && (
                            <div className="space-y-8">
                                <h2 className="text-3xl font-tiempos text-white">Vibe Check</h2>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    {data.testimonials.map((t: any) => (
                                        <div key={t.id} className="p-6 bg-white/[0.03] border border-white/10 rounded-[24px] space-y-4">
                                            <div className="flex items-center gap-3">
                                                {t.type === 'manual' ? (
                                                    <div className="w-10 h-10 rounded-full overflow-hidden bg-white/10 border border-white/10">
                                                        {t.photo ? <img src={t.photo} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-[10px] font-bold">IMG</div>}
                                                    </div>
                                                ) : (
                                                    <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
                                                        <ImageIcon className="w-4 h-4 text-white" />
                                                    </div>
                                                )}
                                                <div>
                                                    <h4 className="text-xs font-bold uppercase tracking-widest text-white">{t.name || 'Proof'}</h4>
                                                    <div className="flex text-mid-highlight"><Star className="w-2.5 h-2.5 fill-current" /><Star className="w-2.5 h-2.5 fill-current" /><Star className="w-2.5 h-2.5 fill-current" /><Star className="w-2.5 h-2.5 fill-current" /><Star className="w-2.5 h-2.5 fill-current" /></div>
                                                </div>
                                            </div>
                                            {t.type === 'manual' ? (
                                                <p className="text-sm text-slate-400 italic">"{t.quote}"</p>
                                            ) : (
                                                <div className="aspect-video rounded-xl overflow-hidden bg-black/20 border border-white/10">
                                                    <img src={t.screenshot} className="w-full h-full object-cover opacity-80" />
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {data.displayIdentity && (
                            <div className="relative overflow-hidden rounded-[40px] bg-[#050520] text-white text-center p-8 md:p-12 shadow-2xl border border-white/5 group mt-8">
                                <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
                                    <div className="w-full h-full bg-gradient-to-br from-mid-primary/40 to-black blur-[80px] opacity-60" />
                                    <div className="absolute inset-0 bg-[#050520]/60 mix-blend-multiply" />
                                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#050520]" />
                                </div>

                                <div className="relative z-10 flex flex-col items-center gap-6">
                                    <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/60">Hosted By</span>
                                    
                                    <div className="w-28 h-28 rounded-3xl p-1 bg-white/10 backdrop-blur-md border border-white/20 shadow-2xl overflow-hidden hover:scale-105 transition-transform duration-500 rotate-3 hover:rotate-0">
                                        <div className="w-full h-full bg-black flex items-center justify-center text-2xl font-bold">ME</div>
                                    </div>

                                    <div className="space-y-2">
                                        <h3 className="text-3xl font-tiempos font-bold text-white tracking-tight">You (Organizer)</h3>
                                        <p className="text-[10px] text-white/50 font-medium tracking-widest uppercase">@yourhandle • Verified Pro</p>
                                    </div>

                                    <div className="flex items-center gap-6 text-white/70 py-2">
                                        <Globe className="w-5 h-5 hover:text-white transition-colors cursor-pointer" />
                                        <Instagram className="w-5 h-5 hover:text-white transition-colors cursor-pointer" />
                                        <Twitter className="w-5 h-5 hover:text-white transition-colors cursor-pointer" />
                                    </div>

                                    {data.displayMessaging && (
                                        <div className="w-full max-w-md relative mt-4">
                                            <div className="w-full bg-black/30 border border-white/10 rounded-full py-4 pl-6 pr-14 text-sm text-white/50 text-left shadow-inner backdrop-blur-sm cursor-not-allowed">
                                                Send direct message...
                                            </div>
                                            <div className="absolute right-2 top-2 p-2 bg-mid-primary text-white rounded-full shadow-lg flex items-center justify-center">
                                                <ArrowUp className="w-5 h-5" />
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                        {data.faqs.length > 0 && (
                            <div className="space-y-6 pt-8 border-t border-white/10">
                                <h3 className="text-xl font-tiempos text-white">Common Questions</h3>
                                <div className="grid grid-cols-1 gap-4">
                                    {data.faqs.map((f: any) => (
                                        <div key={f.id} className="bg-white/5 border border-white/10 rounded-2xl p-6">
                                            <h4 className="text-sm font-bold text-white mb-2 flex items-start gap-3">
                                                <HelpCircle className="w-4 h-4 text-mid-secondary shrink-0 mt-0.5" />
                                                {f.q}
                                            </h4>
                                            <p className="text-xs text-slate-400 pl-7 leading-relaxed">{f.a}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                        
                        <div className="pt-12 border-t border-white/10">
                            <PoweredByBadge isPreview={true} />
                        </div>
                    </div>

                    <div className="hidden lg:block lg:col-span-5 relative">
                        <div className="sticky top-10" ref={priceCardRef}>
                            <EventInfoBlock />
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div className={`absolute bottom-0 left-0 w-full z-[90] transition-all duration-500 bg-[#191919]/30 backdrop-blur-2xl border-t border-white/10 p-4 md:px-8 shadow-[0_-10px_40px_rgba(0,0,0,0.5)] ${showFloatingCTA ? 'translate-y-0 opacity-100' : 'translate-y-full opacity-0 pointer-events-none'}`}>
            <div className="max-w-[1400px] mx-auto flex items-center justify-between">
                <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-0.5">Total</span>
                    <div className="flex items-baseline gap-2">
                        <span className="text-xl font-tiempos font-bold text-white">{data.price ? `${data.price} TND` : 'Free'}</span>
                        <span className="text-[10px] text-slate-500 font-bold uppercase">/ Person</span>
                    </div>
                </div>
                <button className="px-8 py-3.5 bg-mid-primary hover:bg-mid-primary/90 text-white rounded-full font-bold text-[10px] uppercase tracking-[0.2em] shadow-glow-blue flex items-center gap-3 transition-all hover:scale-105 active:scale-95">
                    Book Now <ShoppingBag className="w-4 h-4" />
                </button>
            </div>
        </div>
    </div>
  );
};

// --- Main Architect Component ---

export const CreateEventWizard: React.FC<{ onNavigate: (route: string) => void; onOpenQuickStart?: () => void }> = ({ onNavigate, onOpenQuickStart }) => {
    const { user } = useAuth();
    const [activeStepId, setActiveStepId] = useState('media');
    const [showMobilePreview, setShowMobilePreview] = useState(false);
    const [showPublishModal, setShowPublishModal] = useState(false);
    const [shareLink, setShareLink] = useState('');
    
    // Search Logic
    const [artistSearchQuery, setArtistSearchQuery] = useState('');
    const [artistSearchResults, setArtistSearchResults] = useState<any[]>([]);
    
    // Main Form State
    const [formData, setFormData] = useState({
        media: [] as {url: string, type: 'image' | 'video'}[],
        title: '', category: 'Festival', location: 'Tunis',
        startDate: '', startTime: '20:00 PM', endDate: '', endTime: '06:00 AM',
        address: '', capacity: '5000', price: '', isIndoor: true, description: '',
        benefits: [] as string[],
        selectedArtists: [] as { id: number, name: string, image: string | null, setTime: string }[],
        displayIdentity: true, displayMessaging: true,
        newArtistName: '', newArtistTime: '22:00 PM', newArtistAvatar: null as string | null, isAddingArtist: false,
        testimonials: [] as { id: number, type: 'manual' | 'screenshot', name: string, quote?: string, photo?: string | null, screenshot?: string | null }[],
        policy: 'Standard Cancellation Policy', termsAccepted: false,
        faqs: [] as { id: number, q: string, a: string }[],
        newFaqQ: '', newFaqA: ''
    });

    const handleScrollTo = (id: string) => {
      setActiveStepId(id);
      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };

    const updateArray = (key: 'benefits' | 'selectedArtists' | 'faqs' | 'testimonials', action: 'add' | 'remove', value?: any, idx?: number) => {
        setFormData(prev => {
            const list = [...(prev[key] as any[])];
            if (action === 'add') list.push(value);
            else list.splice(idx!, 1);
            return { ...prev, [key]: list };
        });
    };

    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, callback: (url: string) => void) => {
        const file = e.target.files?.[0];
        if (file) {
            const url = URL.createObjectURL(file);
            callback(url);
        }
    };

    // Artist Search Effect
    useEffect(() => {
        if (artistSearchQuery.length > 0) {
            const results = mockArtists.filter(a => a.title.toLowerCase().includes(artistSearchQuery.toLowerCase()));
            setArtistSearchResults(results);
        } else { setArtistSearchResults([]); }
    }, [artistSearchQuery]);

    const handleAddArtistFromSearch = (artist: any) => {
        const newArtist = {
            id: Date.now(),
            name: artist.title,
            image: artist.imageUrl,
            setTime: '22:00 PM'
        };
        setFormData(prev => ({
            ...prev,
            selectedArtists: [...prev.selectedArtists, newArtist]
        }));
        setArtistSearchQuery('');
        setArtistSearchResults([]);
    };

    const handleAddArtistManual = () => {
        if (!formData.newArtistName) return;
        const newArtist = {
            id: Date.now(),
            name: formData.newArtistName,
            image: formData.newArtistAvatar,
            setTime: formData.newArtistTime
        };
        setFormData(prev => ({
            ...prev,
            selectedArtists: [...prev.selectedArtists, newArtist],
            newArtistName: '',
            newArtistTime: '22:00 PM',
            newArtistAvatar: null,
            isAddingArtist: false
        }));
    };

    const handleAddFaq = () => {
        if (!formData.newFaqQ || !formData.newFaqA) return;
        const newFaqItem = {
            id: Date.now(),
            q: formData.newFaqQ,
            a: formData.newFaqA
        };
        setFormData(prev => ({
            ...prev,
            faqs: [...prev.faqs, newFaqItem],
            newFaqQ: '',
            newFaqA: ''
        }));
    };

    const handlePublish = () => {
        if (!formData.termsAccepted) return alert("Please accept the terms and conditions.");
        
        // Generate mock public link
        const mockId = Math.random().toString(36).substr(2, 6);
        
        // Construct URL for the 'public-event' route
        // We use window.location.search to determine base, but here we just replace or append
        const baseUrl = window.location.href.split('?')[0];
        const link = `${baseUrl}?route=public-event&id=${mockId}`;
        
        setShareLink(link);
        setShowPublishModal(true);
    };

    const copyToClipboard = () => {
        navigator.clipboard.writeText(shareLink);
        alert("Link copied to clipboard!");
    };

    return (
        <div className="flex flex-col lg:flex-row h-[calc(100vh-100px)] bg-[#F9FAFB] dark:bg-mid-bg overflow-hidden rounded-3xl border border-slate-200 dark:border-white/10 shadow-glass animate-cinematic-fade relative">
            {/* Sidebar Logic */}
            <aside className="w-full lg:w-[48%] flex flex-col h-full border-r border-slate-200 dark:border-white/5 relative z-10 bg-white dark:bg-black/10">
                <div className="flex-none h-16 border-b border-slate-200 dark:border-white/5 flex items-center justify-between px-6 bg-white dark:bg-[#121212] z-20">
                    <div className="flex items-center gap-4">
                        <button onClick={() => onNavigate('home')} className="p-2 -ml-2 text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"><X className="w-5 h-5" /></button>
                        <div className="flex items-center gap-2">
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Events</span>
                            <ChevronRight className="w-3 h-3 text-slate-400" />
                            <span className="text-[10px] font-black text-slate-900 dark:text-white uppercase tracking-widest">Create Event</span>
                        </div>
                    </div>
                    <div className="flex items-center gap-3">
                        <button onClick={() => setShowMobilePreview(true)} className="lg:hidden px-4 py-2 bg-slate-100 dark:bg-white/10 rounded-full text-[10px] font-bold text-mid-primary uppercase tracking-widest flex items-center gap-2 hover:bg-slate-200 dark:hover:bg-white/20 transition-all">
                            <Eye className="w-3.5 h-3.5" /> Preview
                        </button>
                    </div>
                </div>
                
                {/* Quick Start Notification Banner */}
                <div className="bg-blue-500/10 border-b border-blue-500/20 px-6 py-3 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="w-6 h-6 rounded-full bg-blue-500 flex items-center justify-center shadow-lg shrink-0">
                            <PlayCircle className="w-3.5 h-3.5 text-white" />
                        </div>
                        <div>
                            <p className="text-[10px] text-slate-700 dark:text-white font-bold uppercase tracking-wide">First time?</p>
                            <p className="text-[10px] text-slate-500 dark:text-blue-200">
                                Check the <span onClick={onOpenQuickStart} className="underline decoration-blue-500 cursor-pointer hover:text-blue-500 transition-colors">Quick Start Guide</span> to create the perfect event.
                            </p>
                        </div>
                    </div>
                    <button onClick={onOpenQuickStart} className="text-blue-500 hover:text-blue-400"><ArrowRight className="w-4 h-4" /></button>
                </div>
                
                <div className="flex-1 flex overflow-hidden relative">
                    {/* Steps Nav */}
                    <div className="hidden sm:flex flex-col gap-2 p-4 border-r border-slate-100 dark:border-white/5 bg-slate-50/50 dark:bg-black/20 w-16 md:w-20 items-center overflow-y-auto no-scrollbar pb-24">
                        {STEPS.map(s => (
                            <button key={s.id} onClick={() => handleScrollTo(s.id)} className={`w-10 h-10 md:w-12 md:h-12 rounded-2xl flex items-center justify-center transition-all ${activeStepId === s.id ? 'bg-mid-primary text-white shadow-glow-blue' : 'bg-white dark:bg-white/5 text-slate-400 hover:text-slate-900 dark:hover:text-white'}`}>
                                <s.icon className="w-5 h-5" />
                            </button>
                        ))}
                    </div>

                    <div className="flex-1 overflow-y-auto custom-scrollbar px-6 md:px-10 py-10 space-y-6 pb-32">
                        <SectionWrapper id="media" title="Upload Media" icon={LucideImage}>
                            <MediaDropzone assets={formData.media} onAdd={(files) => {
                                const urls = Array.from(files).map(f => ({url: URL.createObjectURL(f), type: f.type.startsWith('video') ? 'video' : 'image'})) as any[];
                                setFormData(p => ({...p, media: [...p.media, ...urls].slice(0, 10)}));
                            }} onRemove={(idx) => setFormData(p => ({...p, media: p.media.filter((_, i) => i !== idx)}))} />
                        </SectionWrapper>

                        <SectionWrapper id="details" title="Event Details" icon={FileText}>
                            <div className="space-y-6">
                                <InputGroup label="Event Title *">
                                    <input className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-4 text-sm text-slate-900 dark:text-white font-bold" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} placeholder="e.g. Midnight Summer Fest" />
                                </InputGroup>
                                
                                <div className="grid grid-cols-2 gap-4">
                                    <InputGroup label="Category*"><CustomDropdown options={EVENT_TYPES} value={formData.category} onChange={val => setFormData({...formData, category: val})} /></InputGroup>
                                    <InputGroup label="Location*"><CustomDropdown options={LOCATIONS} value={formData.location} onChange={val => setFormData({...formData, location: val})} /></InputGroup>
                                </div>

                                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                    <div className="space-y-4">
                                        <InputLabel>Start Date & Time *</InputLabel>
                                        <div className="space-y-3">
                                            <CustomDateSelector value={formData.startDate} onChange={val => setFormData({...formData, startDate: val})} />
                                            <CustomTimeSelect value={formData.startTime} onChange={val => setFormData({...formData, startTime: val})} />
                                        </div>
                                    </div>
                                    <div className="space-y-4">
                                        <InputLabel>End Date & Time *</InputLabel>
                                        <div className="space-y-3">
                                            <CustomDateSelector value={formData.endDate} onChange={val => setFormData({...formData, endDate: val})} />
                                            <CustomTimeSelect value={formData.endTime} onChange={val => setFormData({...formData, endTime: val})} />
                                        </div>
                                    </div>
                                </div>

                                <InputGroup label="Full Address">
                                    <input className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-4 text-sm text-slate-900 dark:text-white" value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} placeholder="Street, City, Zip" />
                                </InputGroup>

                                <div className="grid grid-cols-2 gap-4">
                                    <InputGroup label="Capacity">
                                        <input className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-4 text-sm text-slate-900 dark:text-white" type="number" value={formData.capacity} onChange={e => setFormData({...formData, capacity: e.target.value})} placeholder="500" />
                                    </InputGroup>
                                    <InputGroup label="Ticket Price (TND)">
                                        <input className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-4 text-sm text-slate-900 dark:text-white" type="number" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} placeholder="30" />
                                    </InputGroup>
                                </div>
                                
                                <div>
                                    <InputLabel>Environment Setting *</InputLabel>
                                    <div className="flex gap-4">
                                        <button onClick={() => setFormData({...formData, isIndoor: true})} className={`flex-1 p-4 rounded-2xl border transition-all flex flex-col items-center gap-2 ${formData.isIndoor ? 'bg-mid-primary/10 border-mid-primary text-mid-primary shadow-glow-blue' : 'bg-slate-50 dark:bg-black/20 border-slate-200 dark:border-white/10 text-slate-400'}`}>
                                            <div className="w-10 h-10 rounded-full bg-white dark:bg-white/10 flex items-center justify-center"><Sofa className="w-5 h-5" /></div>
                                            <span className="text-[10px] font-bold uppercase tracking-widest">Indoor</span>
                                        </button>
                                        <button onClick={() => setFormData({...formData, isIndoor: false})} className={`flex-1 p-4 rounded-2xl border transition-all flex flex-col items-center gap-2 ${!formData.isIndoor ? 'bg-mid-primary/10 border-mid-primary text-mid-primary shadow-glow-blue' : 'bg-slate-50 dark:bg-black/20 border-slate-200 dark:border-white/10 text-slate-400'}`}>
                                            <div className="w-10 h-10 rounded-full bg-white dark:bg-white/10 flex items-center justify-center"><Cloud className="w-5 h-5" /></div>
                                            <span className="text-[10px] font-bold uppercase tracking-widest">Outdoor</span>
                                        </button>
                                    </div>
                                </div>

                                <InputGroup label="Event Brief">
                                    <textarea className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-2xl p-5 text-sm h-32 focus:border-mid-primary focus:outline-none resize-none" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} placeholder="Describe the atmosphere..." />
                                </InputGroup>
                            </div>
                        </SectionWrapper>

                        {/* ... (Other sections unchanged) ... */}
                        
                        {/* Shortened for brevity, preserving existing structure and logic */}
                        <SectionWrapper id="benefits" title="What's included" icon={Sparkles}>
                            <div className="space-y-4">
                                <div className="flex gap-2">
                                    <input className="flex-1 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-2xl px-5 py-4 text-sm" id="benefit-input" placeholder="Add up to 5 benefits" />
                                    <button onClick={() => { const i = document.getElementById('benefit-input') as HTMLInputElement; if(i.value && formData.benefits.length < 5) { updateArray('benefits', 'add', i.value); i.value=''; } }} className="px-6 bg-mid-primary text-white rounded-2xl shadow-glow-blue"><Plus className="w-6 h-6" /></button>
                                </div>
                                <div className="flex flex-wrap gap-2">
                                    {formData.benefits.map((b, i) => (
                                        <div key={i} className="flex items-center gap-3 px-4 py-2 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-200 dark:border-white/10">
                                            <span className="text-[10px] font-bold uppercase tracking-widest">{b}</span>
                                            <button onClick={() => updateArray('benefits', 'remove', undefined, i)} className="p-1 text-slate-400 hover:text-red-500"><X className="w-3.5 h-3.5" /></button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </SectionWrapper>

                        <SectionWrapper id="artists" title="Artists & Schedule" icon={Mic2}>
                            <div className="space-y-8">
                                <div className="space-y-4">
                                    <div className="relative group">
                                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-mid-primary transition-colors" />
                                        <input 
                                            className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold focus:border-mid-primary focus:outline-none transition-all" 
                                            placeholder="Search Global Artist Database..." 
                                            value={artistSearchQuery}
                                            onChange={(e) => setArtistSearchQuery(e.target.value)}
                                        />
                                        {artistSearchQuery.length > 0 && (
                                            <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-[#151515] border border-slate-200 dark:border-white/10 rounded-2xl shadow-2xl z-[100] max-h-60 overflow-y-auto no-scrollbar py-2 animate-in fade-in zoom-in-95">
                                                {artistSearchResults.length > 0 ? (
                                                    artistSearchResults.map(artist => (
                                                        <button 
                                                            key={artist.id}
                                                            onClick={() => handleAddArtistFromSearch(artist)}
                                                            className="w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-50 dark:hover:bg-white/5 transition-colors text-left group border-b border-slate-100 dark:border-white/5 last:border-0"
                                                        >
                                                            <div className="w-10 h-10 rounded-lg bg-slate-200 dark:bg-white/10 overflow-hidden shrink-0 border border-slate-100 dark:border-white/5">
                                                                <img src={artist.imageUrl} className="w-full h-full object-cover" alt={artist.title} />
                                                            </div>
                                                            <div className="flex-1 min-w-0">
                                                                <span className="block text-sm font-bold text-slate-900 dark:text-white truncate">{artist.title}</span>
                                                                <span className="block text-[10px] text-slate-500 uppercase tracking-wider">{artist.profession}</span>
                                                            </div>
                                                            <Plus className="w-5 h-5 text-mid-primary opacity-0 group-hover:opacity-100 transition-opacity" />
                                                        </button>
                                                    ))
                                                ) : (
                                                    <div className="px-4 py-6 text-center">
                                                        <p className="text-xs font-bold text-slate-500 dark:text-slate-400">No artists found matching "{artistSearchQuery}"</p>
                                                        <p className="text-[10px] text-slate-400 dark:text-mid-text-subtle mt-1">Try using the manual entry below.</p>
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                </div>
                                <div className="p-6 rounded-[24px] bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10">
                                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle mb-4">Add To Lineup (Manual)</h4>
                                    <div className="space-y-4">
                                        <div className="flex items-center gap-4">
                                            <label className="w-16 h-16 rounded-2xl bg-white dark:bg-white/5 border-2 border-dashed border-slate-300 dark:border-white/10 flex items-center justify-center cursor-pointer hover:border-mid-primary transition-all group">
                                                {formData.newArtistAvatar ? <img src={formData.newArtistAvatar} className="w-full h-full object-cover rounded-2xl" /> : <Camera className="w-5 h-5 text-slate-400 group-hover:text-mid-primary" />}
                                                <input type="file" className="hidden" accept="image/*" onChange={e => handleFileUpload(e, (url) => setFormData({...formData, newArtistAvatar: url}))} />
                                            </label>
                                            <div className="flex-1 space-y-3">
                                                <input className="w-full bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-xs font-bold" placeholder="Artist Name / Group" value={formData.newArtistName} onChange={e => setFormData({...formData, newArtistName: e.target.value})} />
                                                <CustomTimeSelect value={formData.newArtistTime} onChange={val => setFormData({...formData, newArtistTime: val})} />
                                            </div>
                                        </div>
                                        <button onClick={handleAddArtistManual} disabled={!formData.newArtistName} className="w-full py-3 bg-mid-primary text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-glow-blue disabled:opacity-50 hover:bg-mid-primary/90 transition-all">Add To Schedule</button>
                                    </div>
                                </div>
                                <div className="space-y-3">
                                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-400 dark:text-mid-text-subtle text-center">Current Schedule</h4>
                                    {formData.selectedArtists.length === 0 && <p className="text-center text-xs text-slate-400 italic">No artists added yet.</p>}
                                    {formData.selectedArtists.map((a, i) => (
                                        <div key={i} className="flex items-center gap-4 p-3 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-2xl group">
                                            <div className="w-10 h-10 rounded-xl bg-slate-200 dark:bg-white/10 overflow-hidden shrink-0">
                                                {a.image ? <img src={a.image} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-[9px] font-black">{a.name.charAt(0)}</div>}
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <h5 className="text-xs font-bold text-slate-900 dark:text-white truncate">{a.name}</h5>
                                                <div className="flex items-center gap-1.5 text-[9px] text-mid-primary uppercase font-bold tracking-wider mt-0.5"><Clock className="w-3 h-3" /> {a.setTime}</div>
                                            </div>
                                            <button onClick={() => updateArray('selectedArtists', 'remove', undefined, i)} className="p-2 text-slate-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </SectionWrapper>

                        <SectionWrapper id="reviews" title="Add Review" icon={Star}>
                            <div className="space-y-8">
                                <div className="p-6 rounded-[24px] bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10">
                                    <div className="flex items-center gap-2 mb-4">
                                        <span className="w-2 h-2 bg-mid-primary rounded-full" />
                                        <h4 className="text-[10px] font-bold uppercase tracking-widest">Manual Entry</h4>
                                    </div>
                                    <div className="grid grid-cols-[auto_1fr] gap-4 mb-4">
                                        <label className="w-12 h-12 rounded-xl bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 flex items-center justify-center cursor-pointer hover:border-mid-primary transition-all text-slate-400">
                                            <Camera className="w-5 h-5" />
                                            <input type="file" className="hidden" accept="image/*" id="manual-review-img" />
                                        </label>
                                        <input className="w-full bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl px-4 text-xs font-bold" placeholder="Reviewer Name" id="manual-review-name" />
                                    </div>
                                    <textarea className="w-full bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl p-4 text-xs mb-4 resize-none" placeholder="Review text..." id="manual-review-text" />
                                    <button 
                                        onClick={() => {
                                            const nameEl = document.getElementById('manual-review-name') as HTMLInputElement;
                                            const textEl = document.getElementById('manual-review-text') as HTMLInputElement;
                                            if(nameEl.value && textEl.value) {
                                                updateArray('testimonials', 'add', { id: Date.now(), type: 'manual', name: nameEl.value, quote: textEl.value });
                                                nameEl.value = ''; textEl.value = '';
                                            }
                                        }}
                                        className="w-full py-2.5 bg-slate-900 dark:bg-white text-white dark:text-black rounded-xl text-[9px] font-black uppercase tracking-widest"
                                    >
                                        Add Text Review
                                    </button>
                                </div>

                                <div className="flex items-center justify-center text-xs font-bold text-slate-300 uppercase tracking-widest">- OR -</div>

                                <div className="p-6 rounded-[24px] bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10">
                                     <div className="flex items-center gap-2 mb-4">
                                        <span className="w-2 h-2 bg-mid-accent rounded-full" />
                                        <h4 className="text-[10px] font-bold uppercase tracking-widest">Upload Screenshot</h4>
                                    </div>
                                    <label className="border-2 border-dashed border-slate-300 dark:border-white/10 rounded-xl p-8 flex flex-col items-center justify-center gap-3 cursor-pointer hover:border-mid-accent hover:bg-mid-accent/5 transition-all">
                                        <Upload className="w-6 h-6 text-slate-400" />
                                        <span className="text-[9px] font-bold uppercase text-slate-500">Drop Proof Image</span>
                                        <input type="file" className="hidden" accept="image/*" onChange={e => handleFileUpload(e, (url) => updateArray('testimonials', 'add', { id: Date.now(), type: 'screenshot', name: 'Proof', screenshot: url }))} />
                                    </label>
                                </div>

                                <div className="space-y-2">
                                    {formData.testimonials.map((t, i) => (
                                        <div key={i} className="flex items-center justify-between p-3 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl">
                                            <div className="flex items-center gap-3">
                                                {t.type === 'manual' ? <MessageCircle className="w-4 h-4 text-mid-primary" /> : <ImageIcon className="w-4 h-4 text-mid-accent" />}
                                                <span className="text-xs font-bold">{t.name}</span>
                                            </div>
                                            <button onClick={() => updateArray('testimonials', 'remove', undefined, i)}><Trash2 className="w-4 h-4 text-slate-400 hover:text-red-500" /></button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </SectionWrapper>

                        <SectionWrapper id="creator" title="Identity Registry" icon={User}>
                            <div className="space-y-6">
                                <div className="p-6 bg-gradient-to-r from-mid-primary/10 to-mid-accent/5 border border-mid-primary/20 rounded-[24px] flex items-center gap-5">
                                    <div className="w-16 h-16 rounded-full p-1 bg-gradient-to-br from-mid-primary to-mid-accent">
                                        <div className="w-full h-full rounded-full bg-black overflow-hidden">
                                            <div className="w-full h-full bg-slate-800 flex items-center justify-center text-white font-bold">{user?.name ? user.name.charAt(0) : 'U'}</div>
                                        </div>
                                    </div>
                                    <div>
                                        <h4 className="text-lg font-tiempos font-medium text-slate-900 dark:text-white">{user?.name || 'Pro Organizer'}</h4>
                                        <div className="flex items-center gap-2 mt-1">
                                            <CheckCircle2 className="w-3.5 h-3.5 text-mid-primary" />
                                            <span className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Verified Identity</span>
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-4">
                                    <ToggleSwitch label="Display Identity on Event Page" checked={formData.displayIdentity} onChange={val => setFormData({...formData, displayIdentity: val})} />
                                    <ToggleSwitch label="Enable Direct Messaging" checked={formData.displayMessaging} onChange={val => setFormData({...formData, displayMessaging: val})} />
                                </div>
                            </div>
                        </SectionWrapper>

                        <SectionWrapper id="advanced" title="Governance & Policy" icon={ShieldCheck}>
                            <div className="space-y-8">
                                <InputGroup label="Refund & Cancellation Matrix *"><textarea className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-2xl p-5 text-sm h-24 resize-none focus:outline-none" value={formData.policy} onChange={e => setFormData({...formData, policy: e.target.value})} /></InputGroup>
                                <div className="p-6 bg-mid-primary/5 rounded-[24px] border border-mid-primary/10">
                                    <label className="flex items-start gap-4 cursor-pointer group">
                                        <input type="checkbox" checked={formData.termsAccepted} onChange={e => setFormData({...formData, termsAccepted: e.target.checked})} className="mt-1 w-5 h-5 accent-mid-primary shrink-0" />
                                        <span className="text-[11px] font-bold text-slate-600 dark:text-mid-text-subtle uppercase leading-relaxed">I accept the Terms & Conditions and Policy.</span>
                                    </label>
                                </div>
                            </div>
                        </SectionWrapper>

                        <SectionWrapper id="faq" title="Frequently Asked Questions" icon={HelpCircle}>
                            <div className="space-y-8">
                                <div className="p-6 rounded-[24px] bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10">
                                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle mb-4">Add New FAQ</h4>
                                    <div className="space-y-4">
                                        <input 
                                            className="w-full bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-xs font-bold"
                                            placeholder="Question (e.g. Is there parking?)"
                                            value={formData.newFaqQ}
                                            onChange={e => setFormData({...formData, newFaqQ: e.target.value})}
                                        />
                                        <textarea 
                                            className="w-full bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl p-4 text-xs resize-none h-24"
                                            placeholder="Answer..."
                                            value={formData.newFaqA}
                                            onChange={e => setFormData({...formData, newFaqA: e.target.value})}
                                        />
                                        <button 
                                            onClick={handleAddFaq}
                                            disabled={!formData.newFaqQ || !formData.newFaqA}
                                            className="w-full py-3 bg-slate-900 dark:bg-white text-white dark:text-black rounded-xl text-[10px] font-black uppercase tracking-widest disabled:opacity-50"
                                        >
                                            Add to List
                                        </button>
                                    </div>
                                </div>

                                <div className="space-y-3">
                                    {formData.faqs.map((f, i) => (
                                        <div key={f.id} className="p-4 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-2xl relative group">
                                            <h5 className="text-xs font-bold text-slate-900 dark:text-white pr-8">{f.q}</h5>
                                            <p className="text-[10px] text-slate-500 dark:text-mid-text-subtle mt-1">{f.a}</p>
                                            <button onClick={() => updateArray('faqs', 'remove', undefined, i)} className="absolute top-4 right-4 text-slate-400 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
                                        </div>
                                    ))}
                                    {formData.faqs.length === 0 && <p className="text-center text-xs text-slate-400 italic">No FAQs added.</p>}
                                </div>
                            </div>
                        </SectionWrapper>

                        <PoweredByBadge />
                    </div>
                </div>
                
                {/* Sticky Bottom Bar for Publishing */}
                <div className="absolute bottom-0 left-0 right-0 p-4 bg-white/95 dark:bg-[#151515]/95 backdrop-blur-xl border-t border-slate-200 dark:border-white/10 z-50 flex items-center justify-between shadow-[0_-5px_20px_rgba(0,0,0,0.1)]">
                    <div className="hidden sm:flex flex-col">
                        <span className="text-[10px] font-bold text-slate-400 dark:text-mid-text-subtle uppercase tracking-widest">Status</span>
                        <span className="text-xs font-bold text-slate-900 dark:text-white">Draft - Unsaved</span>
                    </div>
                    <div className="flex items-center gap-3 w-full sm:w-auto">
                        <button className="flex-1 sm:flex-none px-6 py-3 rounded-xl border border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/5 text-[10px] font-bold uppercase tracking-widest transition-all">Save Draft</button>
                        <button 
                            onClick={handlePublish}
                            className="flex-1 sm:flex-none px-8 py-3 bg-mid-primary hover:bg-mid-primary/90 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-glow-blue transition-all"
                        >
                            Publish Event
                        </button>
                    </div>
                </div>
            </aside>

            {/* Desktop Preview */}
            <section className="hidden lg:flex flex-1 flex-col h-full bg-[#EDF0F3] dark:bg-[#080808] relative overflow-hidden">
                <div className="flex-none h-16 border-b border-slate-200 dark:border-white/5 flex items-center justify-between px-8 bg-white/50 dark:bg-black/20 backdrop-blur-3xl z-20">
                    <div className="flex items-center gap-3">
                        <Activity className="w-4 h-4 text-mid-primary animate-pulse" />
                        <span className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500">Live Microsite Stage</span>
                    </div>
                    <div className="flex items-center bg-white/80 dark:bg-black/40 border border-slate-200 dark:border-white/10 rounded-full p-1 shadow-inner">
                        <button className="p-2 rounded-full bg-mid-primary text-white shadow-glow-blue"><Monitor className="w-4 h-4" /></button>
                        <button className="p-2 rounded-full text-slate-400 hover:text-slate-600"><Smartphone className="w-4 h-4" /></button>
                    </div>
                </div>
                <div className="flex-1 overflow-hidden relative">
                    <MicrositePreview data={formData} />
                </div>
            </section>
            
            {/* Mobile Preview Overlay */}
            {showMobilePreview && (
                <div className="fixed inset-0 z-[200] bg-[#0a0a0a] flex flex-col animate-in slide-in-from-bottom-full duration-500">
                    <div className="flex-none p-4 flex justify-between items-center bg-black/50 backdrop-blur-xl border-b border-white/10">
                        <span className="text-[10px] font-black uppercase tracking-widest text-white">Mobile Preview</span>
                        <button onClick={() => setShowMobilePreview(false)} className="p-2 bg-white/10 rounded-full text-white"><X className="w-5 h-5" /></button>
                    </div>
                    <div className="flex-1 overflow-y-auto">
                        <MicrositePreview data={formData} />
                    </div>
                </div>
            )}

            {/* Publish Success Modal */}
            <Modal
                isOpen={showPublishModal}
                onClose={() => setShowPublishModal(false)}
                title=""
            >
                <div className="p-8 flex flex-col items-center text-center space-y-6">
                    <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center border border-green-500/20 shadow-glow-secondary mb-2 animate-in zoom-in duration-500">
                        <CheckCircle className="w-10 h-10 text-green-500" />
                    </div>
                    <div className="space-y-2">
                        <h2 className="text-2xl font-tiempos font-bold text-slate-900 dark:text-white">Event Published!</h2>
                        <p className="text-sm text-slate-500 dark:text-mid-text-subtle max-w-sm mx-auto">
                            Your event microsite is now live. Share this unique link with your audience to sell tickets directly.
                        </p>
                    </div>
                    
                    <div className="w-full bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-2xl p-3 pl-4 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0 overflow-hidden">
                            <Globe className="w-4 h-4 text-mid-primary shrink-0" />
                            <span className="text-xs font-mono text-slate-600 dark:text-slate-300 truncate">{shareLink || "midmike.com/e/preview"}</span>
                        </div>
                        <button 
                            onClick={copyToClipboard}
                            className="flex items-center gap-2 px-4 py-2.5 bg-white dark:bg-white/10 rounded-xl hover:bg-slate-50 dark:hover:bg-white/20 transition-all text-slate-900 dark:text-white shadow-sm shrink-0 group"
                        >
                            <Copy className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" />
                            <span className="text-[10px] font-bold uppercase tracking-wider">Copy</span>
                        </button>
                    </div>

                    <div className="flex items-center gap-2 pt-4 w-full">
                        <button 
                            onClick={() => {
                                window.open(shareLink, '_blank');
                                setShowPublishModal(false);
                            }}
                            className="flex-1 py-3 bg-slate-900 dark:bg-white text-white dark:text-black rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg flex items-center justify-center gap-2 hover:scale-105 transition-all"
                        >
                            View Live <ExternalLink className="w-3.5 h-3.5" />
                        </button>
                        <button 
                            onClick={() => { setShowPublishModal(false); onNavigate('home'); }}
                            className="flex-1 py-3 border border-slate-200 dark:border-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-50 dark:hover:bg-white/5 transition-all"
                        >
                            Back to Home
                        </button>
                    </div>
                </div>
            </Modal>
        </div>
    );
};

const InputGroup = ({ label, children }: { label: string, children?: React.ReactNode }) => (
    <div>
        <InputLabel required={label.includes('*')}>{label.replace('*', '')}</InputLabel>
        {children}
    </div>
);
