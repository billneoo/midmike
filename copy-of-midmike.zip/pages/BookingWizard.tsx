
import React, { useState, useEffect } from 'react';
import { 
  Calendar, Clock, MapPin, Users, Music, Mic2, 
  Zap, Video, Camera, Layout, Utensils, Shield, 
  Truck, FileText, CheckCircle, ArrowRight, ArrowLeft, 
  ChevronDown, Save, AlertCircle, ShoppingBag, Plus 
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useBasket } from '../contexts/BasketContext';
import { api } from '../services/api';
import { TalentBrowserModal } from '../components/TalentBrowserModal';
import { PremiumSelect, PremiumDateSelect, PremiumTimeSelect } from '../components/PremiumInputs';

const STEPS = [
  'General Details',
  'Venue & Logistics',
  'Artistic Vision',
  'Tech Requirements',
  'Contact Info',
  'Confirmation'
];

const EVENT_TYPES = ['Concert', 'Festival', 'Wedding', 'Private Party', 'Bar / Lounge Night', 'Corporate Event', 'Other'];
const ATTENDEE_RANGES = ['< 50', '50–150', '150–500', '500+'];
const VENUE_TYPES = ['Hotel / Resort', 'Bar', 'Lounge / Rooftop', 'Club / Nightclub', 'Concert Hall', 'Outdoor Space', 'Private Residence'];
const PERFORMANCE_DURATIONS = ['30 min', '45 min', '1 h', '2 h', 'Full Event'];
const MUSIC_THEMES = ['Chill / Lounge', 'Dancefloor / Party', 'Jazz / Soul', 'Acoustic', 'Reggae / World', 'Specific Theme'];
const DRESS_CODES = ['Formal', 'Casual Chic', 'Themed', 'Black Tie'];
const LANGUAGES = ['French', 'English', 'Arabic', 'Spanish'];

const INITIAL_DATA = {
  // Step 1
  eventTitle: '',
  eventType: '',
  date: '',
  startTime: '',
  endTime: '',
  attendees: '',
  // Step 2
  venueTypes: [] as string[],
  venueSelection: '',
  address: '',
  isIndoor: true,
  setupDetails: '',
  // Step 3
  duration: '1 h',
  musicThemes: [] as string[],
  dressCode: 'Casual Chic',
  dressCodeDetails: '',
  venueAmbiance: '',
  languages: [] as string[],
  playlist: '',
  // Step 4
  needsSound: false, soundDetails: '',
  needsLighting: false, lightingDetails: '',
  needsVideo: false, videoDetails: '',
  needsPhoto: false, photoDetails: '',
  needsDecor: false, decorDetails: '',
  needsCatering: false, cateringDetails: '',
  needsSecurity: false, securityDetails: '',
  needsTransport: false, transportDetails: '',
  needsOther: false, otherDetails: '',
  // Step 5
  contactName: '',
  organization: '',
  email: '',
  phone: '',
  billingAddress: '',
  // Step 6
  comments: '',
  acceptedTerms: false,
  authorizedShare: false
};

export const BookingWizard: React.FC<{ onNavigate: (route: string) => void }> = ({ onNavigate }) => {
  const { user, setAuthModalOpen } = useAuth();
  const { items: basketItems, clearBasket, removeFromBasket } = useBasket();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState(INITIAL_DATA);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  
  // New State for Talent Browser
  const [isTalentModalOpen, setIsTalentModalOpen] = useState(false);
  const [showBasketNotification, setShowBasketNotification] = useState(false);

  // Auto-fill user data
  useEffect(() => {
    if (user && !formData.contactName) {
      setFormData(prev => ({
        ...prev,
        contactName: user.name,
        email: user.email,
        phone: user.phone
      }));
    }
  }, [user]);

  // Load Draft or Initialize from Basket
  useEffect(() => {
    const saved = localStorage.getItem('booking_wizard_draft');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setFormData(prev => ({ ...prev, ...parsed }));
        
        // If we have a draft, we check if we should notify about new basket items
        if (basketItems.length > 0) {
             // Logic: If draft exists but user just added items to basket, we assume they want to add them to current draft.
             // Basket items are handled via BasketContext, so no manual merge needed into formData for talent.
        }
      } catch (e) {}
    } else {
        // No draft, check basket for "Smart Hand-off"
        if (basketItems.length > 0) {
            setShowBasketNotification(true);
            // Hide notification after 5s
            setTimeout(() => setShowBasketNotification(false), 8000);
        }
    }
  }, []); // Run once on mount

  useEffect(() => {
    localStorage.setItem('booking_wizard_draft', JSON.stringify(formData));
  }, [formData]);

  const updateField = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleArrayItem = (field: keyof typeof formData, item: string) => {
    setFormData(prev => {
      const arr = prev[field] as string[];
      return {
        ...prev,
        [field]: arr.includes(item) ? arr.filter(i => i !== item) : [...arr, item]
      };
    });
  };

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

  const handleNext = () => {
    if (step < 6) {
      setStep(s => s + 1);
      scrollToTop();
    } else {
      handleSubmit();
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(s => s - 1);
      scrollToTop();
    } else {
      onNavigate('home');
    }
  };

  const handleSubmit = async () => {
    if (!user) {
        setAuthModalOpen(true);
        return;
    }
    if (!formData.acceptedTerms) return alert("Please accept terms.");
    
    setIsSubmitting(true);
    // Simulate API call
    await new Promise(r => setTimeout(r, 2000));
    
    setIsSubmitting(false);
    setSuccess(true);
    localStorage.removeItem('booking_wizard_draft');
    clearBasket();
  };

  const TechToggle = ({ icon: Icon, label, field, detailsField }: any) => (
    <div className={`p-4 rounded-xl border transition-all ${formData[field as keyof typeof formData] ? 'bg-mid-primary/5 border-mid-primary shadow-sm' : 'bg-white dark:bg-white/5 border-slate-200 dark:border-white/10'}`}>
        <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${formData[field as keyof typeof formData] ? 'bg-mid-primary text-white' : 'bg-slate-100 dark:bg-white/10 text-slate-500'}`}>
                    <Icon className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-slate-900 dark:text-white">{label}</span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" checked={formData[field as keyof typeof formData] as boolean} onChange={e => updateField(field, e.target.checked)} className="sr-only peer" />
                <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none dark:bg-slate-700 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-mid-primary"></div>
            </label>
        </div>
        {formData[field as keyof typeof formData] && (
            <textarea 
                value={formData[detailsField as keyof typeof formData] as string}
                onChange={e => updateField(detailsField, e.target.value)}
                placeholder={`Describe your ${label.toLowerCase()} needs...`}
                className="w-full bg-white dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-lg p-3 text-xs focus:outline-none focus:border-mid-primary/50 h-20 resize-none animate-in fade-in slide-in-from-top-2"
            />
        )}
    </div>
  );

  if (success) {
      return (
          <div className="min-h-screen flex items-center justify-center p-4 bg-[#F2F4F7] dark:bg-[#0D0D0D]">
              <div className="w-full max-w-lg bg-white dark:bg-[#151515] rounded-[32px] p-8 md:p-12 text-center shadow-2xl border border-slate-200 dark:border-white/5 animate-in zoom-in duration-500">
                  <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-green-500/20 shadow-glow-secondary">
                      <CheckCircle className="w-10 h-10 text-green-500" />
                  </div>
                  <h2 className="text-3xl font-tiempos font-bold text-slate-900 dark:text-white mb-4">Request Sent!</h2>
                  <p className="text-slate-500 dark:text-mid-text-muted mb-8 leading-relaxed">
                      Your booking request (ID: #EV-{Math.floor(Math.random() * 10000)}) has been dispatched to the selected talent and our operations team. You will receive a confirmation email shortly.
                  </p>
                  <button onClick={() => onNavigate('home')} className="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-black rounded-full font-bold uppercase tracking-widest text-xs hover:scale-105 transition-transform shadow-lg">
                      Return Home
                  </button>
              </div>
          </div>
      );
  }

  return (
    <div className="min-h-screen bg-[#F2F4F7] dark:bg-[#0D0D0D] pb-32 pt-20 relative">
        {/* Smart Handoff Notification */}
        {showBasketNotification && (
            <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 w-[90%] max-w-md animate-in slide-in-from-top-4 duration-500">
                <div className="bg-mid-primary text-white px-6 py-4 rounded-2xl shadow-xl flex items-center justify-between border border-white/10">
                    <div className="flex items-center gap-3">
                        <ShoppingBag className="w-5 h-5" />
                        <div>
                            <p className="text-xs font-bold uppercase tracking-wide">Starting Booking</p>
                            <p className="text-[10px] opacity-80">Including {basketItems.length} selected professionals.</p>
                        </div>
                    </div>
                    <button onClick={() => setShowBasketNotification(false)} className="p-1 hover:bg-white/20 rounded-full"><div className="w-4 h-4">×</div></button>
                </div>
            </div>
        )}

        <div className="max-w-3xl mx-auto px-4 md:px-8">
            
            {/* Header */}
            <div className="mb-8">
                <button onClick={handleBack} className="flex items-center gap-2 text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors mb-6 text-xs font-bold uppercase tracking-widest">
                    <ArrowLeft className="w-4 h-4" /> Back
                </button>
                <div className="flex items-end justify-between">
                    <div>
                        <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-mid-primary mb-2 block">Booking Wizard</span>
                        <h1 className="text-3xl md:text-4xl font-tiempos font-normal text-slate-900 dark:text-white">{STEPS[step - 1]}</h1>
                    </div>
                    <div className="text-right hidden sm:block">
                        <span className="text-4xl font-tiempos text-slate-200 dark:text-white/10 font-bold">0{step}</span>
                        <span className="text-lg text-slate-200 dark:text-white/10 font-light">/06</span>
                    </div>
                </div>
                
                {/* Progress Bar */}
                <div className="mt-6 h-1 w-full bg-slate-200 dark:bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-mid-primary transition-all duration-500 ease-out" style={{ width: `${(step / 6) * 100}%` }} />
                </div>
            </div>

            {/* Form Container */}
            <div className="bg-white dark:bg-[#151515] rounded-[24px] border border-slate-200 dark:border-white/5 p-6 md:p-10 shadow-xl relative overflow-hidden min-h-[500px] flex flex-col">
                
                {/* Step 1: General Details */}
                {step === 1 && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-right-8 duration-500">
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Event Title *</label>
                            <input value={formData.eventTitle} onChange={e => updateField('eventTitle', e.target.value)} className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm focus:border-mid-primary/50 focus:outline-none" placeholder="e.g. Summer Sunset Festival" />
                        </div>
                        
                        <div className="space-y-2">
                            <PremiumSelect 
                                label="Event Type *"
                                options={EVENT_TYPES}
                                value={formData.eventType}
                                onChange={val => updateField('eventType', val)}
                                placeholder="Select type..."
                            />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                                <PremiumDateSelect 
                                    label="Date *"
                                    value={formData.date}
                                    onChange={val => updateField('date', val)}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle mb-2 block">Timing *</label>
                                <div className="flex gap-2">
                                    <div className="flex-1">
                                        <PremiumTimeSelect 
                                            value={formData.startTime}
                                            onChange={val => updateField('startTime', val)}
                                        />
                                    </div>
                                    <div className="flex items-center text-slate-400">-</div>
                                    <div className="flex-1">
                                        <PremiumTimeSelect 
                                            value={formData.endTime}
                                            onChange={val => updateField('endTime', val)}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-2">
                            <PremiumSelect 
                                label="Guest Count *"
                                options={ATTENDEE_RANGES}
                                value={formData.attendees}
                                onChange={val => updateField('attendees', val)}
                                placeholder="Approximate number of guests"
                                icon={Users}
                            />
                        </div>
                    </div>
                )}

                {/* Step 2: Venue */}
                {step === 2 && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-right-8 duration-500">
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Venue Type</label>
                            <div className="flex flex-wrap gap-2">
                                {VENUE_TYPES.map(t => (
                                    <button key={t} onClick={() => toggleArrayItem('venueTypes', t)} className={`px-4 py-2 rounded-full border text-xs font-bold transition-all ${formData.venueTypes.includes(t) ? 'bg-mid-secondary text-white border-mid-secondary' : 'bg-transparent border-slate-200 dark:border-white/10 text-slate-500 hover:bg-slate-50 dark:hover:bg-white/5'}`}>
                                        {t}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Venue Selection / Custom Address *</label>
                            <div className="relative">
                                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                                <input value={formData.venueSelection} onChange={e => updateField('venueSelection', e.target.value)} className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl pl-12 pr-4 py-3 text-sm focus:border-mid-secondary/50 focus:outline-none" placeholder="Search venue or enter address..." />
                            </div>
                        </div>

                        <div className="flex gap-4">
                            <button onClick={() => updateField('isIndoor', true)} className={`flex-1 py-4 rounded-xl border-2 flex flex-col items-center gap-2 transition-all ${formData.isIndoor ? 'border-mid-secondary bg-mid-secondary/5 text-mid-secondary' : 'border-slate-200 dark:border-white/10 text-slate-400'}`}>
                                <Layout className="w-5 h-5" /> <span className="text-xs font-bold uppercase">Indoor</span>
                            </button>
                            <button onClick={() => updateField('isIndoor', false)} className={`flex-1 py-4 rounded-xl border-2 flex flex-col items-center gap-2 transition-all ${!formData.isIndoor ? 'border-mid-secondary bg-mid-secondary/5 text-mid-secondary' : 'border-slate-200 dark:border-white/10 text-slate-400'}`}>
                                <Zap className="w-5 h-5" /> <span className="text-xs font-bold uppercase">Outdoor</span>
                            </button>
                        </div>

                        <div className="space-y-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Setup Details / Floor Plan</label>
                            <textarea value={formData.setupDetails} onChange={e => updateField('setupDetails', e.target.value)} className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl p-4 text-sm focus:outline-none h-24 resize-none" placeholder="Describe stage position, seating, etc..." />
                        </div>
                    </div>
                )}

                {/* Step 3: Artistic */}
                {step === 3 && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-right-8 duration-500">
                        
                        {/* Integrated Talent Browser */}
                        <div className="bg-mid-surface/50 border border-slate-200 dark:border-white/10 rounded-[20px] overflow-hidden">
                            <div className="p-4 bg-slate-50 dark:bg-white/5 border-b border-slate-200 dark:border-white/10 flex justify-between items-center">
                                <h4 className="text-xs font-bold uppercase tracking-widest text-slate-600 dark:text-slate-300 flex items-center gap-2">
                                    <ShoppingBag className="w-4 h-4" /> Lineup Builder
                                </h4>
                                <button 
                                    onClick={() => setIsTalentModalOpen(true)}
                                    className="px-4 py-2 bg-mid-primary hover:bg-mid-primary/90 text-white rounded-lg text-[10px] font-bold uppercase tracking-widest shadow-sm flex items-center gap-2 transition-all"
                                >
                                    <Plus className="w-3 h-3" /> Browse Talent
                                </button>
                            </div>
                            
                            <div className="p-4">
                                {basketItems.length > 0 ? (
                                    <div className="space-y-3">
                                        {basketItems.map(item => (
                                            <div key={item.id} className="flex items-center gap-4 bg-white dark:bg-black/20 p-3 rounded-xl border border-slate-100 dark:border-white/5 shadow-sm group">
                                                <div className="w-10 h-10 rounded-lg bg-slate-200 dark:bg-white/10 overflow-hidden shrink-0"><img src={item.imageUrl} className="w-full h-full object-cover" /></div>
                                                <div className="flex-1 min-w-0">
                                                    <span className="block text-sm font-bold text-slate-900 dark:text-white truncate">{item.title}</span>
                                                    <span className="block text-[10px] text-slate-500">{item.category}</span>
                                                </div>
                                                <button onClick={() => removeFromBasket(item.id)} className="p-2 text-slate-400 hover:text-red-500 transition-colors">
                                                    <div className="sr-only">Remove</div>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="py-8 text-center border-2 border-dashed border-slate-200 dark:border-white/10 rounded-xl">
                                        <p className="text-xs text-slate-400">No artists selected.</p>
                                        <button onClick={() => setIsTalentModalOpen(true)} className="text-[10px] font-bold text-mid-primary uppercase tracking-widest mt-2 hover:underline">Open Catalog</button>
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                                <PremiumSelect 
                                    label="Perf. Duration"
                                    options={PERFORMANCE_DURATIONS}
                                    value={formData.duration}
                                    onChange={val => updateField('duration', val)}
                                    icon={Clock}
                                />
                            </div>
                            <div className="space-y-2">
                                <PremiumSelect 
                                    label="Dress Code"
                                    options={DRESS_CODES}
                                    value={formData.dressCode}
                                    onChange={val => updateField('dressCode', val)}
                                    icon={Users}
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Music Themes</label>
                            <div className="flex flex-wrap gap-2">
                                {MUSIC_THEMES.map(t => (
                                    <button key={t} onClick={() => toggleArrayItem('musicThemes', t)} className={`px-3 py-1.5 rounded-full border text-[10px] font-bold uppercase transition-all ${formData.musicThemes.includes(t) ? 'bg-mid-primary text-white border-mid-primary' : 'bg-transparent border-slate-200 dark:border-white/10 text-slate-500'}`}>
                                        {t}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Mandatory Playlist / Songs</label>
                            <textarea value={formData.playlist} onChange={e => updateField('playlist', e.target.value)} className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl p-4 text-sm focus:outline-none h-20 resize-none" placeholder="Paste Spotify link or list songs..." />
                        </div>
                    </div>
                )}

                {/* Step 4: Tech */}
                {step === 4 && (
                    <div className="space-y-4 animate-in fade-in slide-in-from-right-8 duration-500 h-full overflow-y-auto custom-scrollbar pr-2">
                        <TechToggle icon={Music} label="Sound Equipment" field="needsSound" detailsField="soundDetails" />
                        <TechToggle icon={Zap} label="Lighting" field="needsLighting" detailsField="lightingDetails" />
                        <TechToggle icon={Video} label="Video / Streaming" field="needsVideo" detailsField="videoDetails" />
                        <TechToggle icon={Camera} label="Photography" field="needsPhoto" detailsField="photoDetails" />
                        <TechToggle icon={Layout} label="Furniture / Decor" field="needsDecor" detailsField="decorDetails" />
                        <TechToggle icon={Utensils} label="Catering" field="needsCatering" detailsField="cateringDetails" />
                        <TechToggle icon={Shield} label="Security" field="needsSecurity" detailsField="securityDetails" />
                        <TechToggle icon={Truck} label="Transport" field="needsTransport" detailsField="transportDetails" />
                        <TechToggle icon={FileText} label="Other Services" field="needsOther" detailsField="otherDetails" />
                    </div>
                )}

                {/* Step 5: Contact */}
                {step === 5 && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-right-8 duration-500">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Full Name *</label>
                                <input value={formData.contactName} onChange={e => updateField('contactName', e.target.value)} className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none" />
                            </div>
                            <div className="space-y-2">
                                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Organization</label>
                                <input value={formData.organization} onChange={e => updateField('organization', e.target.value)} className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none" />
                            </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Email *</label>
                                <input type="email" value={formData.email} onChange={e => updateField('email', e.target.value)} className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none" />
                            </div>
                            <div className="space-y-2">
                                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Phone *</label>
                                <input type="tel" value={formData.phone} onChange={e => updateField('phone', e.target.value)} className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none" />
                            </div>
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Billing Address *</label>
                            <textarea value={formData.billingAddress} onChange={e => updateField('billingAddress', e.target.value)} className="w-full bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl p-4 text-sm focus:outline-none h-24 resize-none" />
                        </div>
                    </div>
                )}

                {/* Step 6: Confirmation */}
                {step === 6 && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-right-8 duration-500 h-full overflow-y-auto custom-scrollbar">
                        <div className="bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl p-6 space-y-4">
                            <h3 className="font-tiempos text-xl text-slate-900 dark:text-white">Booking Summary</h3>
                            <div className="grid grid-cols-2 gap-y-2 text-sm">
                                <span className="text-slate-500">Event:</span> <span className="font-bold">{formData.eventTitle} ({formData.eventType})</span>
                                <span className="text-slate-500">Date:</span> <span className="font-bold">{formData.date}</span>
                                <span className="text-slate-500">Venue:</span> <span className="font-bold">{formData.venueSelection || 'TBD'}</span>
                                <span className="text-slate-500">Talent:</span> <span className="font-bold">{basketItems.length} Selected</span>
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Additional Comments</label>
                            <textarea value={formData.comments} onChange={e => updateField('comments', e.target.value)} className="w-full bg-white dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-xl p-4 text-sm focus:outline-none h-24 resize-none" />
                        </div>

                        <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-white/5">
                            <label className="flex items-center gap-3 cursor-pointer">
                                <input type="checkbox" checked={formData.acceptedTerms} onChange={e => updateField('acceptedTerms', e.target.checked)} className="w-4 h-4 accent-mid-primary" />
                                <span className="text-xs text-slate-600 dark:text-slate-300">I accept the Terms & Conditions and cancellation policy *</span>
                            </label>
                            <label className="flex items-center gap-3 cursor-pointer">
                                <input type="checkbox" checked={formData.authorizedShare} onChange={e => updateField('authorizedShare', e.target.checked)} className="w-4 h-4 accent-mid-primary" />
                                <span className="text-xs text-slate-600 dark:text-slate-300">I authorize MidMike to share my details with providers *</span>
                            </label>
                        </div>
                    </div>
                )}

                {/* Footer Controls */}
                <div className="mt-auto pt-6 flex items-center justify-between border-t border-slate-100 dark:border-white/5">
                    <button onClick={handleBack} className="px-6 py-3 rounded-full border border-slate-200 dark:border-white/10 text-xs font-bold uppercase tracking-widest hover:bg-slate-50 dark:hover:bg-white/5 transition-all">
                        {step === 1 ? 'Cancel' : 'Back'}
                    </button>
                    <div className="flex gap-3">
                        <button onClick={() => {}} className="hidden md:flex items-center gap-2 px-4 py-3 text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-mid-primary transition-colors">
                            <Save className="w-4 h-4" /> Save Draft
                        </button>
                        <button 
                            onClick={handleNext}
                            disabled={isSubmitting}
                            className="px-8 py-3 bg-mid-primary hover:bg-mid-primary/90 text-white rounded-full text-xs font-bold uppercase tracking-[0.2em] shadow-glow-blue transition-all flex items-center gap-2 disabled:opacity-50"
                        >
                            {isSubmitting ? 'Processing...' : step === 6 ? 'Confirm Booking' : 'Next Step'}
                            {!isSubmitting && <ArrowRight className="w-4 h-4" />}
                        </button>
                    </div>
                </div>
            </div>
        </div>

        {/* Integrated Talent Browser Modal */}
        <TalentBrowserModal 
            isOpen={isTalentModalOpen}
            onClose={() => setIsTalentModalOpen(false)}
        />
    </div>
  );
};
