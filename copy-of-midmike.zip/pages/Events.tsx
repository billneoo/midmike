
import React, { useEffect, useState, useMemo } from 'react';
import { api } from '../services/api';
import { EventEntity } from '../types';
import { Card } from '../components/Card';
import { 
  Search, LayoutList, LayoutGrid, 
  CalendarDays, Clock, SlidersHorizontal 
} from 'lucide-react';
import { FilterPanel, FilterState } from '../components/FilterPanel';

type ViewMode = 'timeline' | 'grid';

export const Events: React.FC<{ onNavigate: (route: string, params?: any) => void }> = ({ onNavigate }) => {
  const [events, setEvents] = useState<EventEntity[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [viewMode, setViewMode] = useState<ViewMode>('timeline');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Advanced Filters
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [filters, setFilters] = useState<FilterState>({
    categories: [],
    tags: [],
    rating: null,
    verifiedOnly: false,
    location: null,
    venueTypes: [],
    equipment: [],
    contentFormats: [],
    capacity: undefined
  });

  useEffect(() => {
    const loadEvents = async () => {
      try {
        const data = await api.getAllEvents();
        setEvents(data);
      } catch (error) {
        console.error("Failed to load events", error);
      } finally {
        setIsLoading(false);
      }
    };
    loadEvents();
  }, []);

  const filteredEvents = events.filter(evt => {
    // 1. Search Query
    const matchesSearch = evt.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          evt.location?.toLowerCase().includes(searchQuery.toLowerCase());
    if (!matchesSearch) return false;

    // 2. Event Types (Categories)
    if (filters.categories.length > 0) {
        // Assume 'category' property holds the event type
        const matchesType = filters.categories.some(c => evt.category.includes(c));
        if (!matchesType) return false;
    }

    // 3. Ambiance (Tags)
    if (filters.tags.length > 0) {
        const matchesMood = filters.tags.some(t => evt.tags?.some(tag => tag.includes(t)));
        if (!matchesMood) return false;
    }

    // 4. Location
    if (filters.location && !evt.location?.includes(filters.location)) return false;

    // 5. Rating
    if (filters.rating && (evt.rating || 0) < filters.rating) return false;

    // 6. Verified
    if (filters.verifiedOnly && !evt.verified) return false;

    // Simple tag-based fallback check for demo purposes:
    if (filters.venueTypes && filters.venueTypes.length > 0) {
         const matchesVenue = filters.venueTypes.some(vt => evt.tags?.some(tag => tag.includes(vt)) || evt.location?.includes(vt));
    }

    return true;
  });

  const activeFilterCount = 
    filters.categories.length + 
    filters.tags.length + 
    (filters.rating ? 1 : 0) + 
    (filters.verifiedOnly ? 1 : 0) +
    (filters.location ? 1 : 0) +
    (filters.venueTypes?.length || 0) +
    (filters.equipment?.length || 0) +
    (filters.contentFormats?.length || 0) +
    (filters.capacity ? 1 : 0);

  return (
    <div className="min-h-screen pb-24 animate-cinematic-fade">
      
      {/* Header & Controls */}
      <div className="sticky top-20 z-40 bg-gray-50/70 dark:bg-[#191919]/60 backdrop-blur-xl border-b border-slate-200 dark:border-white/5 pb-4 mb-8 -mx-4 px-4 md:-mx-6 md:px-6 pt-4 transition-all duration-300">
        <div className="max-w-[1800px] mx-auto flex flex-col gap-6">
            
            {/* Title & Stats */}
            <div className="flex items-end justify-between">
                <div>
                    <h1 className="text-3xl md:text-4xl font-inter font-normal text-slate-900 dark:text-white mb-1">Explore Events</h1>
                    <p className="text-xs text-slate-500 dark:text-mid-text-muted font-inter uppercase tracking-[0.2em]">
                        {filteredEvents.length} Upcoming Experiences
                    </p>
                </div>
            </div>

            {/* Filter Bar */}
            <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
                
                {/* Search & Filters */}
                <div className="flex flex-1 flex-col md:flex-row gap-4 w-full md:w-auto items-start md:items-center">
                     
                     {/* Row for Search + Filter Button */}
                     <div className="flex items-center gap-2 w-full md:w-auto">
                         <div className="relative group flex-1 md:w-64">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-subtle group-focus-within:text-mid-primary transition-colors" />
                            <input 
                                type="text" 
                                placeholder="Search events..." 
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="w-full bg-slate-200/50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-full py-2.5 pl-10 pr-4 text-xs font-medium text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-mid-text-subtle focus:outline-none focus:border-mid-primary/50 transition-all shadow-inner"
                            />
                         </div>

                        {/* Filter Trigger Button - Unified Style */}
                        <button 
                            onClick={() => setIsFilterOpen(true)}
                            className={`
                                flex items-center gap-2 rounded-full border transition-all duration-300 shrink-0
                                px-4 py-2.5 md:px-6 md:py-3 
                                ${activeFilterCount > 0 
                                    ? 'bg-mid-primary text-white border-mid-primary shadow-glow-blue' 
                                    : 'bg-white dark:bg-white/5 border-slate-200 dark:border-white/10 text-slate-600 dark:text-mid-text-subtle hover:bg-slate-50 dark:hover:bg-white/10'}
                            `}
                        >
                            <SlidersHorizontal className="w-3.5 h-3.5 md:w-4 md:h-4" />
                            <span className="text-[9px] md:text-[10px] font-bold uppercase tracking-widest">Filter</span>
                            {activeFilterCount > 0 && (
                                <span className="ml-1 w-4 h-4 md:w-5 md:h-5 flex items-center justify-center bg-white text-mid-primary rounded-full text-[8px] md:text-[9px] font-bold">{activeFilterCount}</span>
                            )}
                        </button>
                     </div>
                    
                    {/* Active Filters Summary (Desktop) */}
                    {activeFilterCount > 0 && (
                        <div className="hidden md:flex flex-wrap gap-2 items-center">
                            <div className="h-4 w-[1px] bg-slate-300 dark:bg-white/10 mx-2"></div>
                            {filters.categories.slice(0, 2).map(c => <span key={c} className="px-3 py-1 rounded-full bg-mid-primary/10 text-mid-primary text-[10px] font-bold uppercase border border-mid-primary/20">{c}</span>)}
                            {filters.categories.length > 2 && <span className="text-[10px] text-slate-500">+{filters.categories.length - 2} more</span>}
                            <button onClick={() => setFilters({categories: [], tags: [], rating: null, verifiedOnly: false, location: null, venueTypes: [], equipment: [], contentFormats: [], capacity: undefined})} className="text-[10px] text-slate-400 hover:text-white underline decoration-dashed underline-offset-4 ml-2">Clear</button>
                        </div>
                    )}
                </div>

                {/* View Toggle */}
                <div className="flex bg-slate-200/50 dark:bg-white/5 rounded-full p-1 border border-slate-200 dark:border-white/10 shrink-0 self-end md:self-auto">
                    <button 
                        onClick={() => setViewMode('timeline')}
                        className={`p-2 rounded-full transition-all flex items-center gap-2 px-3 ${viewMode === 'timeline' ? 'bg-white dark:bg-mid-panel shadow-sm text-mid-primary' : 'text-slate-400 dark:text-mid-text-subtle hover:text-slate-600 dark:hover:text-white'}`}
                    >
                        <LayoutList className="w-4 h-4" />
                        {viewMode === 'timeline' && <span className="text-[10px] font-bold uppercase tracking-widest animate-in fade-in zoom-in">Timeline</span>}
                    </button>
                    <button 
                        onClick={() => setViewMode('grid')}
                        className={`p-2 rounded-full transition-all flex items-center gap-2 px-3 ${viewMode === 'grid' ? 'bg-white dark:bg-mid-panel shadow-sm text-mid-primary' : 'text-slate-400 dark:text-mid-text-subtle hover:text-slate-600 dark:hover:text-white'}`}
                    >
                        <LayoutGrid className="w-4 h-4" />
                        {viewMode === 'grid' && <span className="text-[10px] font-bold uppercase tracking-widest animate-in fade-in zoom-in">Grid</span>}
                    </button>
                </div>
            </div>
        </div>
      </div>

      {/* Main Content Area */}
      {isLoading ? (
        <div className="flex items-center justify-center py-20">
             <div className="w-10 h-10 border-2 border-mid-primary/30 border-t-mid-primary rounded-full animate-spin"></div>
        </div>
      ) : (
          <div className="max-w-[1800px] mx-auto px-2 md:px-0">
            {filteredEvents.length === 0 ? (
                <div className="text-center py-20 opacity-60">
                    <CalendarDays className="w-12 h-12 text-slate-300 dark:text-white/20 mx-auto mb-4" />
                    <p className="text-lg font-inter text-slate-900 dark:text-white">No events found matching your criteria.</p>
                    <button onClick={() => setFilters({categories: [], tags: [], rating: null, verifiedOnly: false, location: null, venueTypes: [], equipment: [], contentFormats: [], capacity: undefined})} className="mt-4 text-xs font-bold uppercase tracking-widest text-mid-primary">Clear Filters</button>
                </div>
            ) : viewMode === 'timeline' ? (
                <TimelineSwimlanes events={filteredEvents} onNavigate={onNavigate} />
            ) : (
                <GridView events={filteredEvents} onNavigate={onNavigate} />
            )}
          </div>
      )}

      {/* Filter Panel */}
      <FilterPanel 
        isOpen={isFilterOpen}
        onClose={() => setIsFilterOpen(false)}
        type="event"
        currentFilters={filters}
        onApply={setFilters}
        resultsCount={filteredEvents.length}
      />
    </div>
  );
};

// Helper for separating Day and Time for Timeline
const getEventDayTime = (dateStr: string) => {
    if (dateStr.includes(':') && !dateStr.includes('/')) {
        return { day: 'Today', time: dateStr };
    }
    if (dateStr.includes('/')) {
        return { day: dateStr, time: '20:00' };
    }
    return { day: 'Upcoming', time: 'TBD' };
};

const TimelineSwimlanes: React.FC<{ events: EventEntity[], onNavigate: (route: string, params?: any) => void }> = ({ events, onNavigate }) => {
    const groupedEvents = useMemo(() => {
        const groups: Record<string, EventEntity[]> = {};
        events.forEach(evt => {
            const { day } = getEventDayTime(evt.date);
            if (!groups[day]) groups[day] = [];
            groups[day].push(evt);
        });
        return groups;
    }, [events]);

    const sortedDays = Object.keys(groupedEvents).sort((a, b) => {
        if (a === 'Today') return -1;
        if (b === 'Today') return 1;
        return 0;
    });

    return (
        <div className="flex flex-col gap-12 pt-4 pb-20 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {sortedDays.map((day, index) => (
                <div key={day} className="relative group/swimlane">
                    <div className="absolute left-2 md:left-0 z-20">
                         <div className={`
                            px-5 py-2 rounded-full border border-mid-primary/20 backdrop-blur-md shadow-lg
                            ${day === 'Today' 
                                ? 'bg-mid-primary text-white shadow-glow-blue' 
                                : 'bg-white dark:bg-[#191919] text-slate-900 dark:text-white border-slate-200 dark:border-white/10'}
                         `}>
                            <span className="text-[11px] font-bold uppercase tracking-[0.2em] flex items-center gap-2">
                                <CalendarDays className="w-3.5 h-3.5" />
                                {day}
                            </span>
                         </div>
                    </div>

                    <div className="relative pt-16 pb-8 overflow-x-auto no-scrollbar mask-gradient-x pl-4 md:pl-40 snap-x snap-mandatory flex items-start scroll-smooth">
                        <div className="absolute top-[32px] left-0 w-[max(100%,100vw)] h-[2px] bg-gradient-to-r from-transparent via-mid-primary/50 to-transparent z-0 pointer-events-none" />

                        <div className="flex gap-6 md:gap-8 items-start w-max pt-6 px-4 md:px-0">
                            {groupedEvents[day].map((evt, idx) => {
                                const { time } = getEventDayTime(evt.date);
                                return (
                                    <div key={evt.id} className="group relative flex flex-col items-center w-[280px] md:w-[320px] shrink-0 snap-center transition-all duration-500 hover:scale-[1.01] hover:-translate-y-1">
                                        <div className="absolute -top-[22px] left-1/2 -translate-x-1/2 w-[2px] h-[30px] bg-gradient-to-b from-mid-primary to-transparent z-0" />
                                        <div className="absolute -top-[45px] z-20">
                                            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white dark:bg-[#191919] border border-mid-primary/40 text-mid-primary shadow-sm dark:shadow-[0_0_15px_rgba(23,84,216,0.3)]">
                                                <Clock className="w-3 h-3" />
                                                <span className="text-[10px] font-bold tracking-wider">{time}</span>
                                            </div>
                                        </div>
                                        <div className="absolute -top-[28px] left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-mid-primary shadow-glow-blue z-10 ring-4 ring-slate-100 dark:ring-[#191919]" />
                                        <div className="w-full">
                                            <Card 
                                                image={evt.imageUrl}
                                                title={evt.title}
                                                subtitle={evt.location}
                                                date={evt.date}
                                                badge={evt.category}
                                                variant="portrait-action"
                                                actionLabel="DETAILS" 
                                                imageAspectRatio="square" 
                                                showBookingAction={false}
                                                onClick={() => onNavigate('event-details', { id: evt.id })}
                                            />
                                        </div>
                                    </div>
                                );
                            })}
                            <div className="w-12 shrink-0" />
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );
};

const GridView: React.FC<{ events: EventEntity[], onNavigate: (route: string, params?: any) => void }> = ({ events, onNavigate }) => {
    return (
        <div className="flex flex-wrap gap-8 justify-center animate-in fade-in slide-in-from-bottom-4 duration-700 pb-12">
            {events.map((evt) => (
                <div key={evt.id} className="w-[300px] md:w-[340px] animate-in fade-in slide-in-from-bottom-2 duration-500">
                     <Card 
                        image={evt.imageUrl}
                        title={evt.title}
                        subtitle={evt.location}
                        date={evt.date}
                        badge={evt.category}
                        variant="portrait-action"
                        actionLabel="DETAILS" 
                        imageAspectRatio="square" 
                        showBookingAction={false}
                        onClick={() => onNavigate('event-details', { id: evt.id })}
                    />
                </div>
            ))}
        </div>
    );
};
