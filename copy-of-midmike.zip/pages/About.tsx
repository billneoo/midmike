
import React, { useState } from 'react';
import { 
  Sparkles, Users, Zap, Shield, Globe, ArrowRight, 
  Mail, MapPin, Phone, Linkedin, Twitter, Instagram,
  ChevronDown, ChevronUp, HelpCircle, Target
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface AboutProps {
  onNavigate: (route: string) => void;
}

const TEAM = [
    {
        name: 'Sarah Ben Amor',
        role: 'Founder & CEO',
        bio: 'Ex-Event Producer with 10+ years managing festivals in North Africa.',
        image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=400&auto=format&fit=crop'
    },
    {
        name: 'Malek Jaziri',
        role: 'CTO & Architect',
        bio: 'Audio Engineer turned Full-stack Developer. Obsessed with acoustics.',
        image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=400&auto=format&fit=crop'
    },
    {
        name: 'Yassine K.',
        role: 'Head of Talent',
        bio: 'Former Booking Agent. Connected 500+ artists with international stages.',
        image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=400&auto=format&fit=crop'
    },
    {
        name: 'Nour El Hoda',
        role: 'Venue Partnerships',
        bio: 'Hospitality expert specializing in luxury nightlife experiences.',
        image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=400&auto=format&fit=crop'
    }
];

const FAQS = [
    {
        q: "How do I get verified as a professional?",
        a: "We require a portfolio review and ID verification. Once you sign up as an Artist or Technician, our curation team reviews your profile within 48 hours."
    },
    {
        q: "Is MidMike free to use?",
        a: "For Users and basic listings, yes. We charge a small commission on confirmed bookings and offer Premium plans for Agencies and Venues requiring advanced tools."
    },
    {
        q: "Does MidMike handle payments?",
        a: "Yes. We use a secure escrow system. Client funds are held safely and released to the professional upon successful completion of the event."
    }
];

export const About: React.FC<AboutProps> = ({ onNavigate }) => {
  const { user, setAuthModalOpen } = useAuth();
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
      setOpenFaq(openFaq === index ? null : index);
  };

  const handleCta = () => {
    if (user) {
      onNavigate('events');
    } else {
      setAuthModalOpen(true);
    }
  };

  return (
    <div className="animate-cinematic-fade max-w-6xl mx-auto pb-20">
      
      {/* 1. HERO SECTION */}
      <div className="premium-shiny-container rounded-[32px] overflow-hidden p-8 md:p-20 text-center mb-16 shadow-glass-deep relative group">
        <div className="relative z-10 flex flex-col items-center max-w-4xl mx-auto space-y-8">
          
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-mid-primary/10 dark:bg-white/10 backdrop-blur-md border border-mid-primary/20 dark:border-white/20 shadow-glow-blue animate-in slide-in-from-top-4 duration-700">
            <Sparkles className="w-4 h-4 text-mid-primary dark:text-mid-highlight animate-pulse" />
            <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-slate-900 dark:text-white">The Infrastructure of Nightlife</span>
          </div>
          
          {/* Title with Unified Gradient (Blue -> Green -> Orange) */}
          <h1 className="text-4xl md:text-7xl font-inter font-medium text-slate-900 dark:text-white tracking-tight leading-[0.95] text-glow-none dark:text-glow drop-shadow-sm dark:drop-shadow-2xl">
            Orchestrating the <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-mid-primary via-mid-secondary to-mid-accent">Creative Economy.</span>
          </h1>
          
          {/* Subtitle */}
          <p className="text-lg md:text-xl text-slate-600 dark:text-slate-300 font-inter leading-relaxed max-w-2xl font-light">
            MidMike connects the pulse of the underground with the precision of professional management. We are bridging the gap between talent, technology, and venues.
          </p>
          
          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4 pt-4 w-full justify-center">
            <button 
                onClick={handleCta}
                className="px-8 py-4 bg-slate-900 dark:bg-white text-white dark:text-black hover:bg-mid-primary dark:hover:bg-mid-highlight transition-all duration-500 rounded-full font-bold text-xs uppercase tracking-[0.2em] flex items-center justify-center gap-3 shadow-2xl hover:scale-105 active:scale-95"
            >
                {user ? 'Explore Network' : 'Join the Network'}
                <ArrowRight className="w-4 h-4" />
            </button>
            <button 
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="px-8 py-4 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/10 text-slate-900 dark:text-white rounded-full font-bold text-xs uppercase tracking-[0.2em] backdrop-blur-md transition-all flex items-center justify-center"
            >
                Contact Us
            </button>
          </div>
        </div>
        
        {/* Animated Background Elements - Theme Adaptive */}
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-white/60 via-transparent to-white/90 dark:from-black/40 dark:via-transparent dark:to-black/80 pointer-events-none" />
        <div className="absolute -top-[50%] -left-[50%] w-[200%] h-[200%] bg-[radial-gradient(circle_at_center,rgba(23,84,216,0.05),transparent_60%)] dark:bg-[radial-gradient(circle_at_center,rgba(23,84,216,0.15),transparent_60%)] animate-spin-slow pointer-events-none opacity-60" />
      </div>

      {/* 2. VISION & MISSION */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-20 px-4 md:px-0">
        <div className="p-10 rounded-[32px] bg-slate-100 dark:bg-white/[0.02] border border-slate-200 dark:border-white/5 backdrop-blur-xl relative overflow-hidden group hover:border-mid-primary/30 transition-colors shadow-sm dark:shadow-none">
          <div className="absolute top-0 right-0 p-10 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110 duration-700">
              <Target className="w-32 h-32 text-mid-primary" />
          </div>
          <div className="relative z-10 space-y-4">
             <div className="w-12 h-12 rounded-2xl bg-mid-primary/10 flex items-center justify-center text-mid-primary mb-6">
                 <Target className="w-6 h-6" />
             </div>
             <h3 className="text-2xl font-inter font-normal text-slate-900 dark:text-white">Our Mission</h3>
             <p className="text-slate-600 dark:text-mid-text-subtle leading-relaxed text-sm">
                To democratize access to premium stages. We believe every event is a symphony of coordination, and we provide the digital baton to conduct it. We empower artists to get paid fairly and venues to find reliable expertise.
             </p>
          </div>
        </div>

        <div className="p-10 rounded-[32px] bg-slate-900 dark:bg-[#121212] border border-slate-200 dark:border-white/5 relative overflow-hidden group shadow-xl dark:shadow-none">
           <div className="absolute inset-0 bg-gradient-to-br from-mid-accent/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
           <div className="relative z-10 space-y-4">
             <div className="w-12 h-12 rounded-2xl bg-mid-accent/10 flex items-center justify-center text-mid-accent mb-6">
                 <Globe className="w-6 h-6" />
             </div>
             <h3 className="text-2xl font-inter font-normal text-white">Our Vision</h3>
             <p className="text-slate-400 leading-relaxed text-sm">
                A borderless creative economy for the MENA region and beyond. We envision a world where talent flows freely, technical standards are universally high, and the "nightlife industry" is recognized as a professional ecosystem.
             </p>
           </div>
        </div>
      </div>

      {/* 3. IMPACT METRICS */}
      <div className="mb-24 border-y border-slate-200 dark:border-white/5 py-12 bg-slate-50/50 dark:bg-white/[0.01]">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center divide-y md:divide-y-0 md:divide-x divide-slate-200 dark:divide-white/5">
              <div className="px-4 py-4 md:py-0 space-y-2">
                  <h4 className="text-4xl md:text-5xl font-inter font-bold text-slate-900 dark:text-white">10k+</h4>
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Events Powered</p>
              </div>
              <div className="px-4 py-4 md:py-0 space-y-2">
                  <h4 className="text-4xl md:text-5xl font-inter font-bold text-mid-primary">$2M+</h4>
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Artist Revenue Generated</p>
              </div>
              <div className="px-4 py-4 md:py-0 space-y-2">
                  <h4 className="text-4xl md:text-5xl font-inter font-bold text-mid-accent">500+</h4>
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Verified Venues</p>
              </div>
          </div>
      </div>

      {/* 4. THE TEAM */}
      <div className="mb-24 px-4 md:px-0">
        <div className="flex flex-col items-center text-center mb-12 space-y-4">
           <h2 className="text-3xl md:text-4xl font-inter font-normal text-slate-900 dark:text-white">The Architects</h2>
           <p className="text-slate-500 dark:text-mid-text-muted text-sm max-w-xl">
             Built by a collective of audio engineers, producers, and software architects who lived the fragmentation of the industry firsthand.
           </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {TEAM.map((member, i) => (
              <div key={i} className="group relative bg-white dark:bg-white/[0.02] border border-slate-200 dark:border-white/5 rounded-3xl overflow-hidden hover:-translate-y-2 transition-all duration-500 shadow-sm hover:shadow-xl">
                  <div className="aspect-[4/5] overflow-hidden bg-slate-200 dark:bg-white/5 relative">
                      <img src={member.image} alt={member.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 grayscale group-hover:grayscale-0" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60" />
                      
                      <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                          <h4 className="text-white font-inter text-lg">{member.name}</h4>
                          <span className="text-mid-primary text-[10px] font-bold uppercase tracking-widest">{member.role}</span>
                      </div>
                  </div>
                  <div className="p-6">
                      <p className="text-xs text-slate-500 dark:text-mid-text-subtle leading-relaxed mb-4">
                          {member.bio}
                      </p>
                      <div className="flex gap-3 opacity-60 hover:opacity-100 transition-opacity">
                          <Linkedin className="w-4 h-4 text-slate-900 dark:text-white cursor-pointer hover:text-blue-500" />
                          <Twitter className="w-4 h-4 text-slate-900 dark:text-white cursor-pointer hover:text-blue-400" />
                      </div>
                  </div>
              </div>
          ))}
        </div>
      </div>

      {/* 5. FAQ SECTION */}
      <div className="mb-24 max-w-3xl mx-auto px-4 md:px-0">
          <div className="flex items-center gap-3 mb-8 justify-center">
             <HelpCircle className="w-5 h-5 text-mid-secondary" />
             <h2 className="text-xl font-inter font-normal text-slate-900 dark:text-white uppercase tracking-widest">Common Questions</h2>
          </div>

          <div className="space-y-4">
              {FAQS.map((faq, idx) => (
                  <div key={idx} className="bg-white dark:bg-white/[0.02] border border-slate-200 dark:border-white/5 rounded-2xl overflow-hidden shadow-sm dark:shadow-none">
                      <button 
                        onClick={() => toggleFaq(idx)}
                        className="w-full flex items-center justify-between p-6 text-left hover:bg-slate-50 dark:hover:bg-white/[0.02] transition-colors"
                      >
                          <span className="font-inter text-lg text-slate-900 dark:text-white">{faq.q}</span>
                          {openFaq === idx ? <ChevronUp className="w-5 h-5 text-slate-400" /> : <ChevronDown className="w-5 h-5 text-slate-400" />}
                      </button>
                      <div className={`overflow-hidden transition-[max-height] duration-500 ease-in-out ${openFaq === idx ? 'max-h-40' : 'max-h-0'}`}>
                          <div className="p-6 pt-0 text-sm text-slate-500 dark:text-mid-text-subtle leading-relaxed border-t border-slate-100 dark:border-white/5 mt-2">
                              {faq.a}
                          </div>
                      </div>
                  </div>
              ))}
          </div>
      </div>

      {/* 6. CONTACT & HQ */}
      <div id="contact" className="relative rounded-[32px] overflow-hidden bg-[#0a0a0a] border border-white/10 shadow-2xl">
         <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1492684223066-81342ee5ff30?q=80&w=2000')] bg-cover bg-center opacity-20 mix-blend-overlay" />
         
         <div className="relative z-10 grid grid-cols-1 md:grid-cols-2">
             <div className="p-10 md:p-16 space-y-8 border-b md:border-b-0 md:border-r border-white/10">
                 <h2 className="text-3xl md:text-4xl font-inter font-normal text-white">Let's Talk Business.</h2>
                 <p className="text-slate-400 text-sm leading-relaxed max-w-sm">
                     Whether you're a venue looking to digitize your operations or an investor interested in the future of the creator economy, we're listening.
                 </p>
                 
                 <div className="space-y-6 pt-4">
                     <div className="flex items-start gap-4">
                         <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
                             <MapPin className="w-4 h-4 text-white" />
                         </div>
                         <div>
                             <h5 className="text-white text-sm font-bold uppercase tracking-wider mb-1">Headquarters</h5>
                             <p className="text-slate-400 text-xs">15 Rue du Lac, Les Berges du Lac<br/>1053 Tunis, Tunisia</p>
                         </div>
                     </div>
                     
                     <div className="flex items-start gap-4">
                         <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
                             <Mail className="w-4 h-4 text-white" />
                         </div>
                         <div>
                             <h5 className="text-white text-sm font-bold uppercase tracking-wider mb-1">Email Us</h5>
                             <a href="mailto:hello@midmike.com" className="text-slate-400 text-xs hover:text-white transition-colors">hello@midmike.com</a>
                         </div>
                     </div>

                     <div className="flex items-start gap-4">
                         <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
                             <Phone className="w-4 h-4 text-white" />
                         </div>
                         <div>
                             <h5 className="text-white text-sm font-bold uppercase tracking-wider mb-1">Call Center</h5>
                             <p className="text-slate-400 text-xs">+216 55 000 000 (Mon-Fri)</p>
                         </div>
                     </div>
                 </div>
             </div>

             <div className="p-10 md:p-16 flex flex-col justify-between bg-white/[0.02]">
                 <div className="space-y-6">
                     <h3 className="text-white font-bold uppercase tracking-widest text-sm">Follow the movement</h3>
                     <div className="flex gap-4">
                         <a href="#" className="w-12 h-12 rounded-xl bg-white/5 hover:bg-white/20 border border-white/10 flex items-center justify-center transition-all text-white">
                             <Instagram className="w-5 h-5" />
                         </a>
                         <a href="#" className="w-12 h-12 rounded-xl bg-white/5 hover:bg-white/20 border border-white/10 flex items-center justify-center transition-all text-white">
                             <Linkedin className="w-5 h-5" />
                         </a>
                         <a href="#" className="w-12 h-12 rounded-xl bg-white/5 hover:bg-white/20 border border-white/10 flex items-center justify-center transition-all text-white">
                             <Twitter className="w-5 h-5" />
                         </a>
                     </div>
                 </div>

                 <div className="pt-12 mt-auto">
                     <div className="flex items-center gap-2 mb-4">
                         <Shield className="w-4 h-4 text-mid-secondary" />
                         <span className="text-[10px] font-bold text-mid-secondary uppercase tracking-widest">ISO 27001 Certified Security</span>
                     </div>
                     <p className="text-[10px] text-slate-500 uppercase tracking-widest">
                         © 2024 MidMike Platforms Inc. All rights reserved.
                     </p>
                 </div>
             </div>
         </div>
      </div>

    </div>
  );
};
