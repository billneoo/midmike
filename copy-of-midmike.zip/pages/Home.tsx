
import React, { useEffect, useState, useRef } from 'react';
import { Card } from '../components/Card';
import { api } from '../services/api';
import { EventEntity, ProfessionalEntity, BaseEntity } from '../types';
import { ArrowRight, Briefcase, Zap, Flame, TrendingUp } from 'lucide-react';
import { useBasket } from '../contexts/BasketContext';
import { useAuth } from '../contexts/AuthContext';

export const Home: React.FC<{ onNavigate: (route: string, params?: any) => void }> = ({ onNavigate }) => {
  const [featuredEvents, setFeaturedEvents] = useState<EventEntity[]>([]);
  const [artists, setArtists] = useState<ProfessionalEntity[]>([]);
  const [technicians, setTechnicians] = useState<ProfessionalEntity[]>([]);
  const [venues, setVenues] = useState<BaseEntity[]>([]);
  const [agencies, setAgencies] = useState<BaseEntity[]>([]);
  const [providers, setProviders] = useState<ProfessionalEntity[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const { addToBasket } = useBasket();
  const { user, setAuthModalOpen } = useAuth();

  useEffect(() => {
    const loadData = async () => {
      try {
        const [
          eventsData, 
          artistsData, 
          techniciansData, 
          venuesData, 
          agenciesData, 
          providersData
        ] = await Promise.all([
          api.getFeaturedEvents(),
          api.getFeaturedArtists(),
          api.getFeaturedTechnicians(),
          api.getFeaturedVenues(),
          api.getFeaturedAgencies(),
          api.getFeaturedServiceProviders()
        ]);
        setFeaturedEvents(eventsData);
        setArtists(artistsData);
        setTechnicians(techniciansData); 
        setVenues(venuesData);
        setAgencies(agenciesData);
        setProviders(providersData);
      } catch (error) {
        console.error("Failed to load home data", error);
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, []);

  if (isLoading) {
    return (
      <div className="h-[80vh] flex flex-col items-center justify-center gap-6">
        <div className="w-16 h-16 border-4 border-mid-primary/20 border-t-mid-primary rounded-full animate-spin"></div>
        <div className="text-mid-text-muted font-inter font-normal tracking-[0.3em] animate-pulse text-xs uppercase">Initialising Experience</div>
      </div>
    );
  }

  const handleProCTAClick = () => {
    if (!user) {
        setAuthModalOpen(true);
    } else {
        onNavigate('opportunities');
    }
  };

  return (
    <div className="pb-20 animate-cinematic-fade">
      
      {/* 1. Events Section (Glass Runway) */}
      <Section 
        index={0}
        colorClass="text-mid-primary bg-mid-primary/60"
        title="Upcoming Events" 
        items={featuredEvents} 
        variant="glass-runway"
        renderItem={(evt) => (
            <Card 
                key={evt.id}
                variant="portrait-action"
                image={evt.imageUrl}
                title={evt.title}
                subtitle={evt.location}
                date={evt.date}
                badge={evt.category}
                imageAspectRatio="square"
                onClick={() => onNavigate('event-details', { id: evt.id })}
                showLoveAction={true}
            />
        )}
      />

      {/* 2. Artists Section */}
      <Section 
        index={1}
        colorClass="text-mid-secondary bg-mid-secondary/60"
        title="Verified Artists" 
        items={artists}
        renderItem={(artist) => (
            <Card 
                key={artist.id}
                variant="portrait-action"
                image={artist.imageUrl}
                title={artist.title}
                subtitle={artist.profession}
                badge={artist.tags?.[0]}
                verified={artist.verified}
                rating={artist.rating}
                imageAspectRatio="square"
                showBookingAction={true}
                showLoveAction={true}
                onBook={() => addToBasket(artist)}
                onClick={() => onNavigate('artist-details', { id: artist.id })}
            />
        )}
      />

      {/* Professional CTA Banner - KEEPING TIEMPOS HERE AS REQUESTED */}
      <section className="my-8 md:my-12 px-4 md:px-0">
          <div className="premium-shiny-container rounded-[32px] overflow-hidden p-8 md:p-16 flex flex-col md:flex-row items-center justify-between gap-12 shadow-glass-deep">
              <div className="flex flex-col gap-6 text-center md:text-left max-w-xl">
                  <div className="flex items-center justify-center md:justify-start gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 flex items-center justify-center shadow-glow-accent/20">
                          <Briefcase className="w-6 h-6 text-mid-accent" />
                      </div>
                      <span className="text-xs font-bold text-mid-accent uppercase tracking-[0.4em]">Pro Network</span>
                  </div>
                  <h2 className="text-3xl md:text-5xl font-tiempos font-normal text-black dark:text-white leading-[1.1] tracking-tight">
                      Elevate your career. <br/><span className="text-neutral-500 dark:text-white/60 italic">Find your next spotlight.</span>
                  </h2>
                  <p className="text-neutral-600 dark:text-mid-text-muted text-sm md:text-base font-inter leading-relaxed">
                      Join the most exclusive nightlife ecosystem. Showcase your talent, manage technical requirements, and get booked by world-class venues.
                  </p>
              </div>
              
              <div className="flex flex-col gap-6 w-full md:w-auto shrink-0">
                  <button 
                    onClick={handleProCTAClick}
                    className="group relative px-6 py-3 md:px-12 md:py-5 bg-black dark:bg-white text-white dark:text-black hover:bg-neutral-800 dark:hover:bg-mid-highlight transition-all duration-500 rounded-full font-bold text-[10px] md:text-[13px] uppercase tracking-[0.25em] flex items-center justify-center gap-3 md:gap-4 shadow-2xl"
                  >
                      <Zap className="w-4 h-4 md:w-5 md:h-5 fill-current" />
                      Find Opportunities
                  </button>
                  <p className="text-center text-[10px] text-mid-text-subtle font-bold uppercase tracking-widest opacity-40">
                      Access premium global placements
                  </p>
              </div>
          </div>
      </section>

      {/* 3. Technicians Section */}
      <Section 
        index={2}
        colorClass="text-mid-accent bg-mid-accent/60"
        title="Technical Experts" 
        items={technicians} 
        renderItem={(tech) => (
            <Card 
                key={tech.id}
                variant="portrait-action"
                image={tech.imageUrl}
                title={tech.title}
                subtitle={tech.profession}
                badge={tech.tags?.[0]}
                verified={tech.verified}
                rating={tech.rating}
                imageAspectRatio="square"
                showBookingAction={true}
                showLoveAction={true}
                onBook={() => addToBasket(tech)}
                onClick={() => onNavigate('technician-details', { id: tech.id })}
            />
        )}
      />

      {/* 4. Venues Section */}
      <Section 
        index={3}
        colorClass="text-mid-secondary bg-mid-secondary/60"
        title="Premium Venues" 
        items={venues} 
        renderItem={(venue) => (
            <Card 
                key={venue.id}
                variant="portrait-action"
                image={venue.imageUrl}
                title={venue.title}
                subtitle={venue.location}
                badge={venue.category}
                verified={venue.verified}
                rating={venue.rating}
                imageAspectRatio="16/9"
                showBookingAction={true}
                showLoveAction={true}
                onBook={() => addToBasket(venue)}
                onClick={() => onNavigate('venue-details', { id: venue.id })}
            />
        )}
      />

      {/* 5. Agencies Section */}
      <Section 
        index={4}
        colorClass="text-mid-primary bg-mid-primary/60"
        title="Agencies" 
        items={agencies} 
        renderItem={(agency) => (
            <Card 
                key={agency.id}
                variant="portrait-action"
                image={agency.imageUrl}
                title={agency.title}
                subtitle={agency.location}
                badge={agency.category}
                verified={agency.verified}
                rating={agency.rating}
                imageAspectRatio="16/9"
                showBookingAction={true}
                showLoveAction={true}
                onBook={() => addToBasket(agency)}
                onClick={() => onNavigate('agency-details', { id: agency.id })}
            />
        )}
      />

      {/* 6. Service Providers Section */}
      <Section 
        index={5}
        colorClass="text-mid-accent bg-mid-accent/60"
        title="Service Providers" 
        items={providers} 
        renderItem={(provider) => (
            <Card 
                key={provider.id}
                variant="portrait-action"
                image={provider.imageUrl}
                title={provider.title}
                subtitle={provider.profession}
                badge={provider.category}
                verified={provider.verified}
                rating={provider.rating}
                imageAspectRatio="16/9"
                showBookingAction={true}
                showLoveAction={true}
                onBook={() => addToBasket(provider)}
                onClick={() => onNavigate('provider-details', { id: provider.id })}
            />
        )}
      />

    </div>
  );
};

interface SectionProps {
  title: string;
  items: any[];
  renderItem: (item: any) => React.ReactNode;
  index: number;
  colorClass: string;
  variant?: 'default' | 'glass-runway';
}

const Section = ({ title, items, renderItem, index, colorClass, variant = 'default' }: SectionProps) => {
    const indicatorColor = colorClass.split(' ')[0];
    const barColor = colorClass.split(' ')[1];
    const isRunway = variant === 'glass-runway';
    
    // Drag to Scroll Logic
    const scrollRef = useRef<HTMLDivElement>(null);
    const [isDragging, setIsDragging] = useState(false);
    const [startX, setStartX] = useState(0);
    const [scrollLeft, setScrollLeft] = useState(0);

    const handleMouseDown = (e: React.MouseEvent) => {
        if (!scrollRef.current) return;
        setIsDragging(true);
        setStartX(e.pageX - scrollRef.current.offsetLeft);
        setScrollLeft(scrollRef.current.scrollLeft);
        scrollRef.current.style.cursor = 'grabbing';
        scrollRef.current.style.scrollBehavior = 'auto'; // Disable smooth scroll while dragging for responsiveness
    };

    const handleMouseLeave = () => {
        if (!scrollRef.current) return;
        setIsDragging(false);
        scrollRef.current.style.cursor = 'grab';
        scrollRef.current.style.scrollBehavior = 'smooth';
    };

    const handleMouseUp = () => {
        if (!scrollRef.current) return;
        setIsDragging(false);
        scrollRef.current.style.cursor = 'grab';
        scrollRef.current.style.scrollBehavior = 'smooth';
    };

    const handleMouseMove = (e: React.MouseEvent) => {
        if (!isDragging || !scrollRef.current) return;
        e.preventDefault();
        const x = e.pageX - scrollRef.current.offsetLeft;
        const walk = (x - startX) * 2; // Scroll-fast multiplier
        scrollRef.current.scrollLeft = scrollLeft - walk;
    };

    const scroll = (direction: 'left' | 'right') => {
        if (scrollRef.current) {
            const amount = direction === 'left' ? -340 : 340;
            scrollRef.current.scrollBy({ left: amount, behavior: 'smooth' });
        }
    };

    return (
        <section className={`mt-6 md:mt-8 relative px-4 md:px-0 group/section ${isRunway ? 'pt-4 pb-8' : ''}`}>
            
            {/* Header */}
            <div className={`
                ${isRunway 
                    ? 'flex flex-col gap-4 border-transparent px-2 md:px-4 pb-6' 
                    : 'flex items-end justify-between border-b border-black/5 dark:border-white/[0.08] pb-6'
                }
            `}>
                 {/* Title Section */}
                 <div className={`flex flex-col gap-2 ${isRunway ? 'w-full' : ''}`}>
                    {!isRunway && (
                        <div className="flex items-center gap-3">
                            <span className={`w-8 h-[2px] ${barColor}`}></span>
                            <span className={`text-[10px] font-bold uppercase tracking-[0.4em] ${indicatorColor}`}>Category 0{index + 1}</span>
                        </div>
                    )}
                    
                    <h2 className={`
                        font-inter font-semibold tracking-wide
                        ${isRunway 
                            ? 'text-[32px] md:text-[34px] tracking-tight leading-tight pb-1 text-transparent bg-clip-text bg-gradient-to-r from-slate-900 via-slate-700 to-slate-900 dark:from-white dark:via-slate-200 dark:to-white drop-shadow-sm relative z-[100]' 
                            : 'text-[24px] md:text-[30px] text-slate-900 dark:text-white'
                        }
                    `}>
                        {title}
                    </h2>
                 </div>
                 
                 {/* Controls Section */}
                 {isRunway ? (
                     <div className="flex items-center justify-between w-full mt-2">
                        {/* Trending Badge */}
                        <div className="px-3 py-1 rounded-full bg-orange-500/10 border border-orange-500/20 flex items-center gap-2 animate-in fade-in zoom-in duration-700">
                            <Flame className="w-3 h-3 text-orange-500 fill-orange-500 animate-pulse" />
                            <span className="text-[9px] font-bold text-orange-500 uppercase tracking-widest">Trending Now</span>
                        </div>

                        {/* Actions */}
                        <div className="flex gap-2">
                            <button onClick={() => scroll('left')} className="hidden md:flex w-10 h-10 rounded-full border border-slate-200 dark:border-white/10 items-center justify-center hover:bg-slate-100 dark:hover:bg-white/5 transition-all text-slate-500 dark:text-white">
                                <ArrowRight className="w-4 h-4 rotate-180" />
                            </button>
                            <button onClick={() => scroll('right')} className="hidden md:flex w-10 h-10 rounded-full border border-slate-200 dark:border-white/10 items-center justify-center hover:bg-slate-100 dark:hover:bg-white/5 transition-all text-slate-500 dark:text-white">
                                <ArrowRight className="w-4 h-4" />
                            </button>
                            <button className="group flex items-center gap-2 md:gap-3 px-4 py-2 md:px-6 md:py-2.5 rounded-full border border-black/5 dark:border-white/10 hover:border-mid-primary/50 hover:bg-mid-primary/5 transition-all duration-500">
                                <span className="text-[9px] md:text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle group-hover:text-mid-primary transition-colors whitespace-nowrap">View All</span>
                                <ArrowRight className="w-3.5 h-3.5 md:w-4 md:h-4 text-slate-400 group-hover:text-mid-primary group-hover:translate-x-1 transition-all" />
                            </button>
                        </div>
                     </div>
                 ) : (
                     <div className="flex gap-2">
                        <button onClick={() => scroll('left')} className="hidden md:flex w-10 h-10 rounded-full border border-slate-200 dark:border-white/10 items-center justify-center hover:bg-slate-100 dark:hover:bg-white/5 transition-all text-slate-500 dark:text-white">
                            <ArrowRight className="w-4 h-4 rotate-180" />
                        </button>
                        <button onClick={() => scroll('right')} className="hidden md:flex w-10 h-10 rounded-full border border-slate-200 dark:border-white/10 items-center justify-center hover:bg-slate-100 dark:hover:bg-white/5 transition-all text-slate-500 dark:text-white">
                            <ArrowRight className="w-4 h-4" />
                        </button>
                        <button className="group flex items-center gap-2 md:gap-3 px-4 py-2 md:px-6 md:py-2.5 rounded-full border border-black/5 dark:border-white/10 hover:border-mid-primary/50 hover:bg-mid-primary/5 transition-all duration-500">
                            <span className="text-[9px] md:text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle group-hover:text-mid-primary transition-colors whitespace-nowrap">View All</span>
                            <ArrowRight className="w-3.5 h-3.5 md:w-4 md:h-4 text-slate-400 group-hover:text-mid-primary group-hover:translate-x-1 transition-all" />
                        </button>
                     </div>
                 )}
            </div>
            
            {/* Immersive Horizontal Scroll for both Mobile and Desktop with Drag */}
            <div className={`relative ${isRunway ? '-mx-4 md:-mx-8' : ''}`}>
                {/* Glass Runway Track Background */}
                {isRunway && (
                    <div className="absolute inset-0 bg-gradient-to-r from-slate-100/50 via-white/40 to-slate-100/50 dark:from-white/[0.02] dark:via-white/[0.05] dark:to-white/[0.02] backdrop-blur-md border-y border-white/20 dark:border-white/5 shadow-[inset_0_0_20px_rgba(0,0,0,0.05)] z-0 pointer-events-none" />
                )}
                {isRunway && (
                    <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-mid-primary/50 to-transparent shadow-[0_0_10px_rgba(23,84,216,0.5)] z-10" />
                )}

                <div 
                    ref={scrollRef}
                    className={`
                        flex overflow-x-auto gap-8 pb-12 px-4 md:px-8 snap-x snap-mandatory no-scrollbar mask-gradient-x cursor-grab active:cursor-grabbing relative z-10
                        ${isRunway ? 'pt-8 pb-12' : 'mt-8 -mx-4 md:mx-0 md:px-0'}
                    `}
                    onMouseDown={handleMouseDown}
                    onMouseLeave={handleMouseLeave}
                    onMouseUp={handleMouseUp}
                    onMouseMove={handleMouseMove}
                >
                    {items.map((item, idx) => (
                        <div key={idx} className="min-w-[280px] md:min-w-[320px] lg:min-w-[340px] snap-center pointer-events-auto select-none">
                            {renderItem(item)}
                        </div>
                    ))}
                    <div className="min-w-[40px] shrink-0" />
                </div>
            </div>
        </section>
    );
};
