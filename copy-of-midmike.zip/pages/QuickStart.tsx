
import React from 'react';
import { Play, Zap, ArrowRight, Monitor, Mic2, Calendar, User, ArrowLeft, BookOpen, GraduationCap } from 'lucide-react';
import { useTour } from '../contexts/TourContext';
import { OptimizedImage } from '../components/Card';

interface QuickStartProps {
  onNavigate: (route: string) => void;
}

const TUTORIALS = [
    {
        id: 1,
        title: "Creating Your First Event",
        duration: "2:15",
        category: "Basics",
        thumbnail: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?q=80&w=400&auto=format&fit=crop",
        icon: Calendar
    },
    {
        id: 2,
        title: "Managing Professional Roles",
        duration: "1:45",
        category: "Profile",
        thumbnail: "https://images.unsplash.com/photo-1551818255-e6e10975bc17?q=80&w=400&auto=format&fit=crop",
        icon: User
    },
    {
        id: 3,
        title: "Booking Artists & Techs",
        duration: "3:20",
        category: "Pro Tools",
        thumbnail: "https://images.unsplash.com/photo-1598387993441-a364f854c3e1?q=80&w=400&auto=format&fit=crop",
        icon: Mic2
    },
    {
        id: 4,
        title: "Using the Studio Booking System",
        duration: "1:30",
        category: "Services",
        thumbnail: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=400&auto=format&fit=crop",
        icon: Monitor
    }
];

export const QuickStart: React.FC<QuickStartProps> = ({ onNavigate }) => {
  const { startTour } = useTour();

  return (
    <div className="animate-cinematic-fade pb-24 pt-6 min-h-screen">
       
       {/* Header */}
       <div className="max-w-7xl mx-auto px-4 md:px-8 mb-12">
          <button 
                onClick={() => onNavigate('home')}
                className="group flex items-center gap-3 px-5 py-2.5 rounded-full border border-slate-200 dark:border-white/10 bg-white/50 dark:bg-white/5 backdrop-blur-md hover:border-mid-primary/50 hover:bg-mid-primary/5 transition-all duration-300 w-fit mb-8"
            >
                <ArrowLeft className="w-4 h-4 text-slate-500 dark:text-slate-400 group-hover:text-mid-primary transition-colors" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 group-hover:text-mid-primary transition-colors">Back Home</span>
          </button>
          
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
              <div className="flex flex-col gap-6 max-w-2xl">
                 <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-2xl bg-mid-primary/10 flex items-center justify-center border border-mid-primary/20 shadow-glow-blue/20">
                        <Zap className="w-7 h-7 text-mid-primary" />
                    </div>
                    <div>
                        <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-mid-primary mb-1 block">Onboarding Protocol</span>
                        <h1 className="text-4xl md:text-5xl font-tiempos font-normal text-slate-900 dark:text-white">Quick Start Guide</h1>
                    </div>
                 </div>
                 <p className="text-slate-600 dark:text-slate-400 text-lg leading-relaxed pl-1">
                    Master the platform in minutes. Learn how to create events, manage your professional profile, and book talent securely.
                 </p>
              </div>

              {/* Interactive Tour CTA */}
              <div className="w-full lg:w-auto relative group cursor-pointer" onClick={startTour}>
                  <div className="absolute inset-0 bg-gradient-to-r from-mid-primary via-blue-600 to-mid-primary opacity-20 blur-xl group-hover:opacity-30 transition-opacity rounded-3xl" />
                  <div className="relative bg-[#121212] border border-white/10 rounded-3xl p-6 flex items-center gap-6 shadow-2xl hover:scale-[1.02] transition-transform">
                      <div className="flex flex-col">
                          <h3 className="text-xl font-tiempos font-medium text-white">Interactive Tour</h3>
                          <p className="text-xs text-slate-400 mt-1">Guided walkthrough of key features</p>
                      </div>
                      <div className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center">
                          <Play className="w-5 h-5 fill-current ml-0.5" />
                      </div>
                  </div>
              </div>
          </div>
       </div>

       {/* Video Grid */}
       <div className="max-w-7xl mx-auto px-4 md:px-8 space-y-8">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-200 dark:border-white/5">
              <GraduationCap className="w-5 h-5 text-mid-secondary" />
              <h2 className="text-sm font-bold uppercase tracking-[0.2em] text-slate-900 dark:text-white">Video Tutorials</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {TUTORIALS.map((video) => (
                  <div key={video.id} className="group flex flex-col gap-4 cursor-pointer">
                      <div className="relative aspect-video rounded-2xl overflow-hidden bg-slate-900 border border-white/10 shadow-lg group-hover:shadow-glow-blue/20 transition-all duration-300">
                          <OptimizedImage 
                              src={video.thumbnail} 
                              alt={video.title} 
                              containerClass="w-full h-full" 
                              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-80 group-hover:opacity-100" 
                          />
                          <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                              <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 scale-90 group-hover:scale-100 transition-transform">
                                  <Play className="w-5 h-5 text-white fill-current ml-0.5" />
                              </div>
                          </div>
                          <div className="absolute bottom-3 right-3 px-2 py-1 bg-black/80 backdrop-blur-md rounded-md text-[9px] font-bold text-white uppercase tracking-wider">
                              {video.duration}
                          </div>
                          <div className="absolute top-3 left-3 px-2 py-1 bg-mid-primary/90 backdrop-blur-md rounded-md text-[8px] font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                              <video.icon className="w-3 h-3" /> {video.category}
                          </div>
                      </div>
                      <div className="space-y-1">
                          <h3 className="text-lg font-tiempos font-medium text-slate-900 dark:text-white leading-tight group-hover:text-mid-primary transition-colors">
                              {video.title}
                          </h3>
                          <p className="text-xs text-slate-500 dark:text-slate-400">Step-by-step guide</p>
                      </div>
                  </div>
              ))}
          </div>
       </div>

       {/* FAQ / Support Section */}
       <div className="max-w-7xl mx-auto px-4 md:px-8 mt-20">
           <div className="bg-slate-100 dark:bg-white/[0.02] border border-slate-200 dark:border-white/5 rounded-[32px] p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8 text-center md:text-left">
               <div className="space-y-4 max-w-xl">
                   <h2 className="text-2xl md:text-3xl font-tiempos font-normal text-slate-900 dark:text-white">Still need help?</h2>
                   <p className="text-slate-600 dark:text-mid-text-subtle text-sm leading-relaxed">
                       Our support team is available 24/7 to assist with technical issues, verification requests, or payment inquiries.
                   </p>
               </div>
               <button className="px-8 py-4 bg-slate-900 dark:bg-white text-white dark:text-black rounded-full font-bold text-xs uppercase tracking-[0.2em] hover:scale-105 transition-transform shadow-xl">
                   Contact Support
               </button>
           </div>
       </div>

    </div>
  );
};
