
import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, LayoutDashboard, Users, Ticket, CheckCircle, XCircle, 
  Activity, TrendingUp, Search, Eye, AlertTriangle, MoreHorizontal,
  DollarSign, LogOut, ShieldCheck, Zap, Globe, Lock, BarChart3, 
  Radio, Flame, ChevronRight, Save, Settings, Layers, CreditCard, 
  Scale, RadioTower, Bell, Monitor, Smartphone, RefreshCw, 
  Database, Server, Cpu, HardDrive, Filter, Download, Briefcase, Calendar
} from 'lucide-react';

interface AdminProps {
  onNavigate: (route: string) => void;
}

type AdminSection = 'overview' | 'finance' | 'moderation' | 'ops' | 'security' | 'users' | 'diagnostics';

// --- Tactical Mock Data ---

const PENDING_PAYOUTS = [
    { id: 'TX_102', artist: 'A.L.A', event: 'Friday Night Party', amount: 1200, status: 'Clearable', date: 'Oct 24' },
    { id: 'TX_105', artist: 'Benjemy', event: 'Analog Ritual', amount: 850, status: 'Escrow', date: 'Oct 25' },
    { id: 'TX_109', artist: 'Nour H.', event: 'Studio Session', amount: 400, status: 'Disputed', date: 'Oct 26' },
    { id: 'TX_112', artist: 'DJ Black', event: 'Sunset Set', amount: 2100, status: 'Clearable', date: 'Oct 27' },
];

const CONTENT_QUEUE = [
    { id: 'vid_01', title: 'Ep. 42: The Future of Tunisian Techno', user: 'MidMike TV', views: '12k', status: 'Live', type: 'Podcast' },
    { id: 'vid_02', title: 'Backstage Raw: The Warehouse', user: 'User_X', views: '4k', status: 'Pending', type: 'Short' },
    { id: 'vid_03', title: 'Deep House Sunset @ La Marsa', user: 'DJ Black', views: '8.5k', status: 'Featured', type: 'Live Set' },
];

const AUDIT_LOGS = [
    { id: 'log_01', admin: 'Sarah', target: 'Commission Rate', action: 'Set to 12% globally', time: '12m ago' },
    { id: 'log_02', admin: 'System', target: 'IP 192.168.1.1', action: 'Auto-blacklisted (DDoS)', time: '45m ago' },
    { id: 'log_03', admin: 'Malek', target: 'User_88', action: 'Granted VIP/Pro status', time: '2h ago' },
];

// --- Styled Sub-Components ---

const TacticalCard = ({ title, subtitle, children, icon: Icon, action, className }: { title: string, subtitle?: string, children?: React.ReactNode, icon: any, action?: React.ReactNode, className?: string }) => (
    <div className={`bg-white dark:bg-[#121212]/60 border border-slate-200 dark:border-white/5 rounded-3xl overflow-hidden backdrop-blur-3xl shadow-soft-xl group ${className || ''}`}>
        <div className="px-6 py-5 border-b border-slate-100 dark:border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-500">
                    <Icon className="w-5 h-5" />
                </div>
                <div>
                    <h4 className="text-xs font-black uppercase tracking-[0.2em] text-slate-900 dark:text-white">{title}</h4>
                    {subtitle && <p className="text-[10px] text-slate-500 dark:text-mid-text-subtle font-medium">{subtitle}</p>}
                </div>
            </div>
            {action}
        </div>
        <div className="p-6">
            {children}
        </div>
    </div>
);

const ControlToggle = ({ active, label, sub, onToggle }: { active: boolean, label: string, sub: string, onToggle?: () => void }) => (
    <div className="flex items-center justify-between py-4">
        <div className="space-y-0.5">
            <h5 className="text-[11px] font-bold text-slate-900 dark:text-white uppercase tracking-wider">{label}</h5>
            <p className="text-[9px] text-slate-500 dark:text-mid-text-subtle">{sub}</p>
        </div>
        <button 
            onClick={onToggle}
            className={`w-10 h-5 rounded-full relative transition-all duration-500 ${active ? 'bg-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.4)]' : 'bg-slate-300 dark:bg-white/10'}`}
        >
            <div className={`absolute top-1 left-1 w-3 h-3 rounded-full bg-white transition-all duration-500 shadow-sm ${active ? 'translate-x-5' : 'translate-x-0'}`} />
        </button>
    </div>
);

const SectionTab = ({ active, label, icon: Icon, onClick }: { active: boolean, label: string, icon: any, onClick: () => void }) => (
    <button 
        onClick={onClick}
        className={`
            flex items-center gap-3 px-6 py-3.5 rounded-2xl transition-all duration-300 w-full relative group
            ${active 
                ? 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 border border-cyan-500/20 shadow-glow-blue/5' 
                : 'text-slate-500 dark:text-mid-text-subtle hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5 border border-transparent'}
        `}
    >
        <Icon className={`w-4 h-4 transition-all duration-300 ${active ? 'scale-110' : 'group-hover:scale-110'}`} />
        <span className="text-[10px] font-black uppercase tracking-widest">{label}</span>
        {active && (
            <div className="absolute right-4 w-1.5 h-1.5 rounded-full bg-cyan-500 shadow-[0_0_10px_rgba(6,182,212,1)]" />
        )}
    </button>
);

export const Admin: React.FC<AdminProps> = ({ onNavigate }) => {
  const [activeSection, setActiveSection] = useState<AdminSection>('overview');
  const [announcement, setAnnouncement] = useState('New studio gear arriving tomorrow! Book your sessions early.');
  const [globalCommission, setGlobalCommission] = useState(12);
  const [isMaintenanceMode, setIsMaintenanceMode] = useState(false);
  const [isLockdown, setIsLockdown] = useState(false);
  const [uptime, setUptime] = useState(99.98);

  // Simulate dynamic uptime
  useEffect(() => {
    const interval = setInterval(() => {
        setUptime(prev => Math.min(100, prev + (Math.random() * 0.01 - 0.005)));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-[#F2F4F7] dark:bg-[#0D0D0D] text-slate-900 dark:text-white font-inter selection:bg-cyan-500/30 transition-colors duration-500">
        
        {/* --- TACTICAL TOP BAR --- */}
        <div className="h-20 border-b border-slate-200 dark:border-white/5 bg-white/70 dark:bg-[#0D0D0D]/70 backdrop-blur-3xl flex items-center justify-between px-8 sticky top-0 z-[100] shadow-glass dark:shadow-none">
            <div className="flex items-center gap-5">
                <div className="relative group">
                    <div className="absolute inset-0 bg-cyan-500/20 blur-xl group-hover:bg-cyan-500/40 transition-all rounded-full" />
                    <div className="relative w-10 h-10 bg-black dark:bg-white/5 border border-white/10 rounded-xl flex items-center justify-center text-cyan-400 shadow-2xl">
                        <ShieldAlert className={`w-5 h-5 ${isLockdown ? 'text-red-500 animate-pulse' : 'animate-pulse'}`} />
                    </div>
                </div>
                <div className="flex flex-col">
                    <span className="text-[11px] font-black tracking-[0.3em] uppercase text-slate-900 dark:text-white leading-none mb-1.5">God Mode HUD</span>
                    <div className="flex items-center gap-2">
                        <div className={`w-1.5 h-1.5 rounded-full ${isMaintenanceMode ? 'bg-amber-500' : 'bg-green-500 shadow-[0_0_10px_rgba(34,197,94,1)]'}`} />
                        <span className="text-[9px] text-slate-400 font-mono tracking-widest uppercase">{isMaintenanceMode ? 'Maintenance_Active' : 'System_Ready_v2.4.8'}</span>
                    </div>
                </div>
            </div>
            
            <div className="flex items-center gap-8">
                {/* Global Metrics Bar */}
                <div className="hidden lg:flex items-center gap-8 px-8 border-x border-slate-200 dark:border-white/5 h-10">
                    <div className="flex flex-col items-center">
                        <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest mb-0.5">Global Uptime</span>
                        <span className="text-[10px] font-mono text-cyan-500">{uptime.toFixed(2)}%</span>
                    </div>
                    <div className="flex flex-col items-center">
                        <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest mb-0.5">Traffic IQ</span>
                        <span className="text-[10px] font-mono text-green-500">Nominal</span>
                    </div>
                </div>

                <button 
                    onClick={() => onNavigate('home')} 
                    className="group flex items-center gap-3 px-5 py-2.5 rounded-full bg-slate-900 text-white dark:bg-white dark:text-black hover:opacity-90 transition-all shadow-xl active:scale-95"
                >
                    <span className="text-[10px] font-black uppercase tracking-widest">Terminate Session</span>
                    <LogOut className="w-4 h-4" />
                </button>
            </div>
        </div>

        <div className="flex flex-col md:flex-row h-[calc(100vh-80px)]">
            
            {/* --- ADMIN SIDEBAR NAV --- */}
            <div className="w-full md:w-72 bg-white dark:bg-[#0D0D0D] border-r border-slate-200 dark:border-white/5 p-6 flex flex-col gap-2 shrink-0 overflow-y-auto no-scrollbar">
                <div className="mb-4 px-2">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-[0.3em]">Command Hierarchy</span>
                </div>
                
                <SectionTab active={activeSection === 'overview'} label="Intelligence Hub" icon={LayoutDashboard} onClick={() => setActiveSection('overview')} />
                <SectionTab active={activeSection === 'finance'} label="The Treasury" icon={DollarSign} onClick={() => setActiveSection('finance')} />
                <SectionTab active={activeSection === 'moderation'} label="Content Architect" icon={Layers} onClick={() => setActiveSection('moderation')} />
                <SectionTab active={activeSection === 'ops'} label="Field Operations" icon={Briefcase} onClick={() => setActiveSection('ops')} />
                <SectionTab active={activeSection === 'users'} label="Identity Registry" icon={Users} onClick={() => setActiveSection('users')} />
                <SectionTab active={activeSection === 'security'} label="Shield & Security" icon={Lock} onClick={() => setActiveSection('security')} />
                <SectionTab active={activeSection === 'diagnostics'} label="System Health" icon={Server} onClick={() => setActiveSection('diagnostics')} />

                <div className="mt-auto space-y-4 pt-6 border-t border-slate-200 dark:border-white/5">
                    <div className="p-4 rounded-2xl bg-cyan-500/5 border border-cyan-500/10">
                        <div className="flex items-center gap-2 mb-2">
                            <Activity className="w-3.5 h-3.5 text-cyan-500" />
                            <span className="text-[9px] font-black uppercase text-cyan-600 dark:text-cyan-400 tracking-widest">Platform Sync</span>
                        </div>
                        <div className="h-1.5 w-full bg-slate-200 dark:bg-white/5 rounded-full overflow-hidden">
                            <div className="h-full bg-cyan-500 w-[88%] animate-pulse" />
                        </div>
                    </div>
                </div>
            </div>

            {/* --- MAIN STAGE --- */}
            <div className="flex-1 overflow-y-auto bg-[#F2F4F7] dark:bg-[#080808] p-6 md:p-10 relative no-scrollbar">
                <div className="bg-grain opacity-[0.05] absolute inset-0 pointer-events-none" />
                
                {/* --- 1. OVERVIEW: TACTICAL METRICS --- */}
                {activeSection === 'overview' && (
                    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700">
                        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                            <div className="space-y-1">
                                <h2 className="text-3xl md:text-5xl font-tiempos font-normal tracking-tight text-slate-900 dark:text-white">Strategic Intel</h2>
                                <p className="text-[10px] md:text-[12px] text-slate-500 dark:text-mid-text-subtle uppercase tracking-[0.4em] font-bold">Real-time Platform Activity</p>
                            </div>
                            <div className="flex items-center gap-3">
                                <button className="p-3 rounded-2xl bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/10 transition-all">
                                    <RefreshCw className="w-5 h-5 text-slate-500" />
                                </button>
                                <button className="px-6 py-3 rounded-2xl bg-cyan-500 text-white font-black text-[10px] uppercase tracking-widest shadow-glow-blue hover:scale-105 transition-all">Export Weekly Dossier</button>
                            </div>
                        </header>

                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                            {[
                                { label: 'Platform Rev', val: '$142,890', trend: '+12%', color: 'text-green-500', icon: BarChart3 },
                                { label: 'Live Pro Nodes', val: '24', trend: 'Transmitting', color: 'text-mid-primary', icon: RadioTower },
                                { label: 'Match Ratio', val: '74%', trend: '+5.2%', color: 'text-mid-accent', icon: Zap },
                                { label: 'Audit Risk', val: 'Nominal', trend: '0.02%', color: 'text-cyan-500', icon: ShieldCheck },
                            ].map((s, i) => (
                                <div key={i} className="bg-white dark:bg-[#121212] border border-slate-200 dark:border-white/5 p-8 rounded-[32px] shadow-soft-xl hover:translate-y-[-4px] transition-all duration-500 group">
                                    <div className="flex justify-between items-start mb-6">
                                        <div className={`w-12 h-12 rounded-2xl bg-slate-100 dark:bg-white/5 flex items-center justify-center ${s.color} group-hover:scale-110 transition-transform`}>
                                            <s.icon className="w-6 h-6" />
                                        </div>
                                        <TrendingUp className="w-4 h-4 text-green-500 opacity-40" />
                                    </div>
                                    <p className="text-[10px] font-black uppercase tracking-[0.25em] text-slate-500 dark:text-mid-text-subtle mb-1">{s.label}</p>
                                    <div className="flex items-baseline gap-2">
                                        <h3 className="text-3xl font-mono text-slate-900 dark:text-white">{s.val}</h3>
                                        <span className={`text-[10px] font-bold ${s.color}`}>{s.trend}</span>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                            {/* Live Verification Queue */}
                            <TacticalCard title="Clearance Queue" subtitle="Pending Industry Verification" icon={CheckCircle} action={<button className="text-[9px] font-black uppercase text-cyan-500 hover:underline">Batch Process</button>}>
                                <div className="space-y-2">
                                    {[1, 2, 3].map(i => (
                                        <div key={i} className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/5 hover:border-cyan-500/30 transition-all group">
                                            <div className="flex items-center gap-4">
                                                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-mid-primary to-cyan-500 p-[1px]">
                                                    <div className="w-full h-full rounded-full bg-white dark:bg-mid-bg" />
                                                </div>
                                                <div>
                                                    <h5 className="text-xs font-bold text-slate-900 dark:text-white">Candidate_RX_{i}024</h5>
                                                    <p className="text-[9px] text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Technician • Sound</p>
                                                </div>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <button className="p-2.5 rounded-xl bg-green-500/10 text-green-600 hover:bg-green-500 hover:text-white transition-all"><CheckCircle className="w-4 h-4" /></button>
                                                <button className="p-2.5 rounded-xl bg-red-500/10 text-red-600 hover:bg-red-500 hover:text-white transition-all"><XCircle className="w-4 h-4" /></button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </TacticalCard>

                            {/* Activity Heatmap Mockup */}
                            <TacticalCard title="Platform Pulse" subtitle="Hourly Engagement Volume" icon={TrendingUp}>
                                <div className="h-48 flex items-end gap-1.5 pb-2">
                                    {[30, 45, 25, 60, 80, 55, 90, 40, 70, 50, 35, 65].map((h, i) => (
                                        <div key={i} className="flex-1 bg-cyan-500/20 rounded-t-sm relative group cursor-pointer hover:bg-cyan-500 transition-all" style={{ height: `${h}%` }}>
                                            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 bg-black text-white text-[8px] font-bold px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                                                {h}k
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                <div className="flex justify-between text-[8px] font-bold text-slate-400 uppercase tracking-widest mt-4">
                                    <span>00:00</span>
                                    <span>12:00</span>
                                    <span>23:59</span>
                                </div>
                            </TacticalCard>

                            {/* Audit Matrix */}
                            <TacticalCard title="Audit Matrix" subtitle="Global Intelligence Trail" icon={Layers}>
                                <div className="space-y-4">
                                    {AUDIT_LOGS.map(log => (
                                        <div key={log.id} className="flex gap-4 group">
                                            <div className="mt-1 w-2 h-2 rounded-full bg-cyan-500/30 group-hover:bg-cyan-500 transition-colors shadow-glow-blue/20" />
                                            <div className="space-y-1 flex-1">
                                                <p className="text-[11px] leading-relaxed text-slate-700 dark:text-slate-300">
                                                    <span className="font-black text-cyan-600 dark:text-cyan-400 uppercase tracking-tighter mr-2">{log.admin}</span>
                                                    {log.action}
                                                </p>
                                                <div className="flex items-center justify-between">
                                                    <span className="text-[9px] font-mono text-slate-400 dark:text-slate-600">{log.target}</span>
                                                    <span className="text-[8px] font-bold text-slate-400">{log.time}</span>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </TacticalCard>
                        </div>
                    </div>
                )}

                {/* --- 2. FINANCE: THE TREASURY --- */}
                {activeSection === 'finance' && (
                    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700">
                         <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                            <div className="lg:col-span-3 space-y-8">
                                <TacticalCard title="Escrow Ledger" icon={CreditCard} action={<div className="flex gap-2"><button className="px-4 py-2 bg-slate-100 dark:bg-white/5 rounded-xl text-[9px] font-bold uppercase">Export CSV</button></div>}>
                                    <div className="overflow-x-auto">
                                        <table className="w-full text-left">
                                            <thead className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400 border-b border-slate-100 dark:border-white/5">
                                                <tr>
                                                    <th className="pb-4 pl-4">TX ID</th>
                                                    <th className="pb-4">Counterparty</th>
                                                    <th className="pb-4">Risk Status</th>
                                                    <th className="pb-4">Balance</th>
                                                    <th className="pb-4 text-right pr-4">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody className="text-xs">
                                                {PENDING_PAYOUTS.map(tx => (
                                                    <tr key={tx.id} className="border-b border-slate-50 dark:border-white/[0.02] hover:bg-slate-50 dark:hover:bg-white/[0.01] transition-colors group">
                                                        <td className="py-5 pl-4">
                                                            <div className="font-mono text-cyan-500 font-bold">#{tx.id}</div>
                                                            <div className="text-[9px] text-slate-400 uppercase tracking-widest">{tx.date}</div>
                                                        </td>
                                                        <td className="py-5">
                                                            <div className="font-bold text-slate-900 dark:text-white">{tx.artist}</div>
                                                            <div className="text-[10px] text-slate-500">{tx.event}</div>
                                                        </td>
                                                        <td className="py-5">
                                                            <span className={`px-2 py-1 rounded-full text-[9px] font-black uppercase tracking-tighter ${tx.status === 'Clearable' ? 'bg-green-500/10 text-green-600' : tx.status === 'Disputed' ? 'bg-red-500/10 text-red-600' : 'bg-amber-500/10 text-amber-600'}`}>
                                                                {tx.status}
                                                            </span>
                                                        </td>
                                                        <td className="py-5 font-mono font-bold text-slate-900 dark:text-white">${tx.amount}</td>
                                                        <td className="py-5 text-right pr-4">
                                                            <button className="px-4 py-2 bg-slate-900 text-white dark:bg-white dark:text-black rounded-xl text-[9px] font-black uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-all hover:scale-105 active:scale-95">Clear Funds</button>
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </TacticalCard>
                            </div>

                            <div className="lg:col-span-1 space-y-6">
                                <TacticalCard title="Platform Yield" icon={BarChart3}>
                                    <div className="space-y-6">
                                        <div className="p-5 rounded-2xl bg-cyan-500/5 border border-cyan-500/10 text-center">
                                            <p className="text-[10px] font-black uppercase text-cyan-600 dark:text-cyan-400 tracking-widest mb-1">Global Fee Ratio</p>
                                            <h3 className="text-4xl font-mono text-cyan-600 dark:text-cyan-400">{globalCommission}%</h3>
                                        </div>
                                        <div className="space-y-4">
                                            <div className="flex justify-between text-[10px] font-bold uppercase text-slate-500">
                                                <span>Commission Override</span>
                                                <span className="text-cyan-500">{globalCommission}%</span>
                                            </div>
                                            <input 
                                                type="range" 
                                                min="5" 
                                                max="30" 
                                                value={globalCommission}
                                                onChange={(e) => setGlobalCommission(parseInt(e.target.value))}
                                                className="w-full h-1.5 bg-slate-200 dark:bg-white/10 rounded-full appearance-none accent-cyan-500 cursor-pointer"
                                            />
                                            <button className="w-full py-3 bg-slate-900 text-white dark:bg-white dark:text-black rounded-xl text-[9px] font-black uppercase tracking-[0.2em] shadow-xl hover:opacity-90 transition-all">Synchronize Fees</button>
                                        </div>
                                    </div>
                                </TacticalCard>

                                <div className="bg-gradient-to-br from-mid-primary to-cyan-600 rounded-[32px] p-8 text-white shadow-glow-blue/20">
                                    <div className="flex items-center gap-3 mb-8">
                                        <ShieldCheck className="w-6 h-6" />
                                        <span className="text-[11px] font-black uppercase tracking-[0.3em]">Compliance</span>
                                    </div>
                                    <h4 className="text-xl font-tiempos mb-2">Audit Dossier</h4>
                                    <p className="text-xs text-white/70 mb-6 leading-relaxed">Auto-generate B2B compliant invoices for all active agency contracts.</p>
                                    <button className="w-full py-3 bg-white/20 hover:bg-white/30 backdrop-blur-md rounded-xl text-[10px] font-black uppercase tracking-widest border border-white/20 transition-all">Download Q4 Audit</button>
                                </div>
                            </div>
                         </div>
                    </div>
                )}

                {/* --- 3. MODERATION: THE ARCHITECT (CMS) --- */}
                {activeSection === 'moderation' && (
                    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <TacticalCard title="Spotlight Engine" icon={Layers} subtitle="Global Interface Override">
                                <div className="space-y-4">
                                    <ControlToggle 
                                        active={isMaintenanceMode} 
                                        label="Maintenance mode" 
                                        sub="Forces all users to a cinematic wait room" 
                                        onToggle={() => setIsMaintenanceMode(!isMaintenanceMode)}
                                    />
                                    <ControlToggle 
                                        active={true} 
                                        label="Live Indicators" 
                                        sub="Toggle pulsating status site-wide" 
                                    />
                                    
                                    <div className="pt-6 border-t border-slate-100 dark:border-white/5 space-y-4">
                                        <label className="text-[9px] font-bold uppercase text-slate-500 tracking-widest">Global Announcement</label>
                                        <div className="flex gap-3">
                                            <input 
                                                value={announcement}
                                                onChange={(e) => setAnnouncement(e.target.value)}
                                                className="flex-1 bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-cyan-500" 
                                            />
                                            <button className="px-5 bg-mid-primary text-white rounded-xl text-[9px] font-black uppercase tracking-widest shadow-glow-blue">Push</button>
                                        </div>
                                    </div>
                                </div>
                            </TacticalCard>

                            <TacticalCard title="Media Moderation" icon={Radio} subtitle="Review Content Submissions">
                                <div className="space-y-4">
                                    {CONTENT_QUEUE.map(content => (
                                        <div key={content.id} className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/5 hover:border-cyan-500/40 transition-all group">
                                            <div className="flex items-center gap-4 min-w-0">
                                                <div className="w-14 h-14 rounded-xl bg-slate-200 dark:bg-white/5 shrink-0 overflow-hidden relative">
                                                    <div className="absolute inset-0 flex items-center justify-center text-slate-400"><Monitor className="w-4 h-4" /></div>
                                                </div>
                                                <div className="min-w-0">
                                                    <h5 className="text-[13px] font-bold text-slate-900 dark:text-white truncate group-hover:text-cyan-500 transition-colors">{content.title}</h5>
                                                    <div className="flex items-center gap-3 text-[9px] text-slate-500 uppercase font-black tracking-tighter mt-1">
                                                        <span className="text-cyan-600 dark:text-cyan-400">{content.type}</span>
                                                        <span>{content.user}</span>
                                                        <span>{content.views} views</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="flex gap-2 shrink-0">
                                                <button className={`p-2 rounded-lg border transition-all ${content.status === 'Featured' ? 'bg-mid-accent/10 border-mid-accent text-mid-accent' : 'border-slate-200 dark:border-white/10 text-slate-400 hover:text-white hover:bg-mid-accent'}`} title="Pin to Featured">
                                                    <Flame className="w-4 h-4" />
                                                </button>
                                                <button className="p-2 rounded-lg border border-slate-200 dark:border-white/10 text-slate-400 hover:text-white hover:bg-red-500 transition-all" title="Hide Content">
                                                    <XCircle className="w-4 h-4" />
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </TacticalCard>
                        </div>
                    </div>
                )}

                {/* --- 4. OPS: FIELD OPERATIONS --- */}
                {activeSection === 'ops' && (
                    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700">
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                            <TacticalCard title="Studio Master Schedule" icon={Calendar} subtitle="Booking Availability Manager" className="lg:col-span-2">
                                <div className="grid grid-cols-7 gap-1">
                                    {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(d => (
                                        <div key={d} className="text-center py-2 text-[9px] font-black text-slate-400 uppercase">{d}</div>
                                    ))}
                                    {Array.from({ length: 31 }).map((_, i) => {
                                        const booked = i % 4 === 0;
                                        const disputed = i === 12;
                                        return (
                                            <div key={i} className={`aspect-square rounded-xl border flex flex-col items-center justify-center relative cursor-pointer transition-all ${disputed ? 'bg-red-500/10 border-red-500/30' : booked ? 'bg-cyan-500/10 border-cyan-500/30' : 'bg-slate-50 dark:bg-white/5 border-slate-200 dark:border-white/10 hover:border-cyan-500/50'}`}>
                                                <span className={`text-[10px] font-mono ${booked || disputed ? 'text-slate-900 dark:text-white font-bold' : 'text-slate-400'}`}>{i + 1}</span>
                                                {(booked || disputed) && <div className={`w-1 h-1 rounded-full mt-1 ${disputed ? 'bg-red-500' : 'bg-cyan-500'}`} />}
                                            </div>
                                        );
                                    })}
                                </div>
                            </TacticalCard>

                            <div className="space-y-6">
                                <TacticalCard title="Dispute resolution" icon={Scale} subtitle="Active Conflict Center">
                                    <div className="p-4 rounded-xl bg-red-500/5 border border-red-500/10 space-y-3">
                                        <div className="flex items-center justify-between">
                                            <span className="text-[10px] font-black text-red-500 uppercase tracking-widest">Active Conflict</span>
                                            <span className="text-[9px] font-mono text-slate-400">#DIS-9920</span>
                                        </div>
                                        <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">Client <span className="font-bold">Karim S.</span> claiming equipment failure. Artist <span className="font-bold">DJ Black</span> disputes.</p>
                                        <div className="flex gap-2 pt-2">
                                            <button className="flex-1 py-2 bg-slate-900 dark:bg-white text-white dark:text-black rounded-lg text-[9px] font-black uppercase">Refund</button>
                                            <button className="flex-1 py-2 border border-slate-200 dark:border-white/10 rounded-lg text-[9px] font-black uppercase text-slate-400">Escalate</button>
                                        </div>
                                    </div>
                                </TacticalCard>

                                <TacticalCard title="Gear Health" icon={Zap} subtitle="Studio Inventory">
                                    <div className="space-y-3">
                                        {[
                                            { item: 'Neumann U87', health: 92, status: 'Nominal' },
                                            { item: 'SSL Fusion', health: 45, status: 'Service Req' },
                                            { item: 'Monitor Pairs', health: 99, status: 'Ideal' },
                                        ].map((g, i) => (
                                            <div key={i} className="flex flex-col gap-1.5">
                                                <div className="flex justify-between text-[10px] font-bold">
                                                    <span className="text-slate-700 dark:text-slate-300">{g.item}</span>
                                                    <span className={g.health < 50 ? 'text-amber-500' : 'text-cyan-500'}>{g.health}%</span>
                                                </div>
                                                <div className="h-1 bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden">
                                                    <div className={`h-full ${g.health < 50 ? 'bg-amber-500' : 'bg-cyan-500'}`} style={{ width: `${g.health}%` }} />
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </TacticalCard>
                            </div>
                        </div>
                    </div>
                )}

                {/* --- 5. SECURITY: THE SHIELD --- */}
                {activeSection === 'security' && (
                    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700">
                        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                            <div className="lg:col-span-3">
                                <TacticalCard title="Firewall Logs" icon={ShieldAlert} subtitle="Real-time Network Traffic">
                                    <div className="space-y-1">
                                        {[
                                            { ip: '192.168.1.1', loc: 'Tunis', status: 'Blocked', reason: 'DDoS Pattern', time: '12m ago' },
                                            { ip: '172.16.2.88', loc: 'Paris', status: 'Trusted', reason: 'Admin Access', time: '24m ago' },
                                            { ip: '10.0.0.42', loc: 'Sousse', status: 'Flagged', reason: 'Geo-Anomaly', time: '1h ago' },
                                            { ip: '192.168.1.5', loc: 'Tunis', status: 'Blocked', reason: 'Brute Force', time: '2h ago' },
                                        ].map((item, i) => (
                                            <div key={i} className="flex items-center justify-between p-4 border-b border-slate-100 dark:border-white/5 last:border-0 group">
                                                <div className="flex items-center gap-6">
                                                    <div className="font-mono text-xs font-bold text-slate-900 dark:text-white">{item.ip}</div>
                                                    <div className="text-[9px] font-black uppercase text-slate-400 tracking-[0.2em]">{item.loc}</div>
                                                </div>
                                                <div className="flex items-center gap-8">
                                                    <div className="text-[10px] text-slate-500 italic opacity-0 group-hover:opacity-100 transition-opacity">{item.reason}</div>
                                                    <span className={`px-2 py-1 rounded-lg text-[9px] font-black uppercase tracking-tighter ${item.status === 'Blocked' ? 'bg-red-500/10 text-red-500' : item.status === 'Flagged' ? 'bg-amber-500/10 text-amber-500' : 'bg-green-500/10 text-green-500'}`}>{item.status}</span>
                                                    <button className="text-slate-400 hover:text-slate-900 dark:hover:text-white"><MoreHorizontal className="w-4 h-4" /></button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </TacticalCard>
                            </div>
                            
                            <div className="lg:col-span-1 space-y-6">
                                <div className={`rounded-[32px] p-8 text-white shadow-2xl transition-all duration-700 ${isLockdown ? 'bg-red-600 shadow-glow-accent' : 'bg-slate-900'}`}>
                                    <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center mb-6"><AlertTriangle className={`w-6 h-6 ${isLockdown ? 'animate-bounce' : ''}`} /></div>
                                    <h4 className="text-xl font-tiempos mb-2">Panic Button</h4>
                                    <p className="text-xs text-white/70 mb-6 leading-relaxed">Instantly put the platform into read-only mode and terminate all user sessions.</p>
                                    <button 
                                        onClick={() => setIsLockdown(!isLockdown)}
                                        className={`w-full py-4 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all ${isLockdown ? 'bg-white text-red-600' : 'bg-red-600 text-white shadow-glow-accent'}`}
                                    >
                                        {isLockdown ? 'Release Lockdown' : 'Initialize Lockdown'}
                                    </button>
                                </div>

                                <TacticalCard title="Role Overrides" icon={Lock} subtitle="Manual Credential Grants">
                                    <div className="space-y-4">
                                        <p className="text-[10px] text-slate-500 leading-relaxed">Locate user by UID to override clearance levels.</p>
                                        <div className="relative">
                                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                                            <input type="text" placeholder="UID: MM-XXXX" className="w-full pl-10 py-3 bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl text-xs focus:outline-none" />
                                        </div>
                                        <button className="w-full py-3 bg-slate-900 dark:bg-white text-white dark:text-black rounded-xl text-[9px] font-black uppercase tracking-widest">Verify & Grant</button>
                                    </div>
                                </TacticalCard>
                            </div>
                        </div>
                    </div>
                )}

                {/* --- 6. USERS: IDENTITY REGISTRY --- */}
                {activeSection === 'users' && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                            <div className="space-y-1">
                                <h3 className="text-2xl md:text-3xl font-tiempos text-slate-900 dark:text-white">Identity Registry</h3>
                                <p className="text-[10px] text-slate-500 uppercase tracking-widest">8,432 Pro Profiles detected</p>
                            </div>
                            <div className="relative w-full sm:w-auto flex gap-2">
                                <div className="relative">
                                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                                    <input type="text" placeholder="Filter IDs..." className="w-full sm:w-64 pl-10 pr-4 py-3 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl text-xs focus:outline-none" />
                                </div>
                                <button className="p-3 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl"><Download className="w-4 h-4 text-slate-400" /></button>
                            </div>
                        </div>

                        <div className="bg-white dark:bg-[#121212] border border-slate-200 dark:border-white/10 rounded-3xl overflow-hidden shadow-soft-xl">
                            <div className="overflow-x-auto">
                                <table className="w-full text-left text-xs min-w-[800px]">
                                    <thead className="bg-slate-50 dark:bg-white/5 text-slate-500 dark:text-slate-400 font-black uppercase tracking-widest border-b border-slate-200 dark:border-white/10">
                                        <tr>
                                            <th className="p-6">Subject Identity</th>
                                            <th className="p-6">Role Matrix</th>
                                            <th className="p-6">Trust Score</th>
                                            <th className="p-6">Registration</th>
                                            <th className="p-6 text-right">Ops</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100 dark:divide-white/5">
                                        {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                                            <tr key={i} className="hover:bg-slate-50 dark:hover:bg-white/[0.01] transition-colors group">
                                                <td className="p-6">
                                                    <div className="flex items-center gap-4">
                                                        <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-mid-primary via-cyan-500 to-emerald-500 p-[1px] group-hover:scale-110 transition-transform">
                                                            <div className="w-full h-full rounded-2xl bg-white dark:bg-mid-bg" />
                                                        </div>
                                                        <div>
                                                            <div className="font-bold text-[14px] text-slate-900 dark:text-white">Subject_Node_{i}024</div>
                                                            <div className="text-slate-500 text-[10px] font-mono">node_{i}@midmike.net</div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td className="p-6">
                                                    <div className="flex gap-1.5">
                                                        <span className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-[9px] font-black uppercase tracking-tighter">Client</span>
                                                        {i % 2 === 0 && <span className="px-2 py-0.5 rounded-lg bg-cyan-500/10 text-cyan-600 border border-cyan-500/20 text-[9px] font-black uppercase tracking-tighter">Artist</span>}
                                                    </div>
                                                </td>
                                                <td className="p-6">
                                                    <div className="flex items-center gap-2">
                                                        <div className={`w-1.5 h-1.5 rounded-full ${i === 5 ? 'bg-red-500' : 'bg-green-500'}`} />
                                                        <span className={`text-[10px] font-black uppercase tracking-tighter ${i === 5 ? 'text-red-500' : 'text-green-600'}`}>{i === 5 ? 'Flagged' : 'Verified'}</span>
                                                    </div>
                                                </td>
                                                <td className="p-6 font-mono text-slate-400 text-[10px]">2024.10.{i + 10}</td>
                                                <td className="p-6 text-right">
                                                    <button className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-white/10 text-slate-400 hover:text-slate-900 dark:hover:text-white transition-all"><MoreHorizontal className="w-5 h-5" /></button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                )}

                {/* --- 7. DIAGNOSTICS: SYSTEM HEALTH --- */}
                {activeSection === 'diagnostics' && (
                    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                             {[
                                { label: 'CPU Usage', val: '12.4%', icon: Cpu, color: 'text-cyan-500' },
                                { label: 'RAM Index', val: '4.2GB', icon: Database, color: 'text-mid-accent' },
                                { label: 'IO Latency', val: '14ms', icon: HardDrive, color: 'text-mid-secondary' },
                             ].map((d, i) => (
                                <div key={i} className="bg-white dark:bg-[#121212] border border-slate-200 dark:border-white/5 p-6 rounded-[24px] flex items-center gap-6">
                                    <div className={`w-12 h-12 rounded-2xl bg-slate-100 dark:bg-white/5 flex items-center justify-center ${d.color}`}>
                                        <d.icon className="w-6 h-6" />
                                    </div>
                                    <div>
                                        <p className="text-[9px] font-black uppercase text-slate-500 tracking-widest">{d.label}</p>
                                        <h3 className="text-2xl font-mono text-slate-900 dark:text-white">{d.val}</h3>
                                    </div>
                                </div>
                             ))}
                        </div>

                        <TacticalCard title="Real-time Node Monitoring" icon={Activity} subtitle="Distributed Instance Status">
                            <div className="space-y-4">
                                {[
                                    { node: 'TN-EAST-01', region: 'Tunis', status: 'Online', load: '12%', color: 'text-green-500' },
                                    { node: 'EU-CENT-02', region: 'Frankfurt', status: 'Online', load: '45%', color: 'text-green-500' },
                                    { node: 'TN-WEST-04', region: 'Sousse', status: 'Critical', load: '98%', color: 'text-red-500' },
                                ].map((n, i) => (
                                    <div key={i} className="flex items-center justify-between p-5 bg-slate-50 dark:bg-white/[0.02] border border-slate-100 dark:border-white/5 rounded-2xl">
                                        <div className="flex items-center gap-4">
                                            <div className={`w-2 h-2 rounded-full ${n.status === 'Critical' ? 'bg-red-500 animate-ping' : 'bg-green-500'}`} />
                                            <div>
                                                <div className="text-xs font-bold text-slate-900 dark:text-white">{n.node}</div>
                                                <div className="text-[9px] text-slate-400 uppercase font-mono">{n.region}</div>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-8">
                                            <div className="flex flex-col items-end">
                                                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">Load index</span>
                                                <span className={`text-xs font-mono font-bold ${n.status === 'Critical' ? 'text-red-500' : 'text-cyan-500'}`}>{n.load}</span>
                                            </div>
                                            <button className="text-[9px] font-black uppercase text-mid-primary hover:underline">Reboot Node</button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </TacticalCard>
                    </div>
                )}
            </div>
        </div>
    </div>
  );
};
