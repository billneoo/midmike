
import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { ContentItem } from '../types';
import { 
  Play, Film, Radio, Music, Flame,
  MessageCircle, Share2, Heart,
  Signal, RadioTower, Mic, Video
} from 'lucide-react';
import { OptimizedImage } from '../components/Card';

// --- Local Data & Constants ---

const TICKER_ITEMS = [
    "LIVE: DJ Black @ Warehouse Sousse",
    "NEW: 'The Analog Archive' Series",
    "TRENDING: Benjemy's Set hits 100k",
    "ON-AIR: 98.4 FM Tunis LIVE"
];

const SHORTS = [
    { 
        id: 101, 
        title: 'Backstage at Warehouse: The Raw Energy', 
        views: '12.4k', 
        likes: 2142,
        comments: 84,
        image: 'https://images.unsplash.com/photo-1514525253361-bee8718a747c?q=80&w=600&h=1000&auto=format&fit=crop',
        audio: 'Original Sound - Nour H.',
        hot: true
    },
    { 
        id: 102, 
        title: 'Lighting Check 101: Visual Masterclass', 
        views: '8.5k', 
        likes: 1205,
        comments: 42,
        image: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?q=80&w=600&h=1000&auto=format&fit=crop',
        audio: 'MidMike Studio Sessions'
    },
    { 
        id: 103, 
        title: 'Crowd Reaction: The Drop in Carthage', 
        views: '22.9k', 
        likes: 5621,
        comments: 128,
        image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=600&h=1000&auto=format&fit=crop',
        audio: 'Live Mix - DJ Black',
        hot: true
    },
    { 
        id: 104, 
        title: 'Synth Setup: The Analog Workflow', 
        views: '5.1k', 
        likes: 942,
        comments: 31,
        image: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=600&h=1000&auto=format&fit=crop',
        audio: 'Modular Explorations'
    },
];

const CATEGORIES = [
    { id: 'all', label: 'All Content', icon: LayoutGridIcon },
    { id: 'Live Set', label: 'Live Sets', icon: RadioTower },
    { id: 'Podcast', label: 'Podcasts', icon: Mic },
    { id: 'Vlog', label: 'Vlogs', icon: Film },
    { id: 'Radio', label: 'MidMike FM', icon: Signal },
];

function LayoutGridIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="7" height="7" x="3" y="3" rx="1" />
      <rect width="7" height="7" x="14" y="3" rx="1" />
      <rect width="7" height="7" x="14" y="14" rx="1" />
      <rect width="7" height="7" x="3" y="14" rx="1" />
    </svg>
  );
}

// --- Sub-Components ---

const ShortsCard: React.FC<{ item: any; onClick: () => void }> = ({ item, onClick }) => {
    const [likes, setLikes] = useState(item.likes);
    const [isLiked, setIsLiked] = useState(false);

    const handleLike = (e: React.MouseEvent) => {
        e.stopPropagation();
        setLikes((prev: number) => isLiked ? prev - 1 : prev + 1);
        setIsLiked(!isLiked);
    };

    return (
        <div 
            onClick={onClick}
            className="relative w-[260px] md:w-[380px] aspect-[9/16] rounded-[32px] overflow-hidden bg-mid-surface group cursor-pointer snap-center shrink-0 ring-1 ring-white/10 hover:ring-mid-primary/50 transition-all duration-700 shadow-2xl hover:scale-[1.02] hover:-translate-y-2"
        >
            <div className="absolute inset-0 border-[3px] border-transparent group-hover:border-mid-primary/20 rounded-[32px] transition-all duration-1000 z-10" />
            
            <OptimizedImage 
                src={item.image} 
                alt={item.title} 
                fallbackInitials={item.title} 
                containerClass="w-full h-full" 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[3s] ease-out" 
            />
            
            <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-transparent to-black/30 opacity-80" />
            
            <div className="absolute top-6 left-6 right-6 flex justify-between items-start z-20">
                <div className="flex items-center gap-2 px-3 py-1.5 bg-white/10 backdrop-blur-2xl rounded-full border border-white/20 shadow-lg">
                    <div className="w-1.5 h-1.5 bg-mid-highlight rounded-full animate-pulse shadow-[0_0_8px_rgba(219,245,5,1)]" />
                    <span className="text-[10px] font-mono font-bold text-white tracking-widest">{item.views} VIEWS</span>
                </div>
                {item.hot && (
                    <div className="px-3 py-1.5 bg-mid-accent text-white rounded-full text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5 shadow-glow-accent animate-bounce">
                        <Flame className="w-3 h-3 fill-current" /> Hot
                    </div>
                )}
            </div>

            <div className="absolute bottom-0 left-0 right-0 p-8 md:p-10 space-y-6 z-20">
                <div className="space-y-2">
                    <h4 className="text-lg md:text-2xl font-tiempos font-medium text-white leading-tight tracking-tight line-clamp-2 drop-shadow-xl">
                        {item.title}
                    </h4>
                    <div className="flex items-center gap-3 text-[10px] md:text-xs font-medium text-slate-400">
                        <div className="flex items-center gap-1.5 text-mid-primary">
                            <Music className="w-3 h-3" />
                            <span className="uppercase tracking-widest font-bold">Sound On</span>
                        </div>
                        <span className="opacity-40">•</span>
                        <span className="truncate">{item.audio}</span>
                    </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-white/10">
                    <div className="flex items-center gap-6">
                        <button onClick={handleLike} className="flex flex-col items-center gap-1.5 group/social transition-all active:scale-90">
                            <Heart className={`w-6 h-6 transition-all duration-300 ${isLiked ? 'text-pink-500 fill-pink-500' : 'text-white'}`} />
                            <span className="text-[9px] font-bold text-white">{likes}</span>
                        </button>
                        <button className="flex flex-col items-center gap-1.5 group/social">
                            <MessageCircle className="w-6 h-6 text-white group-hover:text-mid-primary transition-colors" />
                            <span className="text-[9px] font-bold text-white">{item.comments}</span>
                        </button>
                        <button className="flex flex-col items-center gap-1.5 group/social">
                            <Share2 className="w-6 h-6 text-white group-hover:text-mid-primary transition-colors" />
                            <span className="text-[9px] font-bold text-white">Share</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export const Content: React.FC = () => {
    const [content, setContent] = useState<ContentItem[]>([]);
    const [activeCategory, setActiveCategory] = useState('all');
    const [tickerIndex, setTickerIndex] = useState(0);

    useEffect(() => {
        const load = async () => {
            try {
                const data = await api.getContent();
                setContent(data);
            } catch (e) {
                console.error(e);
            }
        };
        load();

        const tickerInterval = setInterval(() => {
            setTickerIndex(prev => (prev + 1) % TICKER_ITEMS.length);
        }, 4000);

        return () => clearInterval(tickerInterval);
    }, []);

    const filteredContent = activeCategory === 'all' 
        ? content 
        : content.filter(c => c.category === activeCategory);

    return (
        <div className="animate-cinematic-fade pb-24 relative min-h-screen">
            {/* News Ticker */}
            <div className="w-full bg-slate-900 dark:bg-white/5 border-b border-slate-200 dark:border-white/5 overflow-hidden">
                <div className="max-w-7xl mx-auto flex items-center justify-between px-4 h-10">
                    <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                        <span className="text-[9px] font-black uppercase tracking-widest text-white">Broadcast</span>
                    </div>
                    <div className="flex-1 text-center">
                        <span key={tickerIndex} className="text-[10px] font-mono font-bold text-slate-300 dark:text-slate-200 animate-in slide-in-from-bottom-2 fade-in duration-500">
                            {TICKER_ITEMS[tickerIndex]}
                        </span>
                    </div>
                    <div className="text-[9px] font-bold text-slate-500 dark:text-slate-400 font-mono hidden md:block">
                        128kbps STEREO
                    </div>
                </div>
            </div>

            {/* Featured Shorts (Horizontal Scroll) */}
            <div className="pt-8 pb-12 overflow-x-auto no-scrollbar mask-gradient-x pl-4 md:pl-[calc(50vw-600px)] snap-x snap-mandatory flex gap-6">
                {SHORTS.map(item => (
                    <ShortsCard key={item.id} item={item} onClick={() => {}} />
                ))}
                <div className="w-4 shrink-0" />
            </div>

            <div className="max-w-7xl mx-auto px-4 md:px-8">
                {/* Categories */}
                <div className="flex flex-wrap gap-3 mb-10 justify-center md:justify-start">
                    {CATEGORIES.map(cat => (
                        <button
                            key={cat.id}
                            onClick={() => setActiveCategory(cat.id)}
                            className={`
                                flex items-center gap-2 px-5 py-2.5 rounded-full text-[10px] font-bold uppercase tracking-widest border transition-all duration-300
                                ${activeCategory === cat.id 
                                    ? 'bg-mid-primary border-mid-primary text-white shadow-glow-blue' 
                                    : 'bg-white dark:bg-white/5 border-slate-200 dark:border-white/10 text-slate-500 dark:text-mid-text-subtle hover:bg-slate-50 dark:hover:bg-white/10'}
                            `}
                        >
                            <cat.icon className="w-3.5 h-3.5" /> {cat.label}
                        </button>
                    ))}
                </div>

                {/* Content Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredContent.map(item => (
                        <div key={item.id} className="group relative bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-3xl overflow-hidden hover:border-mid-primary/30 transition-all duration-300 hover:shadow-xl dark:hover:shadow-glass hover:-translate-y-1 cursor-pointer">
                            <div className="aspect-video relative overflow-hidden">
                                <OptimizedImage src={item.thumbnailUrl} alt={item.title} containerClass="w-full h-full" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                                    <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 scale-90 opacity-0 group-hover:scale-100 group-hover:opacity-100 transition-all duration-300">
                                        <Play className="w-5 h-5 text-white fill-current ml-0.5" />
                                    </div>
                                </div>
                                <div className="absolute bottom-3 right-3 px-2 py-1 bg-black/80 backdrop-blur-md rounded-lg text-[9px] font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                                    {item.isLive && <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />}
                                    {item.duration}
                                </div>
                            </div>
                            <div className="p-5">
                                <div className="flex items-center gap-2 mb-2">
                                    <span className="text-[9px] font-bold text-mid-primary uppercase tracking-widest">{item.category}</span>
                                    <span className="text-[9px] text-slate-400">•</span>
                                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{item.date}</span>
                                </div>
                                <h3 className="text-lg font-bold text-slate-900 dark:text-white leading-tight mb-2 line-clamp-2 group-hover:text-mid-primary transition-colors">
                                    {item.title}
                                </h3>
                                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-mid-text-subtle">
                                    <span className="font-medium">{item.channel}</span>
                                    <span>{item.views} views</span>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};
