
import React, { useState, useMemo, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Modal } from '../components/Modal';
import { 
  User, Mail, Phone, Shield, Camera, 
  CheckCircle, ArrowLeft, Save, Zap, Award,
  Lock, Settings, ChevronDown, Bell, Laptop, 
  Smartphone, LogOut, Globe, Moon, Sun, Monitor,
  Sparkles, ArrowRight, BarChart3, Activity, 
  MapPin, Briefcase, Music, Wrench, Eye,
  ShieldCheck, Clock, FileText, AlertCircle,
  TrendingUp, Users, Heart, Mic2, DollarSign,
  Instagram, Youtube, Link as LinkIcon, RefreshCw,
  LayoutGrid, XCircle, ArrowLeftRight, Truck, Plus,
  CalendarDays, Layers, Inbox
} from 'lucide-react';
import { Role, BookingRequest, BookingStatus } from '../types';
import { api } from '../services/api';
import { BookingCard } from '../components/BookingCard';
import { useToast } from '../contexts/ToastContext';

interface ProfileProps {
  onNavigate: (route: string) => void;
}

type SettingsTab = 'security' | 'notifications' | 'preferences' | 'pro-suite';
type DashboardTab = 'profile' | 'bookings' | 'schedule';

export const Profile: React.FC<ProfileProps> = ({ onNavigate }) => {
  const { user, switchRole, updateProfile, theme, setTheme, language, setLanguage, logout } = useAuth();
  const { showToast } = useToast();
  
  // Dashboard State
  const [activeTab, setActiveTab] = useState<DashboardTab>('profile');
  const [bookings, setBookings] = useState<BookingRequest[]>([]);
  const [isLoadingBookings, setIsLoadingBookings] = useState(false);

  // Basic User Data
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
  });

  // Role Specific Data States (Mocked)
  const [artistData, setArtistData] = useState({
    stageName: user?.name || '',
    bio: 'Tunisian electronic artist exploring the intersection of analog synths and traditional rhythms.',
    city: 'Tunis',
    country: 'Tunisia',
    priceRange: '300 - 500 TND',
    cancellationPolicy: '50% deposit required. 48h cancellation notice.',
    specialties: ['Techno', 'Live Set', 'Vinyl'],
    hasEquipment: true,
    equipmentDetails: '2x CDJ-3000, DJM-900NXS2, Booth Monitors',
    audioLink: 'soundcloud.com/midmike-demo',
    socials: { instagram: '@midmike_official', youtube: '', website: '' },
    responseTime: '24h',
    availability: ['Weekends (Night)']
  });

  const [techData, setTechData] = useState({
      profession: 'Sound Engineer',
      bio: 'Experienced audio engineer specializing in large-scale festivals and live sound.',
      city: 'Sousse',
      specialties: ['Mixing', 'Mastering', 'Live Sound'],
      hasEquipment: true,
      equipmentDesc: 'Midas M32 Console, Shure Mic Kit',
      priceRange: '400 - 800 TND',
      billingMode: 'Flat Rate'
  });

  const [venueData, setVenueData] = useState({
      venueName: user?.name || '',
      venueType: 'Lounge',
      capacity: '200',
      address: 'Gammarth, Tunis',
      services: ['Sound System', 'Bar', 'VIP Area'],
      bookingMode: 'Request Quote',
      desc: 'Premium seaside lounge perfect for sunset sessions.'
  });

  const [agencyData, setAgencyData] = useState({
      agencyName: user?.name || '',
      services: ['Booking', 'Event Production'],
      operatingZones: ['Tunis', 'Hammamet'],
      desc: 'Full-service artist management and event production agency.'
  });

  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  
  // Role Switcher State
  const [showRoleSwitcher, setShowRoleSwitcher] = useState(false);

  // Settings Modal State
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState<SettingsTab>('security');
  
  // Mock Settings State
  const [twoFactor, setTwoFactor] = useState(false);
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    marketing: false,
    security: true
  });

  // Sync basic data when user changes
  useEffect(() => {
    if (user) {
        setFormData({
            name: user.name,
            email: user.email,
            phone: user.phone
        });
        if (user.role === 'Artist') setArtistData(prev => ({ ...prev, stageName: user.name }));
        if (user.role === 'Venue') setVenueData(prev => ({ ...prev, venueName: user.name }));
        if (user.role === 'Agency') setAgencyData(prev => ({ ...prev, agencyName: user.name }));
    }
  }, [user]);

  // Load Bookings on Tab Change
  useEffect(() => {
      if (activeTab === 'bookings' || activeTab === 'schedule') {
          const fetchBookings = async () => {
              setIsLoadingBookings(true);
              try {
                  const data = await api.getBookingRequests();
                  setBookings(data);
              } catch (e) {
                  console.error(e);
              } finally {
                  setIsLoadingBookings(false);
              }
          };
          fetchBookings();
      }
  }, [activeTab]);

  const handleBookingAction = async (id: string, status: BookingStatus) => {
      // Optimistic update
      setBookings(prev => prev.map(b => b.id === id ? { ...b, status } : b));
      await api.updateBookingStatus(id, status);
      showToast(status === 'confirmed' ? 'Booking Accepted!' : 'Booking Declined', status === 'confirmed' ? 'success' : 'info');
  };

  const isPro = useMemo(() => {
    return user && ['Artist', 'Technician', 'Venue', 'Agency', 'ServiceProvider'].includes(user.role);
  }, [user?.role]);

  const isOrganizer = user && (user.role === 'Venue' || user.role === 'Agency');
  const availableRoles = user?.availableRoles?.filter(r => r !== user.role) || [];

  // Role Specific Metrics Mocking
  const roleMetrics = useMemo(() => {
    if (!user) return [];
    
    // Dynamic pending count based on bookings
    const pendingCount = bookings.filter(b => b.status === 'pending').length;
    
    switch (user.role) {
      case 'Artist':
        return [
          { label: 'Sonic Impact', value: '42.8k', sub: 'Monthly Reach', icon: Music, color: 'text-mid-primary' },
          { label: 'Bookings', value: bookings.length > 0 ? bookings.length.toString() : '12', sub: `${pendingCount} Pending`, icon: CalendarDays, color: 'text-mid-accent' },
          { label: 'Profile Views', value: '1.2k', sub: 'Last 30 Days', icon: Eye, color: 'text-mid-secondary' }
        ];
      case 'Venue':
        return [
          { label: 'Floor Activity', value: '88%', sub: 'Avg. Occupancy', icon: Activity, color: 'text-mid-accent' },
          { label: 'Requests', value: pendingCount > 0 ? pendingCount.toString() : '24', sub: 'Action Required', icon: Briefcase, color: 'text-mid-primary' },
          { label: 'Amenity Rating', value: '4.9', sub: 'Guest Feedback', icon: Award, color: 'text-mid-secondary' }
        ];
      // ... (Rest same as before)
      default:
        return [
          { label: 'Nightlife Pulse', value: '18', sub: 'Events Attended', icon: Activity, color: 'text-mid-primary' },
          { label: 'Saved Artists', value: '45', sub: 'In Collection', icon: Heart, color: 'text-pink-500' },
          { label: 'Tickets', value: '6', sub: 'Active Access', icon: TicketIcon, color: 'text-mid-accent' }
        ];
    }
  }, [user?.role, bookings]);

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      updateProfile({
        name: formData.name,
        email: formData.email,
        phone: formData.phone
      });
      setIsSaving(false);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
      showToast('Profile updated successfully!', 'success');
    }, 1000);
  };

  const handleRoleSwitch = (role: Role) => {
    switchRole(role);
    setShowRoleSwitcher(false);
    setActiveTab('profile'); // Reset tab on switch
  };

  const toggleSpecialty = (tag: string) => {
      setArtistData(prev => ({
          ...prev,
          specialties: prev.specialties.includes(tag) 
            ? prev.specialties.filter(t => t !== tag) 
            : [...prev.specialties, tag]
      }));
  };

  // --- Sub-Components ---

  const Toggle = ({ checked, onChange }: { checked: boolean, onChange: () => void }) => (
    <button 
        onClick={onChange}
        className={`w-10 h-5 rounded-full relative transition-colors duration-300 ${checked ? 'bg-mid-primary' : 'bg-slate-300 dark:bg-white/10'}`}
    >
        <div className={`absolute top-1 left-1 w-3 h-3 rounded-full bg-white transition-transform duration-300 shadow-sm ${checked ? 'translate-x-5' : 'translate-x-0'}`} />
    </button>
  );

  const SettingsTabButton = ({ id, icon: Icon, label }: { id: SettingsTab, icon: any, label: string }) => (
    <button 
        onClick={() => setSettingsTab(id)}
        className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 text-sm font-medium ${settingsTab === id ? 'bg-mid-primary/10 text-mid-primary border border-mid-primary/20' : 'text-slate-500 dark:text-mid-text-muted hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white'}`}
    >
        <Icon className="w-4 h-4" />
        {label}
    </button>
  );

  const DashboardTabNav = () => (
      <div className="flex p-1 bg-slate-100 dark:bg-white/5 rounded-2xl mb-8 border border-slate-200 dark:border-white/5">
          <button 
            onClick={() => setActiveTab('profile')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${activeTab === 'profile' ? 'bg-white dark:bg-[#121212] text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-mid-text-subtle hover:text-slate-900 dark:hover:text-white'}`}
          >
              <User className="w-3.5 h-3.5" /> Edit Profile
          </button>
          <button 
            onClick={() => setActiveTab('bookings')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${activeTab === 'bookings' ? 'bg-white dark:bg-[#121212] text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-mid-text-subtle hover:text-slate-900 dark:hover:text-white'}`}
          >
              <Inbox className="w-3.5 h-3.5" /> 
              Bookings
              {bookings.filter(b => b.status === 'pending').length > 0 && (
                  <span className="ml-1 px-1.5 py-0.5 rounded-full bg-red-500 text-white text-[8px]">{bookings.filter(b => b.status === 'pending').length}</span>
              )}
          </button>
          <button 
            onClick={() => setActiveTab('schedule')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${activeTab === 'schedule' ? 'bg-white dark:bg-[#121212] text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-mid-text-subtle hover:text-slate-900 dark:hover:text-white'}`}
          >
              <CalendarDays className="w-3.5 h-3.5" /> 
              {user?.role === 'Venue' ? 'Events' : 'Schedule'}
          </button>
      </div>
  );

  const BookingsList = () => (
      <div className="space-y-6">
          <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold uppercase tracking-[0.2em] text-slate-500 dark:text-mid-text-subtle">Incoming Requests</h3>
              <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-[10px] font-bold text-green-500 uppercase tracking-widest">Live Updates</span>
              </div>
          </div>
          
          {isLoadingBookings ? (
              <div className="flex justify-center py-12"><div className="w-8 h-8 border-2 border-mid-primary/30 border-t-mid-primary rounded-full animate-spin" /></div>
          ) : bookings.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {bookings.map(booking => (
                      <BookingCard 
                        key={booking.id} 
                        booking={booking} 
                        onAccept={(id) => handleBookingAction(id, 'confirmed')} 
                        onDecline={(id) => handleBookingAction(id, 'declined')}
                      />
                  ))}
              </div>
          ) : (
              <div className="flex flex-col items-center justify-center py-16 border-2 border-dashed border-slate-200 dark:border-white/5 rounded-3xl text-center">
                  <div className="w-16 h-16 bg-slate-50 dark:bg-white/5 rounded-full flex items-center justify-center mb-4">
                      <Inbox className="w-8 h-8 text-slate-300 dark:text-mid-text-subtle" />
                  </div>
                  <h4 className="text-lg font-inter text-slate-900 dark:text-white">All Clear</h4>
                  <p className="text-xs text-slate-500 dark:text-mid-text-subtle mt-1">No pending booking requests at the moment.</p>
              </div>
          )}
      </div>
  );

  const ScheduleView = () => {
      const confirmedBookings = bookings.filter(b => b.status === 'confirmed');
      const isVenue = user?.role === 'Venue';

      return (
          <div className="space-y-6">
              <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold uppercase tracking-[0.2em] text-slate-500 dark:text-mid-text-subtle">
                      {isVenue ? 'Venue Calendar' : 'Upcoming Gigs'}
                  </h3>
              </div>

              {isLoadingBookings ? (
                  <div className="flex justify-center py-12"><div className="w-8 h-8 border-2 border-mid-primary/30 border-t-mid-primary rounded-full animate-spin" /></div>
              ) : confirmedBookings.length > 0 ? (
                  <div className="relative border-l border-slate-200 dark:border-white/10 ml-4 space-y-8 pl-8 py-2">
                      {confirmedBookings.map((evt, i) => (
                          <div key={i} className="relative group">
                              <div className="absolute -left-[39px] top-0 w-5 h-5 rounded-full bg-slate-100 dark:bg-[#191919] border-2 border-slate-300 dark:border-white/20 group-hover:border-mid-primary group-hover:bg-mid-primary/20 transition-all z-10" />
                              <div className="bg-white dark:bg-white/[0.02] border border-slate-200 dark:border-white/10 p-5 rounded-2xl shadow-sm hover:border-mid-primary/30 transition-all">
                                  <div className="flex justify-between items-start mb-2">
                                      <span className="px-2 py-1 rounded bg-slate-100 dark:bg-white/10 text-[9px] font-bold uppercase tracking-wider">{evt.date}</span>
                                      <span className="text-[10px] font-mono text-slate-400">{evt.time}</span>
                                  </div>
                                  <h4 className="text-lg font-inter font-bold text-slate-900 dark:text-white">{evt.eventName}</h4>
                                  <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5"><MapPin className="w-3 h-3" /> {evt.location}</p>
                                  {isVenue && (
                                      <div className="mt-4 pt-4 border-t border-slate-100 dark:border-white/5 flex gap-2">
                                          <button className="flex-1 py-2 text-[9px] font-bold uppercase border border-slate-200 dark:border-white/10 rounded-lg hover:bg-slate-50 dark:hover:bg-white/5">View Logistics</button>
                                          <button className="flex-1 py-2 text-[9px] font-bold uppercase border border-slate-200 dark:border-white/10 rounded-lg hover:bg-slate-50 dark:hover:bg-white/5">Manage Staff</button>
                                      </div>
                                  )}
                              </div>
                          </div>
                      ))}
                  </div>
              ) : (
                  <div className="flex flex-col items-center justify-center py-16 border-2 border-dashed border-slate-200 dark:border-white/5 rounded-3xl text-center">
                      <CalendarDays className="w-12 h-12 text-slate-300 dark:text-mid-text-subtle mb-4" />
                      <h4 className="text-lg font-inter text-slate-900 dark:text-white">Calendar Empty</h4>
                      <p className="text-xs text-slate-500 dark:text-mid-text-subtle mt-1">No upcoming confirmed events.</p>
                  </div>
              )}
          </div>
      );
  };

  if (!user) {
    return (
      <div className="h-[60vh] flex flex-col items-center justify-center text-center space-y-6">
        <div className="w-20 h-20 rounded-full bg-slate-100 dark:bg-white/5 border border-black/5 dark:border-white/10 flex items-center justify-center">
          <User className="w-10 h-10 text-slate-400 dark:text-mid-text-muted" />
        </div>
        <h2 className="text-2xl font-inter font-normal text-slate-900 dark:text-white">Identity not detected</h2>
        <button 
          onClick={() => onNavigate('home')}
          className="px-8 py-3 rounded-full bg-mid-primary text-white text-xs font-bold uppercase tracking-widest"
        >
          Return Home
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-[1400px] mx-auto py-8 animate-cinematic-fade px-4 md:px-6">
      
      {/* 1. ROLE COMMAND CENTER HERO */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-12">
        
        {/* Profile Card */}
        <div className="lg:col-span-1 premium-shiny-container rounded-[32px] overflow-hidden p-8 flex flex-col items-center text-center bg-mid-surface/40 backdrop-blur-3xl shadow-glass-deep relative">
            <div className="relative group mb-6">
              <div className="w-28 h-28 rounded-full p-1 bg-gradient-to-tr from-mid-primary via-mid-accent to-mid-secondary animate-spin-slow">
                <div className="w-full h-full rounded-full bg-[#191919] flex items-center justify-center overflow-hidden">
                  {user.avatarUrl ? (
                    <img src={user.avatarUrl} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <User className="w-10 h-10 text-mid-text-subtle" />
                  )}
                </div>
              </div>
              <button className="absolute inset-0 flex items-center justify-center bg-black/60 rounded-full opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-sm">
                <Camera className="w-5 h-5 text-white" />
              </button>
            </div>
            
            <div className="space-y-2 w-full">
                <h2 className="text-xl font-inter font-semibold text-white tracking-tight">{user.name}</h2>
                <div className="flex justify-center">
                    <div className="px-3 py-1 rounded-full bg-mid-primary/20 border border-mid-primary/30 inline-flex items-center gap-1.5">
                        <span className="text-[10px] font-bold uppercase tracking-widest text-mid-primary">{user.role}</span>
                        {isPro && <ShieldCheck className="w-3 h-3 text-mid-primary" />}
                    </div>
                </div>
                
                {/* ROLE SWITCHER BUTTON */}
                {availableRoles.length > 0 && (
                    <div className="pt-2 relative">
                        <button 
                            onClick={() => setShowRoleSwitcher(!showRoleSwitcher)}
                            className="flex items-center justify-center gap-2 px-4 py-2 mx-auto rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-slate-300 hover:text-white text-[10px] font-bold uppercase tracking-widest transition-all"
                        >
                            <ArrowLeftRight className="w-3 h-3" />
                            Switch Identity
                        </button>
                        
                        {showRoleSwitcher && (
                            <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-48 bg-[#1a1a1a] border border-white/10 rounded-xl shadow-xl overflow-hidden z-20 animate-in fade-in zoom-in-95">
                                {availableRoles.map(r => (
                                    <button
                                        key={r}
                                        onClick={() => handleRoleSwitch(r)}
                                        className="w-full text-left px-4 py-3 text-xs text-white hover:bg-white/5 flex items-center justify-between group"
                                    >
                                        <span>{r}</span>
                                        <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-mid-primary" />
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </div>

            <div className="mt-6 pt-6 border-t border-white/5 w-full space-y-2">
                {isOrganizer && (
                    <button
                        onClick={() => onNavigate('create-event')}
                        className="w-full py-3 rounded-xl bg-mid-primary hover:bg-mid-primary/90 text-white text-[10px] font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-2 shadow-glow-blue"
                    >
                        <Plus className="w-3.5 h-3.5" /> Create Event
                    </button>
                )}
                <button 
                  onClick={() => setIsSettingsOpen(true)}
                  className="w-full py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white text-[10px] font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-2"
                >
                  <Settings className="w-3.5 h-3.5" /> Account Settings
                </button>
            </div>
        </div>

        {/* Dynamic Metric Grid */}
        <div className="lg:col-span-3 grid grid-cols-1 sm:grid-cols-3 gap-4">
            {roleMetrics.map((m, i) => (
                <div key={i} className="bg-white dark:bg-white/[0.02] border border-black/5 dark:border-white/5 rounded-[32px] p-8 flex flex-col justify-between shadow-sm hover:border-mid-primary/30 transition-all group">
                    <div className="flex items-start justify-between">
                        <div className={`w-12 h-12 rounded-2xl bg-slate-50 dark:bg-white/5 flex items-center justify-center ${m.color} group-hover:scale-110 transition-transform duration-500`}>
                            <m.icon className="w-6 h-6" />
                        </div>
                        <TrendingUp className="w-4 h-4 text-green-500 opacity-40" />
                    </div>
                    <div className="mt-8">
                        <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-slate-500 dark:text-mid-text-subtle mb-1">{m.label}</p>
                        <div className="flex items-baseline gap-2">
                             <h3 className="text-4xl font-inter font-normal text-slate-900 dark:text-white">{m.value}</h3>
                             <span className="text-[10px] font-bold text-slate-400 dark:text-mid-text-muted">{m.sub}</span>
                        </div>
                    </div>
                </div>
            ))}
        </div>
      </div>

      {/* 2. MAIN WORKSTATION TABS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        
        {/* WORKSTATION CONTENT */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* --- ARTIST CONSOLE --- */}
          {user.role === 'Artist' && (
            <div className="bg-white/60 dark:bg-white/[0.02] border border-black/5 dark:border-white/5 rounded-[32px] p-8 md:p-10 backdrop-blur-3xl shadow-sm dark:shadow-glass animate-in slide-in-from-bottom-4 duration-700">
               
               {/* New Dashboard Tabs */}
               <DashboardTabNav />

               {activeTab === 'bookings' && <BookingsList />}
               {activeTab === 'schedule' && <ScheduleView />}

               {activeTab === 'profile' && (
                   <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
                       <header className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-4">
                             <div className="w-12 h-12 rounded-2xl bg-mid-primary/10 border border-mid-primary/20 flex items-center justify-center">
                               <Mic2 className="w-6 h-6 text-mid-primary" />
                             </div>
                             <div>
                               <h3 className="text-xl font-inter font-semibold text-slate-900 dark:text-white tracking-tight">Artist Profile Console</h3>
                               <p className="text-[10px] text-slate-500 dark:text-mid-text-subtle font-inter uppercase tracking-widest">Public facing data</p>
                             </div>
                          </div>
                          <button className="flex items-center gap-2 px-4 py-2 bg-mid-primary/10 hover:bg-mid-primary/20 text-mid-primary rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all">
                              <Eye className="w-3.5 h-3.5" /> Preview
                          </button>
                       </header>

                       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                                <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Stage Name</label>
                                <TextInput value={artistData.stageName} onChange={e => setArtistData({...artistData, stageName: e.target.value})} />
                            </div>
                            <div className="space-y-2">
                                <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Base Location</label>
                                <div className="flex gap-2">
                                    <TextInput value={artistData.city} onChange={e => setArtistData({...artistData, city: e.target.value})} placeholder="City" />
                                    <TextInput value={artistData.country} readOnly className="w-1/3 opacity-70 cursor-not-allowed" />
                                </div>
                            </div>
                       </div>
                       <div className="space-y-2">
                            <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Artist Bio</label>
                            <textarea 
                                className="w-full bg-slate-100 dark:bg-white/[0.03] border border-black/5 dark:border-white/10 rounded-2xl p-4 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-mid-primary/50 transition-all resize-none h-28"
                                value={artistData.bio}
                                onChange={e => setArtistData({...artistData, bio: e.target.value})}
                            />
                       </div>
                       <div className="space-y-3">
                            <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Artistic Specialties</label>
                            <div className="flex flex-wrap gap-2">
                                {artistData.specialties.map(tag => (
                                    <div key={tag} className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-[10px] font-bold text-slate-600 dark:text-white flex items-center gap-2 group">
                                        {tag} <button onClick={() => toggleSpecialty(tag)}><XCircle className="w-3 h-3 text-slate-400 group-hover:text-red-500" /></button>
                                    </div>
                                ))}
                                <button className="px-3 py-1.5 rounded-xl border border-dashed border-slate-300 dark:border-white/20 text-[10px] font-bold text-slate-400 hover:text-mid-primary transition-all">+ Add Tag</button>
                            </div>
                       </div>
                       <div className="p-6 bg-slate-50 dark:bg-black/20 rounded-2xl border border-black/5 dark:border-white/5 space-y-4">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <Zap className="w-4 h-4 text-mid-accent" />
                                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-700 dark:text-white">Own Equipment?</span>
                                </div>
                                <Toggle checked={artistData.hasEquipment} onChange={() => setArtistData({...artistData, hasEquipment: !artistData.hasEquipment})} />
                            </div>
                            {artistData.hasEquipment && (
                                <textarea 
                                    className="w-full bg-white dark:bg-white/[0.05] border border-slate-200 dark:border-white/10 rounded-xl p-3 text-xs text-slate-600 dark:text-slate-300 focus:outline-none"
                                    value={artistData.equipmentDetails}
                                    onChange={e => setArtistData({...artistData, equipmentDetails: e.target.value})}
                                    placeholder="List your gear..."
                                />
                            )}
                       </div>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                                <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Base Rate Range</label>
                                <div className="relative">
                                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                                    <TextInput className="pl-10" value={artistData.priceRange} onChange={e => setArtistData({...artistData, priceRange: e.target.value})} />
                                </div>
                            </div>
                       </div>
                       <div className="mt-12 flex justify-end">
                           <button onClick={handleSave} disabled={isSaving} className="cta-shimmer flex items-center gap-3 px-10 py-3.5 rounded-2xl bg-mid-primary text-white text-[10px] font-bold uppercase tracking-[0.2em] shadow-glow-blue disabled:opacity-50">
                               {isSaving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><Save className="w-4 h-4" /> Save Profile</>}
                           </button>
                       </div>
                   </div>
               )}
            </div>
          )}

          {/* --- TECHNICIAN CONSOLE (Also used for Service Provider) --- */}
          {(user.role === 'Technician' || user.role === 'ServiceProvider') && (
            <div className="bg-white/60 dark:bg-white/[0.02] border border-black/5 dark:border-white/5 rounded-[32px] p-8 md:p-10 backdrop-blur-3xl shadow-sm dark:shadow-glass animate-in slide-in-from-bottom-4 duration-700">
               <DashboardTabNav />
               
               {activeTab === 'bookings' && <BookingsList />}
               {activeTab === 'schedule' && <ScheduleView />}

               {activeTab === 'profile' && (
                   <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
                        <header className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-2xl bg-mid-accent/10 border border-mid-accent/20 flex items-center justify-center">
                                {user.role === 'Technician' ? <Wrench className="w-6 h-6 text-mid-accent" /> : <Truck className="w-6 h-6 text-mid-accent" />}
                                </div>
                                <div>
                                <h3 className="text-xl font-inter font-semibold text-slate-900 dark:text-white tracking-tight">{user.role} Console</h3>
                                <p className="text-[10px] text-slate-500 dark:text-mid-text-subtle font-inter uppercase tracking-widest">Technical details & Rates</p>
                                </div>
                            </div>
                            <button className="flex items-center gap-2 px-4 py-2 bg-mid-accent/10 hover:bg-mid-accent/20 text-mid-accent rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all">
                                <Eye className="w-3.5 h-3.5" /> Preview
                            </button>
                        </header>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Profession Title</label>
                                    <TextInput value={techData.profession} onChange={e => setTechData({...techData, profession: e.target.value})} />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">City Base</label>
                                    <TextInput value={techData.city} onChange={e => setTechData({...techData, city: e.target.value})} />
                                </div>
                        </div>
                        <div className="space-y-2">
                                <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Technical Bio</label>
                                <textarea className="w-full bg-slate-100 dark:bg-white/[0.03] border border-black/5 dark:border-white/10 rounded-2xl p-4 text-sm text-slate-900 dark:text-white focus:outline-none h-24 resize-none" value={techData.bio} onChange={e => setTechData({...techData, bio: e.target.value})} />
                        </div>
                        <div className="p-6 bg-slate-50 dark:bg-black/20 rounded-2xl border border-black/5 dark:border-white/5 space-y-4">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <Zap className="w-4 h-4 text-mid-accent" />
                                        <span className="text-[10px] font-bold uppercase tracking-widest text-slate-700 dark:text-white">Equipment Available</span>
                                    </div>
                                    <Toggle checked={techData.hasEquipment} onChange={() => setTechData({...techData, hasEquipment: !techData.hasEquipment})} />
                                </div>
                                {techData.hasEquipment && (
                                    <textarea className="w-full bg-white dark:bg-white/[0.05] border border-slate-200 dark:border-white/10 rounded-xl p-3 text-xs text-slate-600 dark:text-slate-300 focus:outline-none" value={techData.equipmentDesc} onChange={e => setTechData({...techData, equipmentDesc: e.target.value})} placeholder="List your technical gear..." />
                                )}
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Rate Range</label>
                                    <TextInput value={techData.priceRange} onChange={e => setTechData({...techData, priceRange: e.target.value})} />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Billing Mode</label>
                                    <select className="w-full bg-slate-100 dark:bg-white/[0.03] border border-black/5 dark:border-white/10 rounded-2xl p-4 text-sm text-slate-900 dark:text-white focus:outline-none appearance-none" value={techData.billingMode} onChange={e => setTechData({...techData, billingMode: e.target.value})}>
                                        <option>Flat Rate</option>
                                        <option>Hourly</option>
                                        <option>% Fee</option>
                                    </select>
                                </div>
                        </div>
                        <div className="mt-12 flex justify-end">
                            <button onClick={handleSave} disabled={isSaving} className="cta-shimmer flex items-center gap-3 px-10 py-3.5 rounded-2xl bg-mid-accent text-white text-[10px] font-bold uppercase tracking-[0.2em] shadow-glow-accent disabled:opacity-50">
                                {isSaving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><Save className="w-4 h-4" /> Save Details</>}
                            </button>
                        </div>
                   </div>
               )}
            </div>
          )}

          {/* --- VENUE CONSOLE --- */}
          {user.role === 'Venue' && (
            <div className="bg-white/60 dark:bg-white/[0.02] border border-black/5 dark:border-white/5 rounded-[32px] p-8 md:p-10 backdrop-blur-3xl shadow-sm dark:shadow-glass animate-in slide-in-from-bottom-4 duration-700">
               <DashboardTabNav />
               
               {activeTab === 'bookings' && <BookingsList />}
               {activeTab === 'schedule' && <ScheduleView />}

               {activeTab === 'profile' && (
                   <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
                        <header className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-2xl bg-mid-secondary/10 border border-mid-secondary/20 flex items-center justify-center">
                                <MapPin className="w-6 h-6 text-mid-secondary" />
                                </div>
                                <div>
                                <h3 className="text-xl font-inter font-semibold text-slate-900 dark:text-white tracking-tight">Venue Console</h3>
                                <p className="text-[10px] text-slate-500 dark:text-mid-text-subtle font-inter uppercase tracking-widest">Space & Logistics</p>
                                </div>
                            </div>
                            <button className="flex items-center gap-2 px-4 py-2 bg-mid-secondary/10 hover:bg-mid-secondary/20 text-mid-secondary rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all">
                                <Eye className="w-3.5 h-3.5" /> Preview
                            </button>
                        </header>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Venue Name</label>
                                    <TextInput value={venueData.venueName} onChange={e => setVenueData({...venueData, venueName: e.target.value})} />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Venue Type</label>
                                    <select className="w-full bg-slate-100 dark:bg-white/[0.03] border border-black/5 dark:border-white/10 rounded-2xl p-4 text-sm text-slate-900 dark:text-white focus:outline-none appearance-none" value={venueData.venueType} onChange={e => setVenueData({...venueData, venueType: e.target.value})}>
                                        <option>Lounge</option><option>Club</option><option>Hotel</option><option>Bar</option>
                                    </select>
                                </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Capacity (Pax)</label>
                                    <TextInput value={venueData.capacity} onChange={e => setVenueData({...venueData, capacity: e.target.value})} />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Booking Mode</label>
                                    <TextInput value={venueData.bookingMode} onChange={e => setVenueData({...venueData, bookingMode: e.target.value})} />
                                </div>
                        </div>
                        <div className="space-y-2">
                                <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Address</label>
                                <TextInput value={venueData.address} onChange={e => setVenueData({...venueData, address: e.target.value})} />
                        </div>
                        <div className="space-y-2">
                                <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Description</label>
                                <textarea className="w-full bg-slate-100 dark:bg-white/[0.03] border border-black/5 dark:border-white/10 rounded-2xl p-4 text-sm text-slate-900 dark:text-white focus:outline-none h-24 resize-none" value={venueData.desc} onChange={e => setVenueData({...venueData, desc: e.target.value})} />
                        </div>
                        <div className="mt-12 flex justify-end">
                            <button onClick={handleSave} disabled={isSaving} className="cta-shimmer flex items-center gap-3 px-10 py-3.5 rounded-2xl bg-mid-secondary text-white text-[10px] font-bold uppercase tracking-[0.2em] shadow-glow-secondary disabled:opacity-50">
                                {isSaving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><Save className="w-4 h-4" /> Update Venue</>}
                            </button>
                        </div>
                   </div>
               )}
            </div>
          )}

          {/* --- AGENCY CONSOLE --- */}
          {user.role === 'Agency' && (
            <div className="bg-white/60 dark:bg-white/[0.02] border border-black/5 dark:border-white/5 rounded-[32px] p-8 md:p-10 backdrop-blur-3xl shadow-sm dark:shadow-glass animate-in slide-in-from-bottom-4 duration-700">
               <DashboardTabNav />
               
               {activeTab === 'bookings' && <BookingsList />}
               {activeTab === 'schedule' && <ScheduleView />}

               {activeTab === 'profile' && (
                   <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
                        <header className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-2xl bg-mid-primary/10 border border-mid-primary/20 flex items-center justify-center">
                                <Briefcase className="w-6 h-6 text-mid-primary" />
                                </div>
                                <div>
                                <h3 className="text-xl font-inter font-semibold text-slate-900 dark:text-white tracking-tight">Agency Console</h3>
                                <p className="text-[10px] text-slate-500 dark:text-mid-text-subtle font-inter uppercase tracking-widest">Operations & Services</p>
                                </div>
                            </div>
                            <button className="flex items-center gap-2 px-4 py-2 bg-mid-primary/10 hover:bg-mid-primary/20 text-mid-primary rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all">
                                <Eye className="w-3.5 h-3.5" /> Preview
                            </button>
                        </header>

                        <div className="space-y-2">
                                <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Agency Name</label>
                                <TextInput value={agencyData.agencyName} onChange={e => setAgencyData({...agencyData, agencyName: e.target.value})} />
                        </div>
                        <div className="space-y-2">
                                <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Overview</label>
                                <textarea className="w-full bg-slate-100 dark:bg-white/[0.03] border border-black/5 dark:border-white/10 rounded-2xl p-4 text-sm text-slate-900 dark:text-white focus:outline-none h-24 resize-none" value={agencyData.desc} onChange={e => setAgencyData({...agencyData, desc: e.target.value})} />
                        </div>
                        <div className="space-y-2">
                                <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Operating Zones</label>
                                <TextInput value={agencyData.operatingZones.join(', ')} onChange={e => setAgencyData({...agencyData, operatingZones: e.target.value.split(', ')})} placeholder="Tunis, Sousse..." />
                        </div>
                        <div className="mt-12 flex justify-end">
                            <button onClick={handleSave} disabled={isSaving} className="cta-shimmer flex items-center gap-3 px-10 py-3.5 rounded-2xl bg-mid-primary text-white text-[10px] font-bold uppercase tracking-[0.2em] shadow-glow-blue disabled:opacity-50">
                                {isSaving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><Save className="w-4 h-4" /> Update Agency</>}
                            </button>
                        </div>
                   </div>
               )}
            </div>
          )}

          {/* Standard Credentials Section (Visible only when editing profile or as Client) */}
          {(activeTab === 'profile' || user.role === 'Client') && (
            <div className="bg-white/60 dark:bg-white/[0.02] border border-black/5 dark:border-white/5 rounded-[32px] p-8 md:p-10 backdrop-blur-3xl shadow-sm dark:shadow-glass">
                <header className="flex items-center justify-between mb-10">
                <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-mid-accent/10 border border-mid-accent/20 flex items-center justify-center">
                    <Shield className="w-5 h-5 text-mid-accent" />
                    </div>
                    <div>
                    <h3 className="text-xl font-inter font-semibold text-slate-900 dark:text-white tracking-tight">Core Credentials</h3>
                    <p className="text-[10px] text-slate-500 dark:text-mid-text-subtle font-inter uppercase tracking-widest">Platform security & access</p>
                    </div>
                </div>
                </header>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-2">
                    <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Legal Name</label>
                    <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-muted" />
                    <input 
                        type="text" 
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        className="w-full bg-slate-100 dark:bg-white/[0.03] border border-black/5 dark:border-white/10 rounded-2xl p-4 pl-12 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-mid-primary/50 transition-all"
                    />
                    </div>
                </div>

                <div className="space-y-2">
                    <label className="text-[9px] font-bold text-slate-500 dark:text-mid-text-subtle uppercase tracking-widest">Email Address</label>
                    <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-mid-text-muted" />
                    <input 
                        type="email" 
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        className="w-full bg-slate-100 dark:bg-white/[0.03] border border-black/5 dark:border-white/10 rounded-2xl p-4 pl-12 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-mid-primary/50 transition-all"
                    />
                    </div>
                </div>
                </div>

                <div className="mt-12 flex items-center justify-end gap-4">
                <button 
                    onClick={handleSave}
                    disabled={isSaving}
                    className="flex items-center gap-3 px-8 py-3.5 rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-black text-[10px] font-bold uppercase tracking-[0.2em] transition-all active:scale-95 disabled:opacity-50"
                >
                    {isSaving ? 'Processing...' : 'Update Account'}
                </button>
                </div>
            </div>
          )}
        </div>

        {/* SIDEBAR WORKSTATION TOOLS */}
        <div className="lg:col-span-1 space-y-6">
            <div className="bg-white dark:bg-[#121212]/60 border border-black/5 dark:border-white/5 rounded-[32px] p-8 space-y-6 shadow-sm">
                <div className="flex items-center gap-3">
                    <Zap className="w-5 h-5 text-mid-highlight" />
                    <h4 className="text-sm font-bold uppercase tracking-widest text-slate-900 dark:text-white">Active Sessions</h4>
                </div>
                <div className="space-y-4">
                    {[
                        { device: 'MacBook Pro', loc: 'Tunis', active: true, icon: Laptop },
                        { device: 'iPhone 15 Pro', loc: 'Sousse', active: false, icon: Smartphone }
                    ].map((s, i) => (
                        <div key={i} className="flex items-center gap-4 p-4 rounded-2xl bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/5">
                             <div className="w-10 h-10 rounded-full bg-white dark:bg-white/5 flex items-center justify-center">
                                 <s.icon className="w-5 h-5 text-slate-400" />
                             </div>
                             <div className="flex-1 min-w-0">
                                 <h5 className="text-xs font-bold truncate text-slate-900 dark:text-white">{s.device}</h5>
                                 <p className="text-[9px] text-slate-500 uppercase tracking-wider">{s.loc} • {s.active ? 'Active Now' : '2h ago'}</p>
                             </div>
                             {s.active && <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse shadow-glow-secondary" />}
                        </div>
                    ))}
                </div>
                <button className="w-full py-3 rounded-xl border border-dashed border-slate-300 dark:border-white/10 text-[10px] font-bold uppercase tracking-widest text-slate-500 hover:text-red-500 transition-all">Sign out of all devices</button>
            </div>

            <div className="bg-slate-900 dark:bg-mid-primary/10 border border-white/5 rounded-[32px] p-8 space-y-6 shadow-xl">
                 <div className="flex items-center gap-3 text-white dark:text-mid-primary">
                    <LogOut className="w-5 h-5" />
                    <h4 className="text-sm font-bold uppercase tracking-widest">Platform Exit</h4>
                </div>
                <p className="text-[11px] text-slate-400 dark:text-mid-text-subtle leading-relaxed">Closing your session will clear local tactical data and temporary transmission buffers.</p>
                <button 
                  onClick={logout}
                  className="w-full py-4 bg-red-600 hover:bg-red-500 text-white rounded-2xl text-[10px] font-bold uppercase tracking-[0.3em] transition-all shadow-glow-accent/20"
                >
                    Initialize Sign Out
                </button>
            </div>
        </div>
      </div>

      {/* Account Settings Modal (Existing) */}
      <Modal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
        title="Identity Console"
      >
        <div className="flex flex-col md:flex-row min-h-[500px] text-slate-900 dark:text-white">
            {/* Modal Sidebar */}
            <div className="w-full md:w-64 border-b md:border-b-0 md:border-r border-black/5 dark:border-white/5 p-6 flex flex-col gap-2 bg-slate-50/50 dark:bg-black/20">
                <SettingsTabButton id="security" icon={Lock} label="Access & Security" />
                <SettingsTabButton id="notifications" icon={Bell} label="Transmission Alerts" />
                <SettingsTabButton id="preferences" icon={Settings} label="System Context" />
                {isPro && <SettingsTabButton id="pro-suite" icon={Briefcase} label="Professional Suite" />}
                
                <div className="mt-auto pt-6 border-t border-black/5 dark:border-white/5">
                    <button 
                        onClick={() => { setIsSettingsOpen(false); logout(); }}
                        className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[11px] font-bold uppercase tracking-widest text-red-500 hover:bg-red-500/10 transition-colors"
                    >
                        <LogOut className="w-4 h-4" /> Sign Out
                    </button>
                </div>
            </div>

            {/* Modal Content */}
            <div className="flex-1 p-8 space-y-10 overflow-y-auto max-h-[80vh] no-scrollbar">
                
                {settingsTab === 'security' && (
                    <div className="space-y-8 animate-cinematic-fade">
                        <header className="space-y-1">
                            <h3 className="text-xl font-inter font-semibold text-slate-900 dark:text-white">Access & Security</h3>
                            <p className="text-[10px] text-slate-500 uppercase tracking-widest">Protect your digital footprint</p>
                        </header>
                        
                        <div className="space-y-4">
                            <div className="p-6 rounded-2xl bg-slate-100 dark:bg-white/[0.03] border border-black/5 dark:border-white/5 flex items-center justify-between group hover:border-mid-primary/30 transition-all">
                                <div className="space-y-1">
                                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">Two-Factor Auth</h4>
                                    <p className="text-[11px] text-slate-500 dark:text-mid-text-subtle">Add an extra layer of biometric verification.</p>
                                </div>
                                <Toggle checked={twoFactor} onChange={() => setTwoFactor(!twoFactor)} />
                            </div>
                            
                            <div className="p-6 rounded-2xl bg-slate-100 dark:bg-white/[0.03] border border-black/5 dark:border-white/5 flex items-center justify-between group hover:border-mid-accent/30 transition-all">
                                <div className="space-y-1">
                                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">Password Cryptography</h4>
                                    <p className="text-[11px] text-slate-500 dark:text-mid-text-subtle">Last cycled 45 days ago. High strength detected.</p>
                                </div>
                                <button className="text-[9px] font-black uppercase tracking-widest text-mid-primary hover:underline">Cycle Key</button>
                            </div>
                        </div>
                    </div>
                )}

                {settingsTab === 'notifications' && (
                    <div className="space-y-8 animate-cinematic-fade">
                        <header className="space-y-1">
                            <h3 className="text-xl font-inter font-semibold text-slate-900 dark:text-white">Transmission Alerts</h3>
                            <p className="text-[10px] text-slate-500 uppercase tracking-widest">Define your connectivity frequency</p>
                        </header>

                        <div className="space-y-2 divide-y divide-black/5 dark:divide-white/5 border-t border-b border-black/5 dark:border-white/5">
                            <div className="py-6 flex items-center justify-between">
                                <div>
                                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">Booking Matrix Updates</h4>
                                    <p className="text-[11px] text-slate-500 dark:text-mid-text-subtle">Real-time pings for inquiries and confirmations.</p>
                                </div>
                                <Toggle checked={notifications.push} onChange={() => setNotifications({...notifications, push: !notifications.push})} />
                            </div>
                            <div className="py-6 flex items-center justify-between">
                                <div>
                                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">Direct Insight Newsletter</h4>
                                    <p className="text-[11px] text-slate-500 dark:text-mid-text-subtle">Weekly digest of industry movement and trends.</p>
                                </div>
                                <Toggle checked={notifications.marketing} onChange={() => setNotifications({...notifications, marketing: !notifications.marketing})} />
                            </div>
                        </div>
                    </div>
                )}

                {settingsTab === 'preferences' && (
                     <div className="space-y-8 animate-cinematic-fade">
                        <header className="space-y-1">
                            <h3 className="text-xl font-inter font-semibold text-slate-900 dark:text-white">System Context</h3>
                            <p className="text-[10px] text-slate-500 uppercase tracking-widest">Environmental & interface parameters</p>
                        </header>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="p-6 rounded-2xl bg-slate-100 dark:bg-white/[0.03] border border-black/5 dark:border-white/5 space-y-4">
                                <div className="flex items-center gap-3">
                                    <Moon className="w-5 h-5 text-slate-400" />
                                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">Visual Interface</h4>
                                </div>
                                <div className="flex bg-white dark:bg-black/30 rounded-xl p-1 border border-black/5 dark:border-white/10 shadow-inner">
                                    <button 
                                        onClick={() => setTheme('light')}
                                        className={`flex-1 py-2.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${theme === 'light' ? 'bg-white shadow-lg text-slate-900' : 'text-slate-500 dark:text-mid-text-subtle'}`}
                                    >
                                        Light
                                    </button>
                                    <button 
                                        onClick={() => setTheme('dark')}
                                        className={`flex-1 py-2.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${theme === 'dark' ? 'bg-mid-bg shadow-lg text-white' : 'text-slate-500 dark:text-mid-text-subtle'}`}
                                    >
                                        Dark
                                    </button>
                                </div>
                            </div>

                            <div className="p-6 rounded-2xl bg-slate-100 dark:bg-white/[0.03] border border-black/5 dark:border-white/5 space-y-4">
                                <div className="flex items-center gap-3">
                                    <Globe className="w-5 h-5 text-slate-400" />
                                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">Regional Protocol</h4>
                                </div>
                                 <div className="flex bg-white dark:bg-black/30 rounded-xl p-1 border border-black/5 dark:border-white/10 shadow-inner overflow-x-auto no-scrollbar">
                                    {(['EN', 'FR', 'AR'] as const).map(lang => (
                                        <button 
                                            key={lang}
                                            onClick={() => setLanguage(lang)}
                                            className={`flex-1 min-w-[50px] py-2.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${language === lang ? 'bg-mid-primary text-white shadow-lg' : 'text-slate-500 dark:text-mid-text-subtle'}`}
                                        >
                                            {lang}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {settingsTab === 'pro-suite' && (
                    <div className="space-y-8 animate-cinematic-fade">
                        <header className="space-y-1">
                            <h3 className="text-xl font-inter font-semibold text-slate-900 dark:text-white">Professional Suite</h3>
                            <p className="text-[10px] text-slate-500 uppercase tracking-widest">Business logic & operational terms</p>
                        </header>

                        <div className="space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Industry Payout Method</label>
                                    <select className="w-full bg-slate-100 dark:bg-white/[0.03] border border-black/5 dark:border-white/10 rounded-2xl p-4 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-mid-primary/50 appearance-none">
                                        <option>Bank Transfer (SEPA/Local)</option>
                                        <option>Escrow Integration</option>
                                        <option>Direct Digital Payout</option>
                                    </select>
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Legal Status</label>
                                    <TextInput value="Self-Employed / Patent" readOnly />
                                </div>
                            </div>
                            
                            <div className="p-6 rounded-2xl bg-mid-accent/5 border border-mid-accent/20 flex gap-4">
                                <AlertCircle className="w-5 h-5 text-mid-accent shrink-0" />
                                <div className="space-y-1">
                                    <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Cancellation Policy</h4>
                                    <p className="text-[10px] text-slate-600 dark:text-mid-text-subtle leading-relaxed">"Bookings cancelled within 48h of the event are subject to a 50% non-refundable operational fee."</p>
                                    <button className="mt-2 text-[9px] font-bold text-mid-accent hover:underline uppercase tracking-widest">Edit Terms</button>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

            </div>
        </div>
      </Modal>
    </div>
  );
};

// --- Local Helpers ---

function TicketIcon(props: any) {
    return (
        <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/><path d="M13 5v2"/><path d="M13 17v2"/><path d="M13 11v2"/></svg>
    )
}

const TextInput = ({ className, ...props }: React.InputHTMLAttributes<HTMLInputElement>) => (
  <input 
    className={`w-full bg-slate-100 dark:bg-white/[0.03] border border-black/5 dark:border-white/10 rounded-2xl px-4 py-3 text-sm text-slate-900 dark:text-white focus:border-mid-primary/50 focus:outline-none transition-all placeholder-slate-400 dark:placeholder-white/20 ${className || ''}`}
    {...props}
  />
);
