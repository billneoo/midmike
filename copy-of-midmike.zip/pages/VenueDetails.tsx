
import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { BaseEntity, Review } from '../types';
import { 
  ArrowLeft, MapPin, Star, ShieldCheck, ShoppingBag, 
  Users, Music, Coffee, Check, LayoutGrid, Calendar, Plus, User
} from 'lucide-react';
import { OptimizedImage } from '../components/Card';
import { useBasket } from '../contexts/BasketContext';
import { useAuth } from '../contexts/AuthContext';
import { Modal } from '../components/Modal';

interface VenueDetailsProps {
  id?: string;
  onNavigate: (route: string) => void;
  onBack?: () => void;
}

export const VenueDetails: React.FC<VenueDetailsProps> = ({ id, onNavigate, onBack }) => {
  const [venue, setVenue] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // Review State
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [reviewText, setReviewText] = useState('');
  const [reviewRating, setReviewRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);

  const { addToBasket } = useBasket();
  const { user, setAuthModalOpen } = useAuth();

  useEffect(() => {
    const load = async () => {
      try {
        const data = await api.getVenueDetails(id || 'v1');
        setVenue(data);
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, [id]);

  const handleBooking = () => {
      if (venue) {
          addToBasket(venue);
          alert(`${venue.title} added to your basket!`);
      }
  };

  const handleSubmitReview = () => {
      if (!reviewRating) return alert('Please select a rating');
      if (!venue) return;

      const newReview: Review = {
          id: Date.now(),
          type: 'manual',
          name: user?.name || 'Guest User',
          rating: reviewRating,
          date: 'Just now',
          quote: reviewText,
          photo: user?.avatarUrl || undefined
      };

      setVenue(prev => prev ? {
          ...prev,
          reviews: [newReview, ...(prev.reviews || [])]
      } : null);

      setIsReviewModalOpen(false);
      setReviewText('');
      setReviewRating(0);
  };

  if (isLoading || !venue) {
    return (
      <div className="h-[60vh] w-full flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-mid-secondary/20 border-t-mid-secondary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="animate-cinematic-fade pb-24 pt-6 md:pt-8">
      <div className="max-w-7xl mx-auto px-4 md:px-8 mb-12">
          <button 
                onClick={onBack ? onBack : () => onNavigate('venues')}
                className="group flex items-center gap-3 px-5 py-2.5 rounded-full border border-slate-200 dark:border-white/10 bg-white/50 dark:bg-white/5 backdrop-blur-md hover:border-mid-secondary/50 hover:bg-mid-secondary/5 transition-all duration-300 w-fit mb-8"
            >
                <ArrowLeft className="w-4 h-4 text-slate-500 dark:text-slate-400 group-hover:text-mid-secondary transition-colors" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 group-hover:text-mid-secondary transition-colors">Back</span>
          </button>

          <div className="flex flex-col md:flex-row gap-8 md:gap-12 items-start md:items-end">
                <div className="w-full md:w-[500px] shrink-0">
                    <div className="aspect-video md:aspect-[16/10] rounded-[32px] overflow-hidden shadow-2xl relative group bg-mid-surface">
                        <OptimizedImage 
                            src={venue.imageUrl} 
                            alt={venue.title} 
                            containerClass="w-full h-full"
                            className="w-full h-full object-cover transition-transform duration-[20s] group-hover:scale-105"
                        />
                        {venue.verified && (
                            <div className="absolute top-4 right-4 bg-mid-secondary/90 backdrop-blur-md text-white px-3 py-1.5 rounded-full shadow-lg z-10 flex items-center gap-1.5 border border-white/20">
                                <ShieldCheck className="w-3.5 h-3.5" />
                                <span className="text-[9px] font-bold uppercase tracking-widest">Verified</span>
                            </div>
                        )}
                    </div>
                </div>

                <div className="flex-1 space-y-6 pb-2 w-full">
                    <div className="space-y-4">
                        <div className="flex flex-wrap items-center gap-3">
                            <div className="px-4 py-1.5 bg-mid-secondary/10 border border-mid-secondary/20 text-mid-secondary text-[10px] font-bold uppercase tracking-widest rounded-full">
                                {venue.venueType}
                            </div>
                            <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-white/5 px-3 py-1.5 rounded-full border border-slate-200 dark:border-white/10">
                                <Star className="w-3.5 h-3.5 text-mid-highlight fill-current" />
                                <span className="text-xs font-bold text-slate-900 dark:text-white">{venue.rating}</span>
                                <span className="text-[10px] text-slate-500">({venue.reviews?.length || 0} reviews)</span>
                            </div>
                        </div>

                        <h1 className="text-4xl md:text-6xl font-inter font-semibold text-slate-900 dark:text-white leading-[0.9] tracking-tighter">
                            {venue.title}
                        </h1>

                        <div className="flex flex-wrap items-center gap-6 text-sm text-slate-500 dark:text-mid-text-subtle">
                            <div className="flex items-center gap-2">
                                <MapPin className="w-4 h-4" />
                                <span>{venue.location}</span>
                            </div>
                            <div className="w-1 h-1 bg-slate-300 dark:bg-white/20 rounded-full" />
                            <div className="flex items-center gap-2">
                                <Users className="w-4 h-4" />
                                <span>{venue.capacity} Pax</span>
                            </div>
                        </div>
                    </div>
                </div>
          </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12">
          <div className="lg:col-span-8 space-y-12">
              <div className="space-y-6">
                  <h3 className="text-sm font-bold uppercase tracking-[0.2em] text-slate-400">The Space</h3>
                  <p className="text-lg font-light text-slate-700 dark:text-slate-300 leading-relaxed">
                      {venue.description || "A premium venue space tailored for exclusive events and high-end productions."}
                  </p>
                  
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4">
                      {venue.venueServices?.map((service: string) => (
                          <div key={service} className="p-4 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-white dark:bg-white/10 flex items-center justify-center">
                                  <Check className="w-4 h-4 text-mid-secondary" />
                              </div>
                              <span className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-white">{service}</span>
                          </div>
                      ))}
                  </div>
              </div>

              <div className="space-y-6">
                  <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold uppercase tracking-[0.2em] text-slate-400">Gallery</h3>
                      <div className="flex gap-2">
                          <button className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/5"><LayoutGrid className="w-4 h-4" /></button>
                      </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 h-80">
                      {venue.media?.map((m: any, i: number) => (
                          <div key={i} className="relative rounded-2xl overflow-hidden group cursor-pointer h-full">
                              <OptimizedImage src={m.url} alt="" containerClass="w-full h-full" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                          </div>
                      ))}
                  </div>
              </div>

              {/* Review Engine */}
              <div className="space-y-8 pt-8 border-t border-slate-200 dark:border-white/10">
                  <div className="flex items-center justify-between">
                      <div className="space-y-1">
                          <h3 className="text-2xl font-tiempos font-normal text-slate-900 dark:text-white">Visitor Reviews</h3>
                          <div className="flex items-center gap-2">
                              <div className="flex text-mid-highlight">
                                  {[1, 2, 3, 4, 5].map(i => <Star key={i} className={`w-4 h-4 ${(venue.rating || 0) >= i ? 'fill-current' : 'text-slate-300 dark:text-white/20'}`} />)}
                              </div>
                              <span className="text-sm font-bold text-slate-900 dark:text-white">{venue.rating}</span>
                              <span className="text-xs text-slate-500 dark:text-mid-text-subtle">• Based on {venue.reviews?.length || 0} reviews</span>
                          </div>
                      </div>
                      <button 
                        onClick={() => {
                            if (!user) setAuthModalOpen(true);
                            else setIsReviewModalOpen(true);
                        }}
                        className="px-6 py-3 rounded-full border border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/5 transition-all text-xs font-bold uppercase tracking-widest flex items-center gap-2"
                      >
                          <Plus className="w-4 h-4" /> Rate Venue
                      </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {venue.reviews?.map((review: any) => (
                          <div key={review.id} className="p-6 bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-[24px] space-y-4">
                              <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-3">
                                      <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-white/5 flex items-center justify-center overflow-hidden">
                                          {review.photo ? <img src={review.photo} className="w-full h-full object-cover" /> : <User className="w-5 h-5 text-slate-400" />}
                                      </div>
                                      <div>
                                          <h4 className="text-xs font-bold uppercase tracking-widest text-slate-900 dark:text-white">{review.name}</h4>
                                          <span className="text-[10px] text-slate-400">{review.date}</span>
                                      </div>
                                  </div>
                                  <div className="flex text-mid-highlight">
                                      {[1, 2, 3, 4, 5].map(i => <Star key={i} className={`w-3 h-3 ${(review.rating || 5) >= i ? 'fill-current' : 'text-slate-300 dark:text-white/10'}`} />)}
                                  </div>
                              </div>
                              <p className="text-sm text-slate-600 dark:text-slate-400 italic leading-relaxed">"{review.quote}"</p>
                          </div>
                      ))}
                      {(!venue.reviews || venue.reviews.length === 0) && (
                          <p className="text-slate-500 text-sm italic col-span-2">No reviews yet. Be the first to share your experience!</p>
                      )}
                  </div>
              </div>
          </div>

          <div className="lg:col-span-4 relative">
              <div className="sticky top-24 space-y-6">
                  <div className="bg-white dark:bg-[#151515] border border-slate-200 dark:border-white/10 rounded-[32px] p-8 shadow-xl dark:shadow-glass-deep space-y-8">
                      <div className="flex justify-between items-start border-b border-slate-100 dark:border-white/5 pb-6">
                          <div>
                              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Status</p>
                              <h3 className="text-2xl font-tiempos font-medium text-green-500">Available</h3>
                          </div>
                          <div className="p-2 rounded-lg bg-mid-secondary/10 text-mid-secondary">
                              <Calendar className="w-5 h-5" />
                          </div>
                      </div>

                      <div className="space-y-4">
                          <p className="text-xs text-slate-500 leading-relaxed">
                              This venue supports instant booking requests. A 50% deposit is typically required to secure the date.
                          </p>
                      </div>

                      <button 
                        onClick={handleBooking}
                        className="w-full py-4 bg-mid-secondary hover:bg-mid-secondary/90 text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-glow-secondary transition-all active:scale-95 flex items-center justify-center gap-3"
                      >
                          Request Booking <ShoppingBag className="w-4 h-4" />
                      </button>
                  </div>
              </div>
          </div>
      </div>

      {/* Review Modal */}
      <Modal 
        isOpen={isReviewModalOpen} 
        onClose={() => setIsReviewModalOpen(false)} 
        title="Rate Venue"
      >
          <div className="p-8 space-y-8">
              <div className="flex flex-col items-center gap-4">
                  <div className="w-20 h-20 rounded-full overflow-hidden bg-slate-200 dark:bg-white/10">
                      <OptimizedImage src={venue.imageUrl} alt={venue.title} className="w-full h-full object-cover" />
                  </div>
                  <div className="text-center">
                      <h3 className="text-xl font-tiempos font-bold text-slate-900 dark:text-white">{venue.title}</h3>
                      <p className="text-xs text-slate-500 uppercase tracking-widest">How was the space?</p>
                  </div>
              </div>

              <div className="flex justify-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                      <button
                          key={star}
                          onMouseEnter={() => setHoverRating(star)}
                          onMouseLeave={() => setHoverRating(0)}
                          onClick={() => setReviewRating(star)}
                          className="p-2 transition-transform hover:scale-110"
                      >
                          <Star 
                            className={`w-8 h-8 transition-colors ${
                                (hoverRating || reviewRating) >= star 
                                ? 'fill-mid-highlight text-mid-highlight' 
                                : 'text-slate-300 dark:text-white/20'
                            }`} 
                          />
                      </button>
                  ))}
              </div>

              <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Your Review</label>
                  <textarea 
                      value={reviewText}
                      onChange={(e) => setReviewText(e.target.value)}
                      className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-2xl p-4 text-sm focus:outline-none focus:border-mid-secondary h-32 resize-none"
                      placeholder="Share details about the atmosphere, service, and facilities..."
                  />
              </div>

              <button 
                  onClick={handleSubmitReview}
                  className="w-full py-4 bg-mid-secondary text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-glow-secondary transition-all active:scale-95"
              >
                  Submit Review
              </button>
          </div>
      </Modal>
    </div>
  );
};
