
import React, { useEffect, useState, useRef } from 'react';
import { api } from '../services/api';
import { ProfessionalEntity, Review } from '../types';
import { 
  ArrowLeft, MapPin, Star, Play, Pause, Music, 
  CheckCircle2, Share2, Instagram, Youtube, Globe,
  ShieldCheck, Clock, Zap, MessageSquare, Plus,
  LayoutGrid, Volume2, User, Video, List, ArrowRight,
  Calendar
} from 'lucide-react';
import { OptimizedImage } from '../components/Card';
import { useAuth } from '../contexts/AuthContext';
import { useBasket } from '../contexts/BasketContext';
import { useToast } from '../contexts/ToastContext';
import { Modal } from '../components/Modal';

interface ArtistDetailsProps {
  id?: string;
  onNavigate: (route: string) => void;
  onBack?: () => void;
}

export const ArtistDetails: React.FC<ArtistDetailsProps> = ({ id, onNavigate, onBack }) => {
  const [artist, setArtist] = useState<ProfessionalEntity | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeMediaIdx, setActiveMediaIdx] = useState(0);
  const [showFloatingCTA, setShowFloatingCTA] = useState(false);
  
  // Review Modal State
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [reviewText, setReviewText] = useState('');
  const [reviewRating, setReviewRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);

  // Quick Inquiry Modal State
  const [isInquiryModalOpen, setIsInquiryModalOpen] = useState(false);
  const [inquiryDate, setInquiryDate] = useState('');
  const [inquiryMessage, setInquiryMessage] = useState('');

  const { addToShortlist, isInShortlist } = useBasket(); // Refactored to useShortlist internally but useBasket for now
  const { user, setAuthModalOpen } = useAuth();
  const { showToast } = useToast();

  useEffect(() => {
    const load = async () => {
      try {
        const data = await api.getArtistDetails(id || 'a1');
        setArtist(data);
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, [id]);

  useEffect(() => {
    const handleScroll = () => {
      setShowFloatingCTA(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleShortlist = () => {
      if (artist) {
          if (isInShortlist(artist.id)) {
              showToast(`${artist.title} is already in your shortlist.`, 'info');
          } else {
              addToShortlist(artist);
              showToast(`${artist.title} shortlisted!`, 'success');
          }
      }
  };

  const handleQuickInquiry = () => {
      if (!user) {
          setAuthModalOpen(true);
          return;
      }
      setIsInquiryModalOpen(true);
  };

  const submitInquiry = () => {
      if (!inquiryDate || !inquiryMessage) {
          showToast('Please fill in all fields.', 'error');
          return;
      }
      // Mock API call
      setTimeout(() => {
          setIsInquiryModalOpen(false);
          setInquiryDate('');
          setInquiryMessage('');
          showToast('Inquiry sent successfully! The artist will respond shortly.', 'success');
      }, 1000);
  };

  const handleSubmitReview = () => {
      if (!reviewRating) return showToast('Please select a rating', 'error');
      if (!artist) return;

      const newReview: Review = {
          id: Date.now(),
          type: 'manual',
          name: user?.name || 'Guest User',
          rating: reviewRating,
          date: 'Just now',
          quote: reviewText,
          photo: user?.avatarUrl || undefined
      };

      setArtist(prev => prev ? {
          ...prev,
          reviews: [newReview, ...(prev.reviews || [])]
      } : null);

      setIsReviewModalOpen(false);
      setReviewText('');
      setReviewRating(0);
      showToast('Review submitted successfully!', 'success');
  };

  if (isLoading || !artist) {
    return (
      <div className="h-[60vh] w-full flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-mid-primary/20 border-t-mid-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="animate-cinematic-fade pb-32 pt-6 md:pt-8">
      
      {/* Sticky Mobile Action Bar */}
      <div className={`fixed bottom-0 left-0 right-0 z-50 bg-white dark:bg-[#121212] border-t border-slate-200 dark:border-white/10 p-4 pb-6 md:hidden transition-transform duration-300 ${showFloatingCTA ? 'translate-y-0' : 'translate-y-full'}`}>
          <div className="flex gap-3 items-center">
              <div className="flex-1">
                  <p className="text-[10px] text-slate-500 uppercase font-bold tracking-wide">Starting from</p>
                  <p className="text-sm font-bold text-slate-900 dark:text-white">{artist.priceRange}</p>
              </div>
              <button 
                onClick={handleShortlist}
                className="w-12 h-12 flex items-center justify-center rounded-xl bg-slate-100 dark:bg-white/10 text-slate-900 dark:text-white"
              >
                  <List className="w-5 h-5" />
              </button>
              <button 
                onClick={handleQuickInquiry}
                className="flex-1 py-3.5 bg-mid-primary text-white rounded-xl text-[10px] font-bold uppercase tracking-widest shadow-lg"
              >
                Check Availability
              </button>
          </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 mb-12">
          {/* Back Button */}
          <button 
                onClick={onBack ? onBack : () => onNavigate('artists')}
                className="group flex items-center gap-3 px-5 py-2.5 rounded-full border border-slate-200 dark:border-white/10 bg-white/50 dark:bg-white/5 backdrop-blur-md hover:border-mid-primary/50 hover:bg-mid-primary/5 transition-all duration-300 w-fit mb-8"
            >
                <ArrowLeft className="w-4 h-4 text-slate-500 dark:text-slate-400 group-hover:text-mid-primary transition-colors" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 group-hover:text-mid-primary transition-colors">Back</span>
          </button>

          <div className="flex flex-col md:flex-row gap-8 md:gap-12 items-start md:items-end">
                {/* Image Column */}
                <div className="w-full md:w-[400px] lg:w-[450px] shrink-0">
                    <div className="aspect-[3/4] md:aspect-[4/5] rounded-[32px] overflow-hidden shadow-2xl relative group bg-mid-surface">
                        <OptimizedImage 
                            src={artist.imageUrl} 
                            alt={artist.title} 
                            containerClass="w-full h-full"
                            className="w-full h-full object-cover transition-transform duration-[20s] group-hover:scale-105"
                        />
                        {/* Verified Badge */}
                        {artist.verified && (
                            <div className="absolute top-4 right-4 bg-mid-secondary/90 backdrop-blur-md text-white px-3 py-1.5 rounded-full shadow-lg z-10 flex items-center gap-1.5 border border-white/20">
                                <ShieldCheck className="w-3.5 h-3.5" />
                                <span className="text-[9px] font-bold uppercase tracking-widest">Verified</span>
                            </div>
                        )}
                    </div>
                </div>

                {/* Info Column */}
                <div className="flex-1 space-y-6 pb-2 w-full">
                    <div className="space-y-4">
                        <div className="flex flex-wrap items-center gap-3">
                            <div className="px-4 py-1.5 bg-mid-primary/10 border border-mid-primary/20 text-mid-primary text-[10px] font-bold uppercase tracking-widest rounded-full">
                                {artist.profession}
                            </div>
                            <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-white/5 px-3 py-1.5 rounded-full border border-slate-200 dark:border-white/10">
                                <Star className="w-3.5 h-3.5 text-mid-highlight fill-current" />
                                <span className="text-xs font-bold text-slate-900 dark:text-white">{artist.rating}</span>
                                <span className="text-[10px] text-slate-500">({artist.reviews?.length} reviews)</span>
                            </div>
                        </div>

                        {/* Responsive Typography Fix */}
                        <h1 className="text-4xl md:text-7xl lg:text-8xl font-inter font-semibold text-slate-900 dark:text-white leading-[0.95] tracking-tighter">
                            {artist.title}
                        </h1>

                        <div className="flex flex-wrap items-center gap-6 text-sm text-slate-500 dark:text-mid-text-subtle font-medium">
                            <div className="flex items-center gap-2">
                                <MapPin className="w-4 h-4" />
                                <span>{artist.location}</span>
                            </div>
                            <div className="w-1 h-1 bg-slate-300 dark:bg-white/20 rounded-full" />
                            <div className="flex gap-4">
                                {artist.socials?.instagram && <a href={artist.socials.instagram} target="_blank" rel="noreferrer" className="hover:text-mid-primary transition-colors"><Instagram className="w-5 h-5" /></a>}
                                {artist.socials?.youtube && <a href={artist.socials.youtube} target="_blank" rel="noreferrer" className="hover:text-red-500 transition-colors"><Youtube className="w-5 h-5" /></a>}
                                {artist.socials?.website && <a href={artist.socials.website} target="_blank" rel="noreferrer" className="hover:text-blue-400 transition-colors"><Globe className="w-5 h-5" /></a>}
                            </div>
                        </div>
                    </div>

                    <div className="pt-6 border-t border-slate-200 dark:border-white/10 grid grid-cols-2 gap-8">
                         <div>
                            <span className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Response Time</span>
                            <span className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                <Clock className="w-4 h-4 text-mid-primary" /> {artist.responseTime}
                            </span>
                         </div>
                         <div>
                            <span className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Starting Rate</span>
                            <span className="text-sm font-bold text-slate-900 dark:text-white">
                                {artist.priceRange?.split('-')[0]}
                            </span>
                         </div>
                    </div>
                </div>
          </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* LEFT CONTENT COLUMN */}
          <div className="lg:col-span-8 space-y-12">
              
              {/* 1. Bio & Specialties */}
              <div className="space-y-6">
                  <h3 className="text-sm font-bold text-slate-400">About the Artist</h3>
                  <p className="text-lg md:text-xl font-light text-slate-700 dark:text-slate-300 leading-relaxed">
                      {artist.bio || "No bio available."}
                  </p>
                  <div className="flex flex-wrap gap-2">
                      {artist.specialties?.map(tag => (
                          <span key={tag} className="px-4 py-2 bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-full text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">
                              {tag}
                          </span>
                      ))}
                  </div>
              </div>

              {/* 2. Media Gallery */}
              <div className="space-y-6">
                  <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-slate-400">Portfolio</h3>
                      <div className="flex gap-2">
                          <button className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/5"><LayoutGrid className="w-4 h-4" /></button>
                      </div>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 h-96">
                      {/* Featured Item (First) */}
                      <div className="col-span-2 row-span-2 relative rounded-2xl overflow-hidden group cursor-pointer" onClick={() => setActiveMediaIdx(0)}>
                          <OptimizedImage src={artist.media?.[0]?.url} alt="" containerClass="w-full h-full" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                          {artist.media?.[0]?.type === 'video' && (
                              <div className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/40 transition-colors">
                                  <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center border border-white/30">
                                      <Play className="w-5 h-5 text-white fill-current ml-0.5" />
                                  </div>
                              </div>
                          )}
                      </div>
                      
                      {/* Secondary Items */}
                      {artist.media?.slice(1, 5).map((m, i) => (
                          <div key={i} className="relative rounded-2xl overflow-hidden group cursor-pointer" onClick={() => setActiveMediaIdx(i + 1)}>
                              <OptimizedImage src={m.type === 'video' ? m.thumbnail : m.url} alt="" containerClass="w-full h-full" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                              {m.type === 'video' && <div className="absolute top-2 right-2 p-1 bg-black/50 rounded text-white"><Video className="w-3 h-3" /></div>}
                          </div>
                      ))}
                  </div>
              </div>

              {/* 3. Sonic Identity (Audio) */}
              <div className="p-1 rounded-3xl bg-gradient-to-r from-mid-primary via-purple-500 to-pink-500">
                  <div className="bg-[#121212] rounded-[20px] p-6 md:p-8 flex flex-col md:flex-row items-center gap-6 relative overflow-hidden">
                      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20 pointer-events-none" />
                      
                      <button 
                        onClick={() => setIsPlaying(!isPlaying)}
                        className="relative w-16 h-16 md:w-20 md:h-20 rounded-full bg-white text-black flex items-center justify-center shrink-0 hover:scale-105 transition-transform z-10 shadow-[0_0_30px_rgba(255,255,255,0.3)]"
                      >
                          {isPlaying ? <Pause className="w-6 h-6 md:w-8 md:h-8 fill-current" /> : <Play className="w-6 h-6 md:w-8 md:h-8 fill-current ml-1" />}
                      </button>

                      <div className="flex-1 space-y-2 text-center md:text-left z-10">
                          <h4 className="text-white text-lg font-bold">Featured Demo: Live at Carthage</h4>
                          <div className="w-full h-10 flex items-center gap-1 opacity-60">
                              {/* Audio Wave Visualizer Mockup */}
                              {Array.from({ length: 40 }).map((_, i) => (
                                  <div key={i} className="flex-1 bg-white rounded-full animate-pulse" style={{ height: `${Math.random() * 100}%`, animationDelay: `${i * 0.05}s` }} />
                              ))}
                          </div>
                      </div>
                      
                      <div className="text-xs font-mono text-white/60 z-10">
                          02:14 / 04:20
                      </div>
                  </div>
              </div>

              {/* 4. Equipment Rider */}
              {artist.hasEquipment && (
                  <div className="space-y-6">
                      <h3 className="text-sm font-bold text-slate-400">Technical Rider</h3>
                      <div className="bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-2xl p-6 font-mono text-sm text-slate-700 dark:text-slate-300 leading-relaxed relative overflow-hidden">
                          <div className="absolute top-0 left-0 w-1 h-full bg-mid-accent" />
                          <Zap className="w-12 h-12 text-mid-accent/10 absolute top-4 right-4" />
                          {artist.equipment}
                      </div>
                  </div>
              )}

              {/* 5. Review Engine */}
              <div className="space-y-8 pt-8 border-t border-slate-200 dark:border-white/10">
                  <div className="flex items-center justify-between">
                      <div className="space-y-1">
                          <h3 className="text-2xl font-tiempos font-normal text-slate-900 dark:text-white">Vibe Check</h3>
                          <div className="flex items-center gap-2">
                              <div className="flex text-mid-highlight">
                                  {[1, 2, 3, 4, 5].map(i => <Star key={i} className={`w-4 h-4 ${(artist.rating || 0) >= i ? 'fill-current' : 'text-slate-300 dark:text-white/20'}`} />)}
                              </div>
                              <span className="text-sm font-bold text-slate-900 dark:text-white">{artist.rating}</span>
                              <span className="text-xs text-slate-500 dark:text-mid-text-subtle">• Based on {artist.reviews?.length} performances</span>
                          </div>
                      </div>
                      <button 
                        onClick={() => {
                            if (!user) setAuthModalOpen(true);
                            else setIsReviewModalOpen(true);
                        }}
                        className="px-6 py-3 rounded-full border border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/5 transition-all text-xs font-bold uppercase tracking-widest flex items-center gap-2"
                      >
                          <Plus className="w-4 h-4" /> Rate Artist
                      </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {artist.reviews?.map((review) => (
                          <div key={review.id} className="p-6 bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 rounded-[24px] space-y-4">
                              <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-3">
                                      <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-white/5 flex items-center justify-center overflow-hidden">
                                          {review.photo ? <img src={review.photo} className="w-full h-full object-cover" /> : <User className="w-5 h-5 text-slate-400" />}
                                      </div>
                                      <div>
                                          <h4 className="text-xs font-bold uppercase tracking-widest text-slate-900 dark:text-white">{review.name}</h4>
                                          <span className="text-[10px] text-slate-400">{review.date}</span>
                                      </div>
                                  </div>
                                  <div className="flex text-mid-highlight">
                                      {[1, 2, 3, 4, 5].map(i => <Star key={i} className={`w-3 h-3 ${(review.rating || 5) >= i ? 'fill-current' : 'text-slate-300 dark:text-white/10'}`} />)}
                                  </div>
                              </div>
                              <p className="text-sm text-slate-600 dark:text-slate-400 italic leading-relaxed">"{review.quote}"</p>
                          </div>
                      ))}
                  </div>
              </div>

          </div>

          {/* RIGHT SIDEBAR - BOOKING CONSOLE */}
          <div className="lg:col-span-4 relative hidden md:block">
              <div className="sticky top-24 space-y-6">
                  <div className="bg-white dark:bg-[#151515] border border-slate-200 dark:border-white/10 rounded-[32px] p-8 shadow-xl dark:shadow-glass-deep space-y-8">
                      <div className="flex justify-between items-start border-b border-slate-100 dark:border-white/5 pb-6">
                          <div>
                              <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1">Booking Rate</p>
                              <h3 className="text-2xl font-tiempos font-medium text-slate-900 dark:text-white">{artist.priceRange}</h3>
                          </div>
                          <div className="p-2 rounded-lg bg-green-500/10 text-green-500">
                              <ShieldCheck className="w-5 h-5" />
                          </div>
                      </div>

                      <div className="space-y-4">
                          <div className="flex items-center gap-4">
                              <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-white/5 flex items-center justify-center text-slate-900 dark:text-white">
                                  <Clock className="w-5 h-5" />
                              </div>
                              <div>
                                  <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Response Time</h4>
                                  <p className="text-xs text-slate-500 dark:text-slate-400">{artist.responseTime}</p>
                              </div>
                          </div>
                          <div className="flex items-center gap-4">
                              <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-white/5 flex items-center justify-center text-slate-900 dark:text-white">
                                  <CheckCircle2 className="w-5 h-5" />
                              </div>
                              <div>
                                  <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Availability</h4>
                                  <div className="flex flex-wrap gap-1 mt-1">
                                      {artist.availability?.map(a => <span key={a} className="px-1.5 py-0.5 rounded bg-green-500/10 text-green-500 text-[9px] font-bold uppercase">{a}</span>)}
                                  </div>
                              </div>
                          </div>
                      </div>

                      <div className="flex flex-col gap-3">
                          <button 
                            onClick={handleQuickInquiry}
                            className="w-full py-4 bg-mid-primary hover:bg-mid-primary/90 text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-glow-blue transition-all active:scale-95 flex items-center justify-center gap-3"
                          >
                              Check Availability <Calendar className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={handleShortlist}
                            className={`w-full py-3.5 rounded-2xl font-bold text-[10px] uppercase tracking-widest transition-all border flex items-center justify-center gap-2 ${isInShortlist(artist.id) ? 'bg-green-500/10 text-green-500 border-green-500/20' : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 border-transparent hover:bg-slate-200 dark:hover:bg-white/10'}`}
                          >
                              {isInShortlist(artist.id) ? 'Added to Shortlist' : 'Add to Shortlist'} <List className="w-4 h-4" />
                          </button>
                      </div>

                      <div className="text-[10px] text-slate-400 text-center leading-relaxed px-4">
                          Secure booking via MidMike Escrow. 
                          <br/><span className="text-slate-500 dark:text-slate-600">{artist.cancellationPolicy}</span>
                      </div>
                  </div>
              </div>
          </div>
      </div>

      {/* Review Modal */}
      <Modal 
        isOpen={isReviewModalOpen} 
        onClose={() => setIsReviewModalOpen(false)} 
        title="Rate Performance"
      >
          <div className="p-8 space-y-8">
              <div className="flex flex-col items-center gap-4">
                  <div className="w-20 h-20 rounded-full overflow-hidden bg-slate-200 dark:bg-white/10">
                      <OptimizedImage src={artist.imageUrl} alt={artist.title} className="w-full h-full object-cover" />
                  </div>
                  <div className="text-center">
                      <h3 className="text-xl font-tiempos font-bold text-slate-900 dark:text-white">{artist.title}</h3>
                      <p className="text-xs text-slate-500 uppercase tracking-widest">How was the experience?</p>
                  </div>
              </div>

              <div className="flex justify-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                      <button
                          key={star}
                          onMouseEnter={() => setHoverRating(star)}
                          onMouseLeave={() => setHoverRating(0)}
                          onClick={() => setReviewRating(star)}
                          className="p-2 transition-transform hover:scale-110"
                      >
                          <Star 
                            className={`w-8 h-8 transition-colors ${
                                (hoverRating || reviewRating) >= star 
                                ? 'fill-mid-highlight text-mid-highlight' 
                                : 'text-slate-300 dark:text-white/20'
                            }`} 
                          />
                      </button>
                  ))}
              </div>

              <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Your Review</label>
                  <textarea 
                      value={reviewText}
                      onChange={(e) => setReviewText(e.target.value)}
                      className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-2xl p-4 text-sm focus:outline-none focus:border-mid-primary h-32 resize-none"
                      placeholder="Share details about the performance, professionalism, and vibe..."
                  />
              </div>

              <button 
                  onClick={handleSubmitReview}
                  className="w-full py-4 bg-mid-primary text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-glow-blue transition-all active:scale-95"
              >
                  Submit Review
              </button>
          </div>
      </Modal>

      {/* Quick Inquiry Modal */}
      <Modal
        isOpen={isInquiryModalOpen}
        onClose={() => setIsInquiryModalOpen(false)}
        title="Check Availability"
      >
          <div className="p-6 md:p-8 space-y-6">
              <div className="flex items-center gap-4 p-4 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-200 dark:border-white/10">
                  <div className="w-12 h-12 rounded-xl overflow-hidden">
                      <img src={artist.imageUrl} className="w-full h-full object-cover" />
                  </div>
                  <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">Inquiry for {artist.title}</h4>
                      <p className="text-[10px] text-slate-500 dark:text-mid-text-subtle">Direct Message Request</p>
                  </div>
              </div>

              <div className="space-y-4">
                  <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Date of Event</label>
                      <input 
                        type="date" 
                        value={inquiryDate}
                        onChange={(e) => setInquiryDate(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-mid-primary"
                      />
                  </div>
                  <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Message</label>
                      <textarea 
                        value={inquiryMessage}
                        onChange={(e) => setInquiryMessage(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-xl p-4 text-sm focus:outline-none focus:border-mid-primary h-32 resize-none"
                        placeholder="Hi, are you available for a private event in Tunis on this date?"
                      />
                  </div>
              </div>

              <button 
                  onClick={submitInquiry}
                  className="w-full py-4 bg-mid-primary text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-glow-blue transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                  Send Inquiry <ArrowRight className="w-4 h-4" />
              </button>
          </div>
      </Modal>
    </div>
  );
};
