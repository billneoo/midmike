
import React, { useState, useEffect, useRef } from 'react';
import { api } from '../services/api';
import { 
  Mic2, Video, Speaker, Music, Check, 
  Calendar as CalendarIcon, Clock, ArrowRight, Zap,
  Sliders, ChevronLeft, ChevronRight, ChevronDown, X, ArrowLeft,
  Users, MapPin, Shirt, Globe, ListMusic, Truck,
  Lightbulb, Camera, Utensils, Shield, Layout, FileText,
  Mail, Phone, User, Monitor, AlertCircle, Save, RotateCcw
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useBasket } from '../contexts/BasketContext';

// --- Custom Console Select Components ---

const ConsoleSelect = ({ 
    options, 
    value, 
    onChange, 
    placeholder = "Select", 
    className = "",
    error = false
}: { 
    options: string[] | { label: string; value: string }[], 
    value: string, 
    onChange: (val: string) => void, 
    placeholder?: string,
    className?: string,
    error?: boolean
}) => {
    const [isOpen, setIsOpen] = useState(false);
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const displayValue = () => {
        if (!value) return placeholder;
        const selected = options.find(o => (typeof o === 'string' ? o : o.value) === value);
        return selected ? (typeof selected === 'string' ? selected : selected.label) : value;
    };

    return (
        <div className={`relative ${className}`} ref={containerRef}>
            <button
                type="button"
                onClick={() => setIsOpen(!isOpen)}
                className={`w-full flex items-center justify-between px-4 py-3 bg-white dark:bg-black/40 border-2 rounded-xl text-sm transition-all duration-300 
                ${error ? 'border-red-500 animate-pulse' : 'border-slate-300 dark:border-white/5 hover:border-slate-400 dark:hover:border-white/20'}
                ${isOpen ? 'border-mid-primary ring-1 ring-mid-primary shadow-glow-blue' : ''}`}
            >
                <span className={`font-bold truncate mr-2 ${value ? 'text-slate-900 dark:text-white' : 'text-slate-400 dark:text-white/40'}`}>
                    {displayValue()}
                </span>
                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-300 flex-shrink-0 ${isOpen ? 'rotate-180 text-mid-primary' : ''}`} />
            </button>

            {isOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 z-50 bg-white dark:bg-[#1a1a1a] border border-slate-200 dark:border-white/10 rounded-xl shadow-2xl max-h-60 overflow-y-auto custom-scrollbar animate-in fade-in zoom-in-95 origin-top">
                    {options.map((opt, idx) => {
                        const val = typeof opt === 'string' ? opt : opt.value;
                        const label = typeof opt === 'string' ? opt : opt.label;
                        const isSelected = value === val;
                        return (
                            <button
                                key={idx}
                                type="button"
                                onClick={() => { onChange(val); setIsOpen(false); }}
                                className={`w-full text-left px-4 py-3 text-xs font-bold uppercase tracking-wider transition-colors border-b border-slate-100 dark:border-white/5 last:border-0
                                    ${isSelected 
                                        ? 'bg-mid-primary/10 text-mid-primary' 
                                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5'
                                    }`}
                            >
                                {label}
                            </button>
                        );
                    })}
                </div>
            )}
        </div>
    );
};

const ConsoleDateSelector = ({ value, onChange, error }: { value: string, onChange: (val: string) => void, error?: boolean }) => {
    // value format YYYY-MM-DD
    const [year, month, day] = value ? value.split('-') : ['', '', ''];
    
    const currentYear = new Date().getFullYear();
    const years = Array.from({ length: 3 }, (_, i) => (currentYear + i).toString());
    const months = [
        { value: '01', label: 'Jan' }, { value: '02', label: 'Feb' }, { value: '03', label: 'Mar' }, 
        { value: '04', label: 'Apr' }, { value: '05', label: 'May' }, { value: '06', label: 'Jun' },
        { value: '07', label: 'Jul' }, { value: '08', label: 'Aug' }, { value: '09', label: 'Sep' }, 
        { value: '10', label: 'Oct' }, { value: '11', label: 'Nov' }, { value: '12', label: 'Dec' }
    ];
    const days = Array.from({ length: 31 }, (_, i) => (i + 1).toString().padStart(2, '0'));

    const updateDate = (type: 'y' | 'm' | 'd', val: string) => {
        let newY = type === 'y' ? val : (year || currentYear.toString());
        let newM = type === 'm' ? val : (month || '01');
        let newD = type === 'd' ? val : (day || '01');
        onChange(`${newY}-${newM}-${newD}`);
    }

    return (
        <div className="flex gap-2">
            <ConsoleSelect 
                className="w-[80px] shrink-0" 
                options={days} 
                value={day} 
                onChange={v => updateDate('d', v)} 
                placeholder="DD" 
                error={error}
            />
            <ConsoleSelect 
                className="flex-1" 
                options={months} 
                value={month} 
                onChange={v => updateDate('m', v)} 
                placeholder="Month" 
                error={error}
            />
            <ConsoleSelect 
                className="w-[90px] shrink-0" 
                options={years} 
                value={year} 
                onChange={v => updateDate('y', v)} 
                placeholder="YYYY" 
                error={error}
            />
        </div>
    );
};

const ConsoleTimeSelector = ({ value, onChange, error }: { value: string, onChange: (val: string) => void, error?: boolean }) => {
    // Generate time slots 00:00 to 23:30
    const slots = [];
    for (let i = 8; i < 24; i++) { // Start from 8 AM usually
        for (let j = 0; j < 60; j += 30) { 
            const h = i.toString().padStart(2, '0');
            const m = j.toString().padStart(2, '0');
            slots.push(`${h}:${m}`);
        }
    }
    // Add late night slots
    for (let i = 0; i < 4; i++) {
         for (let j = 0; j < 60; j += 30) {
            const h = i.toString().padStart(2, '0');
            const m = j.toString().padStart(2, '0');
            slots.push(`${h}:${m}`);
        }
    }

    return (
        <ConsoleSelect 
            options={slots} 
            value={value} 
            onChange={onChange} 
            placeholder="00:00" 
            error={error}
        />
    );
};

const SERVICES = [
  { 
      id: 'recording', 
      label: 'Audio Recording', 
      icon: Mic2, 
      price: 'From 120 TND/hr',
      gear: 'Neumann U87, Avalon 737',
      desc: 'Pristine vocal & instrument capture in an acoustically treated booth.' 
  },
  { 
      id: 'filming', 
      label: 'Video Production', 
      icon: Video, 
      price: 'From 400 TND/session',
      gear: 'Sony FX3, Aputure Lighting',
      desc: '4K multi-cam setup for podcasts, interviews, and music videos.' 
  },
  { 
      id: 'mixing', 
      label: 'Mixing & Mastering', 
      icon: Speaker, 
      price: 'From 300 TND/track',
      gear: 'Pro Tools HD, SSL Fusion',
      desc: 'Industry-standard post-production to get your tracks radio-ready.' 
  },
  { 
      id: 'rehearsal', 
      label: 'Rehearsal Space', 
      icon: Music, 
      price: 'From 60 TND/hr',
      gear: 'Full Backline Provided',
      desc: 'Spacious, soundproofed room with private lounge access.' 
  },
];

const EVENT_TYPES = ['Concert', 'Festival', 'Wedding', 'Private Party', 'Bar / Lounge Night', 'Corporate Event', 'Other'];
const ATTENDEE_RANGES = ['< 50', '50–150', '150–500', '500+'];
const VENUE_TYPES = ['Hotel / Resort', 'Bar', 'Lounge / Rooftop', 'Club / Nightclub', 'Concert Hall', 'Outdoor Space / Garden', 'Studio / Rehearsal Room', 'Other'];
const PERFORMANCE_DURATIONS = ['30 min', '45 min', '1 h', '2 h', 'Other'];
const MUSIC_THEMES = ['Chill / Lounge / Deep House', 'Dancefloor / Party', 'Jazz / Soul / Blues', 'Acoustic / Intimate', 'Reggae / World', 'Specific Theme'];
const DRESS_CODES = ['Formal Attire', 'Casual Chic', 'Themed', 'Other'];
const PERFORMANCE_LANGUAGES = ['French', 'English', 'Arabic', 'Spanish', 'Other'];

const STEP_LABELS = ['Event', 'Venue', 'Vibes', 'Tech', 'Contact', 'Review'];

const INITIAL_FORM_DATA = {
    // Step 1
    eventTitle: '',
    eventType: '',
    eventTypeOther: '',
    date: '',
    startTime: '',
    endTime: '',
    attendees: '',
    // Step 2
    venueTypes: [] as string[],
    venueTypesOther: '',
    venueName: '', // For venue selection
    address: '', // Custom address / GPS
    isIndoor: true,
    setupDetails: '',
    // Step 3
    performanceDuration: '1 h',
    performanceDurationOther: '',
    musicalThemes: [] as string[],
    musicalThemesOther: '',
    dressCode: 'Casual Chic',
    dressCodeDetails: '',
    venueAmbiance: '',
    languages: [] as string[],
    languagesOther: '',
    playlist: '',
    // Step 4 (Tech - Toggle + Details)
    needsSound: false, soundDetails: '',
    needsLighting: false, lightingDetails: '',
    needsVideo: false, videoDetails: '',
    needsPhoto: false, photoDetails: '',
    needsDecor: false, decorDetails: '',
    needsCatering: false, cateringDetails: '',
    needsSecurity: false, securityDetails: '',
    needsTransport: false, transportDetails: '',
    needsOther: false, otherDetails: '',
    // Step 5
    contactName: '',
    organization: '',
    contactEmail: '',
    contactPhone: '',
    billingAddress: '',
    // Step 6
    comments: '',
    acceptedTerms: false,
    authorizedShare: false
};

export const Studio: React.FC = () => {
  const { user, setAuthModalOpen } = useAuth();
  const { items: basketItems } = useBasket(); 
  // Initialize with the first service selected by default
  const [selectedService, setSelectedService] = useState<string | null>(SERVICES[0].id);
  
  // Wizard State
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 6;
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errors, setErrors] = useState<Record<string, boolean>>({});
  const [draftLoaded, setDraftLoaded] = useState(false);

  // Form Data
  const [formData, setFormData] = useState({ ...INITIAL_FORM_DATA, contactName: user?.name || '', contactEmail: user?.email || '', contactPhone: user?.phone || '' });

  // Auto-Load Draft
  useEffect(() => {
      const saved = localStorage.getItem('studio_booking_draft');
      if (saved && !draftLoaded) {
          try {
              const parsed = JSON.parse(saved);
              if (parsed.service) setSelectedService(parsed.service);
              if (parsed.step) setCurrentStep(parsed.step);
              if (parsed.data) setFormData(prev => ({ ...prev, ...parsed.data }));
              setDraftLoaded(true);
          } catch (e) {
              console.error("Failed to load draft", e);
          }
      }
  }, [draftLoaded]);

  // Auto-Save Draft
  useEffect(() => {
      if (selectedService) {
          const timer = setTimeout(() => {
              localStorage.setItem('studio_booking_draft', JSON.stringify({
                  service: selectedService,
                  step: currentStep,
                  data: formData
              }));
          }, 1000);
          return () => clearTimeout(timer);
      }
  }, [formData, selectedService, currentStep]);

  const updateField = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
        setErrors(prev => {
            const next = { ...prev };
            delete next[field];
            return next;
        });
    }
  };

  const toggleArrayItem = (field: keyof typeof formData, item: string) => {
    setFormData(prev => {
      const arr = prev[field] as string[];
      return {
        ...prev,
        [field]: arr.includes(item) ? arr.filter(i => i !== item) : [...arr, item]
      };
    });
  };

  const validateStep = (step: number) => {
    const newErrors: Record<string, boolean> = {};
    let isValid = true;

    if (step === 1) {
        if (!formData.eventTitle) newErrors.eventTitle = true;
        if (!formData.eventType) newErrors.eventType = true;
        if (!formData.date) newErrors.date = true;
        if (!formData.startTime) newErrors.startTime = true;
        if (!formData.endTime) newErrors.endTime = true;
        if (!formData.attendees) newErrors.attendees = true;
    }
    if (step === 2) {
        if (!formData.venueName) newErrors.venueName = true;
        if (!formData.address) newErrors.address = true;
    }
    if (step === 3) {
        if (!formData.performanceDuration) newErrors.performanceDuration = true;
    }
    if (step === 5) {
        if (!formData.contactName) newErrors.contactName = true;
        if (!formData.contactEmail) newErrors.contactEmail = true;
        if (!formData.contactPhone) newErrors.contactPhone = true;
        if (!formData.billingAddress) newErrors.billingAddress = true;
    }

    if (Object.keys(newErrors).length > 0) {
        setErrors(newErrors);
        isValid = false;
    } else {
        setErrors({});
    }
    return isValid;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
        if (currentStep < totalSteps) {
            setCurrentStep(prev => prev + 1);
            document.getElementById('booking-console')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } else {
            handleSubmit();
        }
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleClearDraft = () => {
      localStorage.removeItem('studio_booking_draft');
      setFormData({ ...INITIAL_FORM_DATA, contactName: user?.name || '', contactEmail: user?.email || '', contactPhone: user?.phone || '' });
      setSelectedService(SERVICES[0].id); // Reset to default service
      setCurrentStep(1);
      setErrors({});
  };

  const handleSubmit = async () => {
    if (!user) {
        setAuthModalOpen(true);
        return;
    }
    if (!formData.acceptedTerms) {
        alert("Please accept the Terms & Conditions.");
        return;
    }
    if (!formData.authorizedShare) {
        alert("Please authorize sharing contact details with providers.");
        return;
    }
    setIsSubmitting(true);
    await api.submitStudioBooking({ service: selectedService, ...formData, artists: basketItems });
    localStorage.removeItem('studio_booking_draft');
    setIsSubmitting(false);
    setSuccess(true);
  };

  const scrollToBooking = () => {
      document.getElementById('booking-console')?.scrollIntoView({ behavior: 'smooth' });
  };

  // --- Styled Components Helper ---
  const InputClass = (error?: boolean) => `w-full bg-white dark:bg-black/40 border-2 rounded-xl px-4 py-3 text-sm text-slate-900 dark:text-white focus:outline-none transition-all ${error ? 'border-red-500 focus:border-red-500 animate-pulse' : 'border-slate-300 dark:border-white/5 focus:border-mid-primary/50'}`;

  // --- Step Renderers ---

  const renderStep1 = () => (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Event Title *</label>
            <input 
                value={formData.eventTitle}
                onChange={e => updateField('eventTitle', e.target.value)}
                className={InputClass(errors.eventTitle)}
                placeholder="e.g. Summer Sunset Session"
            />
        </div>
        
        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Event Type *</label>
            <div className={`grid grid-cols-2 sm:grid-cols-3 gap-2 ${errors.eventType ? 'p-1 border border-red-500 rounded-xl' : ''}`}>
                {EVENT_TYPES.map(type => (
                    <button
                        key={type}
                        type="button"
                        onClick={() => updateField('eventType', type)}
                        className={`px-3 py-2 rounded-lg text-xs font-bold uppercase tracking-wide border transition-all ${formData.eventType === type ? 'bg-mid-primary text-white border-mid-primary' : 'bg-transparent border-slate-300 dark:border-white/10 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5'}`}
                    >
                        {type}
                    </button>
                ))}
            </div>
            {formData.eventType === 'Other' && (
                <input 
                    placeholder="Specify other event type..."
                    value={formData.eventTypeOther}
                    onChange={e => updateField('eventTypeOther', e.target.value)}
                    className="w-full mt-2 bg-white dark:bg-black/40 border-2 border-slate-300 dark:border-white/5 rounded-lg px-3 py-2 text-xs"
                />
            )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Date *</label>
                <ConsoleDateSelector 
                    value={formData.date}
                    onChange={val => updateField('date', val)}
                    error={errors.date}
                />
            </div>
            <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Start Time *</label>
                <ConsoleTimeSelector 
                    value={formData.startTime}
                    onChange={val => updateField('startTime', val)}
                    error={errors.startTime}
                />
            </div>
            <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">End Time *</label>
                <ConsoleTimeSelector 
                    value={formData.endTime}
                    onChange={val => updateField('endTime', val)}
                    error={errors.endTime}
                />
            </div>
        </div>

        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Approximate Attendees *</label>
            <div className={`flex bg-white dark:bg-black/40 rounded-xl p-1 border-2 ${errors.attendees ? 'border-red-500' : 'border-slate-300 dark:border-white/5'}`}>
                {ATTENDEE_RANGES.map(range => (
                    <button
                        key={range}
                        type="button"
                        onClick={() => updateField('attendees', range)}
                        className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${formData.attendees === range ? 'bg-mid-primary text-white shadow-sm' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'}`}
                    >
                        {range}
                    </button>
                ))}
            </div>
        </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Venue Type (Select multiple)</label>
            <div className="flex flex-wrap gap-2">
                {VENUE_TYPES.map(type => (
                    <button
                        key={type}
                        type="button"
                        onClick={() => toggleArrayItem('venueTypes', type)}
                        className={`px-4 py-2 rounded-full text-xs font-bold transition-all border ${formData.venueTypes.includes(type) ? 'bg-mid-secondary/20 border-mid-secondary text-slate-900 dark:text-white' : 'bg-transparent border-slate-300 dark:border-white/10 text-slate-500 dark:text-mid-text-subtle'}`}
                    >
                        {type}
                    </button>
                ))}
            </div>
            {formData.venueTypes.includes('Other') && (
                <input 
                    placeholder="Specify other venue type..."
                    value={formData.venueTypesOther}
                    onChange={e => updateField('venueTypesOther', e.target.value)}
                    className="w-full mt-2 bg-white dark:bg-black/40 border-2 border-slate-300 dark:border-white/5 rounded-lg px-3 py-2 text-xs"
                />
            )}
        </div>

        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Venue Selection / Name *</label>
            <input 
                value={formData.venueName}
                onChange={e => updateField('venueName', e.target.value)}
                className={InputClass(errors.venueName)}
                placeholder="Name of the venue (if known)"
            />
        </div>

        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Full Address / GPS *</label>
            <div className="relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input 
                    value={formData.address}
                    onChange={e => updateField('address', e.target.value)}
                    className={`${InputClass(errors.address)} pl-12`}
                    placeholder="Street address, City, Zip or Google Maps Link"
                />
            </div>
        </div>

        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Environment *</label>
            <div className="flex gap-4">
                <button 
                    type="button"
                    onClick={() => updateField('isIndoor', true)} 
                    className={`flex-1 p-3 rounded-xl border-2 flex items-center justify-center gap-2 transition-all ${formData.isIndoor ? 'border-mid-secondary bg-mid-secondary/10 text-slate-900 dark:text-white' : 'border-slate-300 dark:border-white/5 text-slate-500'}`}
                >
                    <Layout className="w-4 h-4" /> Indoor
                </button>
                <button 
                    type="button"
                    onClick={() => updateField('isIndoor', false)} 
                    className={`flex-1 p-3 rounded-xl border-2 flex items-center justify-center gap-2 transition-all ${!formData.isIndoor ? 'border-mid-secondary bg-mid-secondary/5 text-mid-secondary' : 'border-slate-300 dark:border-white/5 text-slate-500'}`}
                >
                    <Zap className="w-4 h-4" /> <span className="text-xs font-bold uppercase">Outdoor</span>
                </button>
            </div>
        </div>

        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Desired Setup / Floor Plan</label>
            <textarea 
                value={formData.setupDetails}
                onChange={e => updateField('setupDetails', e.target.value)}
                className="w-full bg-white dark:bg-black/40 border-2 border-slate-300 dark:border-white/5 rounded-xl px-4 py-3 text-sm text-slate-900 dark:text-white focus:border-mid-primary/50 focus:outline-none h-24 resize-none"
                placeholder="Describe stage position, seating, or upload link to floor plan..."
            />
        </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
        
        {/* Cart Summary */}
        <div className="bg-slate-100 dark:bg-white/5 p-4 rounded-xl border border-slate-200 dark:border-white/5 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-slate-600 dark:text-mid-text-subtle flex items-center gap-2">
                <Users className="w-4 h-4" /> Selected Artists
            </h4>
            {basketItems.filter(i => i.title).length > 0 ? (
                <div className="flex flex-wrap gap-2">
                    {basketItems.map((item, idx) => (
                        <span key={idx} className="px-3 py-1 bg-white dark:bg-black/30 rounded-lg text-xs font-bold border border-slate-200 dark:border-white/10">{item.title}</span>
                    ))}
                </div>
            ) : (
                <p className="text-xs text-slate-400 italic">No artists selected in current session.</p>
            )}
        </div>

        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Performance Duration *</label>
            <select 
                value={formData.performanceDuration}
                onChange={e => updateField('performanceDuration', e.target.value)}
                className={InputClass(errors.performanceDuration)}
            >
                {PERFORMANCE_DURATIONS.map(d => <option key={d} value={d}>{d}</option>)}
            </select>
            {formData.performanceDuration === 'Other' && (
                <input 
                    placeholder="Specify duration..."
                    value={formData.performanceDurationOther}
                    onChange={e => updateField('performanceDurationOther', e.target.value)}
                    className="w-full mt-2 bg-white dark:bg-black/40 border-2 border-slate-300 dark:border-white/5 rounded-lg px-3 py-2 text-xs"
                />
            )}
        </div>

        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Musical Theme</label>
            <div className="flex flex-wrap gap-2">
                {MUSIC_THEMES.map(theme => (
                    <button
                        key={theme}
                        type="button"
                        onClick={() => toggleArrayItem('musicalThemes', theme)}
                        className={`px-3 py-1.5 rounded-full text-[10px] font-bold uppercase border transition-all ${formData.musicalThemes.includes(theme) ? 'bg-mid-accent text-white border-mid-accent' : 'bg-transparent border-slate-300 dark:border-white/10 text-slate-500 dark:text-mid-text-subtle'}`}
                    >
                        {theme}
                    </button>
                ))}
            </div>
            {formData.musicalThemes.includes('Specific Theme') && (
                <input 
                    placeholder="Specify theme (e.g. Halloween, 80s)..."
                    value={formData.musicalThemesOther}
                    onChange={e => updateField('musicalThemesOther', e.target.value)}
                    className="w-full mt-2 bg-white dark:bg-black/40 border-2 border-slate-300 dark:border-white/5 rounded-lg px-3 py-2 text-xs"
                />
            )}
        </div>

        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Preferred Dress Code</label>
            <div className="flex flex-wrap gap-4">
                {DRESS_CODES.map(dc => (
                    <label key={dc} className="flex items-center gap-2 cursor-pointer">
                        <input 
                            type="radio" 
                            name="dressCode" 
                            checked={formData.dressCode === dc}
                            onChange={() => updateField('dressCode', dc)}
                            className="accent-mid-accent"
                        />
                        <span className="text-xs text-slate-900 dark:text-white">{dc}</span>
                    </label>
                ))}
            </div>
            {(formData.dressCode === 'Themed' || formData.dressCode === 'Other') && (
                <input 
                    placeholder="Specify dress code..."
                    value={formData.dressCodeDetails}
                    onChange={e => updateField('dressCodeDetails', e.target.value)}
                    className="w-full mt-2 bg-white dark:bg-black/40 border-2 border-slate-300 dark:border-white/5 rounded-lg px-3 py-2 text-xs"
                />
            )}
        </div>

        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Venue Ambiance / Theme</label>
            <input 
                value={formData.venueAmbiance}
                onChange={e => updateField('venueAmbiance', e.target.value)}
                className="w-full bg-white dark:bg-black/40 border-2 border-slate-300 dark:border-white/5 rounded-xl px-4 py-3 text-sm text-slate-900 dark:text-white focus:outline-none"
                placeholder="e.g. Candlelit, Industrial, Bohemian..."
            />
        </div>

        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Performance Language(s)</label>
            <div className="flex flex-wrap gap-3">
                {PERFORMANCE_LANGUAGES.map(lang => (
                    <label key={lang} className="flex items-center gap-2 cursor-pointer">
                        <input 
                            type="checkbox" 
                            checked={formData.languages.includes(lang)}
                            onChange={() => toggleArrayItem('languages', lang)}
                            className="accent-mid-accent rounded"
                        />
                        <span className="text-xs text-slate-900 dark:text-white">{lang}</span>
                    </label>
                ))}
            </div>
            {formData.languages.includes('Other') && (
                <input 
                    placeholder="Specify other language..."
                    value={formData.languagesOther}
                    onChange={e => updateField('languagesOther', e.target.value)}
                    className="w-full mt-2 bg-white dark:bg-black/40 border-2 border-slate-300 dark:border-white/5 rounded-lg px-3 py-2 text-xs"
                />
            )}
        </div>

        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Mandatory Songs / Playlist</label>
            <div className="relative">
                <ListMusic className="absolute left-4 top-4 w-4 h-4 text-slate-400" />
                <textarea 
                    value={formData.playlist}
                    onChange={e => updateField('playlist', e.target.value)}
                    className="w-full bg-white dark:bg-black/40 border-2 border-slate-300 dark:border-white/5 rounded-xl pl-12 pr-4 py-3 text-sm text-slate-900 dark:text-white focus:border-mid-primary/50 focus:outline-none h-20 resize-none"
                    placeholder="List specific tracks or link a Spotify playlist..."
                />
            </div>
        </div>
    </div>
  );

  const TechToggle = ({ icon: Icon, label, field, detailsField, placeholder }: { icon: any, label: string, field: string, detailsField: string, placeholder: string }) => (
      <div className="bg-white dark:bg-black/20 border border-slate-200 dark:border-white/5 rounded-xl overflow-hidden transition-all">
          <div className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${(formData as any)[field] ? 'bg-mid-primary text-white' : 'bg-slate-100 dark:bg-white/5 text-slate-400'}`}>
                      <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-sm font-bold text-slate-900 dark:text-white">{label}</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" checked={(formData as any)[field]} onChange={e => updateField(field, e.target.checked)} className="sr-only peer" />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none dark:bg-gray-700 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-mid-primary"></div>
              </label>
          </div>
          {(formData as any)[field] && (
              <div className="px-4 pb-4 animate-in slide-in-from-top-2">
                  <textarea 
                    value={(formData as any)[detailsField]}
                    onChange={e => updateField(detailsField, e.target.value)}
                    placeholder={placeholder}
                    className="w-full bg-slate-50 dark:bg-black/40 border border-slate-200 dark:border-white/10 rounded-lg p-3 text-xs text-slate-900 dark:text-white focus:outline-none h-20 resize-none"
                  />
              </div>
          )}
      </div>
  );

  const renderStep4 = () => (
    <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-500 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
        <p className="text-xs text-slate-500 dark:text-mid-text-subtle mb-2">Enable services you require. Details help us quote accurately.</p>
        <TechToggle icon={Speaker} label="Sound Equipment" field="needsSound" detailsField="soundDetails" placeholder="System type, mics, monitors..." />
        <TechToggle icon={Lightbulb} label="Lighting" field="needsLighting" detailsField="lightingDetails" placeholder="Spots, ambiance, effects..." />
        <TechToggle icon={Video} label="Video Recording" field="needsVideo" detailsField="videoDetails" placeholder="Multicam, streaming, teaser..." />
        <TechToggle icon={Camera} label="Photography" field="needsPhoto" detailsField="photoDetails" placeholder="Reportage, portrait, drone..." />
        <TechToggle icon={Layout} label="Furniture / Decor" field="needsDecor" detailsField="decorDetails" placeholder="Tables, chairs, scenography..." />
        <TechToggle icon={Utensils} label="Catering / Bar" field="needsCatering" detailsField="cateringDetails" placeholder="Cocktails, buffet, service..." />
        <TechToggle icon={Shield} label="Security / Staff" field="needsSecurity" detailsField="securityDetails" placeholder="Number of staff, roles..." />
        <TechToggle icon={Truck} label="Transportation" field="needsTransport" detailsField="transportDetails" placeholder="Vehicles, time slots..." />
        <TechToggle icon={FileText} label="Other Services" field="needsOther" detailsField="otherDetails" placeholder="Specify any other needs..." />
    </div>
  );

  const renderStep5 = () => (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">First & Last Name *</label>
                <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input value={formData.contactName} onChange={e => updateField('contactName', e.target.value)} className={`${InputClass(errors.contactName)} pl-12`} />
                </div>
            </div>
            <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Organization / Company</label>
                <input value={formData.organization} onChange={e => updateField('organization', e.target.value)} className={InputClass(false)} />
            </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Email *</label>
                <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input type="email" value={formData.contactEmail} onChange={e => updateField('contactEmail', e.target.value)} className={`${InputClass(errors.contactEmail)} pl-12`} />
                </div>
            </div>
            <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Phone Number *</label>
                <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input type="tel" value={formData.contactPhone} onChange={e => updateField('contactPhone', e.target.value)} className={`${InputClass(errors.contactPhone)} pl-12`} />
                </div>
            </div>
        </div>
        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Billing Address *</label>
            <textarea value={formData.billingAddress} onChange={e => updateField('billingAddress', e.target.value)} className={`${InputClass(errors.billingAddress)} h-24 resize-none`} />
        </div>
    </div>
  );

  const renderStep6 = () => (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
        
        {/* Manifest Receipt */}
        <div className="bg-white dark:bg-mid-surface border border-slate-200 dark:border-white/10 rounded-2xl overflow-hidden shadow-lg">
            <div className="bg-slate-100 dark:bg-white/5 p-4 border-b border-slate-200 dark:border-white/10 flex justify-between items-center">
                <h4 className="text-sm font-bold uppercase tracking-widest text-slate-900 dark:text-white">Manifest ID: #DRAFT</h4>
                <span className="text-[9px] font-mono text-slate-500">{new Date().toLocaleDateString()}</span>
            </div>
            <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8 text-xs">
                {/* Logistics */}
                <div className="space-y-3">
                    <h5 className="font-bold text-mid-primary uppercase tracking-wider mb-2 flex items-center gap-2"><MapPin className="w-3 h-3" /> Logistics</h5>
                    <div className="grid grid-cols-[80px_1fr] gap-1">
                        <span className="text-slate-500">Event:</span><span className="font-bold text-slate-900 dark:text-white">{formData.eventTitle} ({formData.eventType})</span>
                        <span className="text-slate-500">Date:</span><span className="font-bold text-slate-900 dark:text-white">{formData.date}</span>
                        <span className="text-slate-500">Timing:</span><span className="font-bold text-slate-900 dark:text-white">{formData.startTime} - {formData.endTime}</span>
                        <span className="text-slate-500">Venue:</span><span className="font-bold text-slate-900 dark:text-white">{formData.venueName}</span>
                        <span className="text-slate-500">Location:</span><span className="text-slate-900 dark:text-white truncate">{formData.address}</span>
                        <span className="text-slate-500">Setup:</span><span className="text-slate-900 dark:text-white">{formData.isIndoor ? 'Indoor' : 'Outdoor'}</span>
                    </div>
                </div>

                {/* Tech Rider Summary */}
                <div className="space-y-3">
                    <h5 className="font-bold text-mid-accent uppercase tracking-wider mb-2 flex items-center gap-2"><Zap className="w-3 h-3" /> Tech Rider</h5>
                    <div className="flex flex-wrap gap-2">
                        {formData.needsSound && <span className="px-2 py-1 bg-slate-100 dark:bg-white/10 rounded border border-slate-200 dark:border-white/10">Sound</span>}
                        {formData.needsLighting && <span className="px-2 py-1 bg-slate-100 dark:bg-white/10 rounded border border-slate-200 dark:border-white/10">Light</span>}
                        {formData.needsVideo && <span className="px-2 py-1 bg-slate-100 dark:bg-white/10 rounded border border-slate-200 dark:border-white/10">Video</span>}
                        {formData.needsCatering && <span className="px-2 py-1 bg-slate-100 dark:bg-white/10 rounded border border-slate-200 dark:border-white/10">Catering</span>}
                        {formData.needsSecurity && <span className="px-2 py-1 bg-slate-100 dark:bg-white/10 rounded border border-slate-200 dark:border-white/10">Security</span>}
                        {(!formData.needsSound && !formData.needsLighting && !formData.needsVideo && !formData.needsCatering && !formData.needsSecurity) && <span className="text-slate-500 italic">No specific tech requests</span>}
                    </div>
                    {formData.soundDetails && <p className="text-[10px] text-slate-500 mt-2 italic border-l-2 border-slate-300 pl-2">Sound: "{formData.soundDetails}"</p>}
                </div>
            </div>
            {/* Contact Section */}
            <div className="p-4 bg-slate-50 dark:bg-white/[0.02] border-t border-slate-200 dark:border-white/10 text-xs flex justify-between items-center">
                <div className="flex gap-4">
                    <span><span className="text-slate-500">Contact:</span> <span className="font-bold">{formData.contactName}</span></span>
                    <span><span className="text-slate-500">Phone:</span> <span className="font-bold">{formData.contactPhone}</span></span>
                </div>
                <div className="font-bold text-mid-primary">{SERVICES.find(s => s.id === selectedService)?.label}</div>
            </div>
        </div>

        <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-mid-text-subtle">Additional Comments</label>
            <textarea value={formData.comments} onChange={e => updateField('comments', e.target.value)} className="w-full bg-white dark:bg-black/40 border-2 border-slate-300 dark:border-white/5 rounded-xl px-4 py-3 text-sm text-slate-900 dark:text-white focus:outline-none h-20 resize-none" />
        </div>

        <div className="space-y-3 pt-2">
            <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={formData.acceptedTerms} onChange={e => updateField('acceptedTerms', e.target.checked)} className="w-4 h-4 accent-mid-primary" />
                <span className="text-xs text-slate-600 dark:text-slate-300">I accept the Terms & Conditions and cancellation policy *</span>
            </label>
            <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={formData.authorizedShare} onChange={e => updateField('authorizedShare', e.target.checked)} className="w-4 h-4 accent-mid-primary" />
                <span className="text-xs text-slate-600 dark:text-slate-300">I authorize MidMike to share my contact details with service providers *</span>
            </label>
        </div>
    </div>
  );

  if (success) {
      return (
          <div className="min-h-[80vh] flex flex-col items-center justify-center text-center animate-cinematic-fade bg-white dark:bg-[#121212] rounded-[32px] border border-slate-200 dark:border-white/5 m-4 p-6 shadow-xl">
              <div className="w-24 h-24 bg-green-500/10 rounded-full flex items-center justify-center mb-8 border border-green-500/20 shadow-[0_0_50px_rgba(34,197,94,0.2)] animate-in zoom-in duration-500">
                  <Check className="w-12 h-12 text-green-500" />
              </div>
              <h2 className="text-4xl md:text-5xl font-inter font-normal text-slate-900 dark:text-white mb-6">Booking Confirmed</h2>
              <p className="text-slate-500 dark:text-slate-400 max-w-md mb-10 text-base md:text-lg leading-relaxed">
                  Your request ID is #MM-{Math.floor(Math.random()*10000)}. <br/> A confirmation email with payment schedule has been sent to {formData.contactEmail}.
              </p>
              <button onClick={() => { setSuccess(false); setSelectedService(SERVICES[0].id); setCurrentStep(1); }} className="px-8 py-4 rounded-full bg-slate-900 dark:bg-white text-white dark:text-black font-bold uppercase tracking-widest text-xs transition-all hover:scale-105">
                  Start New Booking
              </button>
          </div>
      );
  }

  return (
    <div className="animate-cinematic-fade pb-24">
      {/* Immersive Hero */}
      <div className="relative h-[65vh] md:h-[70vh] w-full rounded-[24px] md:rounded-[32px] overflow-hidden mb-12 md:mb-16 group shadow-2xl">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=2000')] bg-cover bg-center transition-transform duration-[20s] ease-linear group-hover:scale-105" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-[#121212]/60 to-transparent" />
          
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6 z-10">
              <div className="flex items-center gap-3 mb-4 md:mb-6 animate-in slide-in-from-bottom-4 fade-in duration-700">
                  <div className="px-3 py-1 bg-mid-primary/20 border border-mid-primary/40 rounded-full text-mid-primary text-[9px] font-bold uppercase tracking-[0.25em] backdrop-blur-md">
                      The Sonic Lab
                  </div>
              </div>
              <h1 className="text-4xl md:text-7xl lg:text-8xl font-inter font-normal text-white mb-4 md:mb-6 tracking-tighter drop-shadow-2xl animate-in zoom-in-95 duration-1000 leading-[1.1]">
                  Create Without Limits.
              </h1>
              <p className="text-slate-300 text-sm md:text-lg max-w-2xl mb-8 md:mb-10 font-light tracking-wide leading-relaxed animate-in slide-in-from-bottom-8 fade-in duration-1000 delay-100">
                  Select a service below to configure your session in the booking console.
              </p>
              <button 
                onClick={scrollToBooking}
                className="w-full md:w-auto px-10 py-4 bg-white text-black hover:bg-mid-highlight transition-all duration-300 rounded-full font-bold text-xs uppercase tracking-[0.25em] flex items-center justify-center gap-3 shadow-[0_0_40px_rgba(255,255,255,0.2)] animate-in fade-in duration-1000 delay-200"
              >
                  Book Session <ArrowRight className="w-4 h-4" />
              </button>
          </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-start">
              
              {/* Service Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {SERVICES.map((s) => (
                      <button
                          key={s.id}
                          onClick={() => { setSelectedService(s.id); scrollToBooking(); }}
                          className={`
                              relative p-6 rounded-3xl border text-left transition-all duration-500 group overflow-hidden h-full shadow-sm hover:shadow-md
                              ${selectedService === s.id 
                                  ? 'bg-mid-primary/10 border-mid-primary ring-1 ring-mid-primary shadow-glow-blue' 
                                  : 'bg-white dark:bg-white/[0.02] border-slate-200 dark:border-white/10 hover:border-mid-primary/30 dark:hover:border-white/30 hover:bg-slate-50 dark:hover:bg-white/[0.04]'}
                          `}
                      >
                          <div className={`
                              w-12 h-12 rounded-2xl flex items-center justify-center mb-6 transition-colors duration-300
                              ${selectedService === s.id ? 'bg-mid-primary text-white' : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-mid-text-muted group-hover:bg-slate-200 dark:group-hover:bg-white/10 group-hover:text-slate-900 dark:group-hover:text-white'}
                          `}>
                              <s.icon className="w-6 h-6" />
                          </div>
                          
                          <h3 className={`text-lg md:text-xl font-inter font-medium mb-2 ${selectedService === s.id ? 'text-mid-primary' : 'text-slate-900 dark:text-white group-hover:text-mid-primary transition-colors'}`}>
                              {s.label}
                          </h3>
                          <p className="text-xs text-slate-500 dark:text-mid-text-subtle leading-relaxed mb-6 h-10 line-clamp-2">
                              {s.desc}
                          </p>

                          <div className="pt-4 border-t border-slate-100 dark:border-white/5 flex flex-col gap-2">
                              <div className="flex items-center gap-2 text-[10px] text-slate-400 dark:text-slate-400 font-bold uppercase tracking-wider">
                                  <Zap className="w-3 h-3 text-mid-highlight" />
                                  <span className="truncate">{s.gear}</span>
                              </div>
                              <div className="flex items-center gap-2 text-[10px] text-slate-400 dark:text-slate-400 font-bold uppercase tracking-wider">
                                  <span className="w-3 h-3 flex items-center justify-center font-serif italic text-mid-accent">$</span>
                                  <span>{s.price}</span>
                              </div>
                          </div>
                      </button>
                  ))}
              </div>

              {/* Console Chassis */}
              <div id="booking-console" className="relative mt-8 lg:mt-0">
                  <div className="absolute inset-0 bg-slate-300 dark:bg-[#1a1a1a] rounded-[36px] transform translate-y-1 translate-x-1 md:translate-y-2 md:translate-x-2 border border-slate-400 dark:border-black/50 shadow-2xl" />
                  
                  <div className="relative bg-slate-100 dark:bg-[#222] border-2 border-slate-300 dark:border-white/10 rounded-[32px] p-5 md:p-10 shadow-[inset_0_2px_20px_rgba(255,255,255,0.5)] dark:shadow-[inset_0_2px_20px_rgba(0,0,0,0.5)] overflow-visible transition-colors duration-500 min-h-[650px] flex flex-col">
                      {/* Metallic Texture Overlay */}
                      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/brushed-alum.png')] dark:bg-[url('https://www.transparenttextures.com/patterns/brushed-alum-dark.png')] opacity-30 pointer-events-none rounded-[32px] overflow-hidden" />
                      
                      {/* Screws */}
                      <div className="hidden md:flex absolute top-4 left-4 w-3 h-3 rounded-full bg-slate-300 dark:bg-[#111] border border-slate-400 dark:border-white/10 shadow-inner items-center justify-center"><div className="w-1.5 h-[1px] bg-slate-500 dark:bg-white/20 rotate-45" /></div>
                      <div className="hidden md:flex absolute top-4 right-4 w-3 h-3 rounded-full bg-slate-300 dark:bg-[#111] border border-slate-400 dark:border-white/10 shadow-inner items-center justify-center"><div className="w-1.5 h-[1px] bg-slate-500 dark:bg-white/20 rotate-45" /></div>
                      <div className="hidden md:flex absolute bottom-4 left-4 w-3 h-3 rounded-full bg-slate-300 dark:bg-[#111] border border-slate-400 dark:border-white/10 shadow-inner items-center justify-center"><div className="w-1.5 h-[1px] bg-slate-500 dark:bg-white/20 rotate-45" /></div>
                      <div className="hidden md:flex absolute bottom-4 right-4 w-3 h-3 rounded-full bg-slate-300 dark:bg-[#111] border border-slate-400 dark:border-white/10 shadow-inner items-center justify-center"><div className="w-1.5 h-[1px] bg-slate-500 dark:bg-white/20 rotate-45" /></div>

                      <div className="relative z-10 flex flex-col h-full">
                          {/* Console Header - Timeline Style */}
                          <div className="mb-8 border-b border-slate-300 dark:border-white/5 pb-6">
                              <div className="flex items-center justify-between mb-4">
                                  <div className="flex items-center gap-3">
                                      <div className={`w-2 h-2 rounded-full ${selectedService ? 'bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.8)]' : 'bg-red-500 animate-pulse'}`} />
                                      <div className="flex flex-col">
                                          <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500 dark:text-white/40 font-mono">
                                              MISSION SEQUENCE
                                          </h3>
                                          <span className="text-xs font-bold text-slate-800 dark:text-white uppercase tracking-wider">
                                              {selectedService ? (SERVICES.find(s=>s.id===selectedService)?.label) : 'SELECT_SERVICE'}
                                          </span>
                                      </div>
                                  </div>
                                  {selectedService && (
                                      <button onClick={handleClearDraft} className="text-[9px] font-bold uppercase tracking-widest text-slate-400 hover:text-red-500 transition-colors flex items-center gap-1">
                                          <RotateCcw className="w-3 h-3" /> Reset
                                      </button>
                                  )}
                              </div>
                              
                              {/* New Timeline Stepper */}
                              <div className="flex justify-between relative px-2">
                                  <div className="absolute top-1/2 left-0 w-full h-[1px] bg-slate-300 dark:bg-white/10 -z-10"