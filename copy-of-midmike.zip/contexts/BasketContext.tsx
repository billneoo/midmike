
import React, { createContext, useContext, useState, ReactNode } from 'react';
import { BaseEntity } from '../types';

export interface ShortlistItem extends BaseEntity {
  addedAt: number;
}

interface ShortlistContextType {
  items: ShortlistItem[];
  addToShortlist: (item: BaseEntity) => void;
  removeFromShortlist: (itemId: string) => void;
  clearShortlist: () => void;
  totalItems: number;
  isInShortlist: (id: string) => boolean;
}

const ShortlistContext = createContext<ShortlistContextType | undefined>(undefined);

export const BasketProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<ShortlistItem[]>([]);

  const addToShortlist = (item: BaseEntity) => {
    setItems(prev => {
      if (prev.find(i => i.id === item.id)) return prev;
      return [...prev, { ...item, addedAt: Date.now() }];
    });
  };

  const removeFromShortlist = (itemId: string) => {
    setItems(prev => prev.filter(i => i.id !== itemId));
  };

  const clearShortlist = () => setItems([]);

  const isInShortlist = (id: string) => items.some(i => i.id === id);

  return (
    <ShortlistContext.Provider value={{ items, addToShortlist, removeFromShortlist, clearShortlist, totalItems: items.length, isInShortlist }}>
      {children}
    </ShortlistContext.Provider>
  );
};

export const useBasket = () => {
  const context = useContext(ShortlistContext);
  if (!context) throw new Error('useShortlist must be used within ShortlistProvider');
  
  // Mapping new names to old interface for compatibility where needed, but preferring new names
  return {
      items: context.items,
      addToBasket: context.addToShortlist, // Alias for legacy components
      addToShortlist: context.addToShortlist,
      removeFromBasket: context.removeFromShortlist, // Alias
      removeFromShortlist: context.removeFromShortlist,
      clearBasket: context.clearShortlist, // Alias
      clearShortlist: context.clearShortlist,
      totalItems: context.totalItems,
      isInShortlist: context.isInShortlist
  };
};
