import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { User, Role } from '../types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (userData: User) => void;
  register: (userData: User) => void;
  logout: () => void;
  switchRole: (newRole: Role) => void;
  updateProfile: (data: Partial<User>) => void;
  requireAuth: (action: () => void) => void;
  isAuthModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  // Role Management
  isAddingRole: boolean;
  openAddRole: () => void;
  // Theme & Language
  theme: 'dark' | 'light';
  setTheme: (theme: 'dark' | 'light') => void;
  language: 'EN' | 'FR' | 'AR';
  setLanguage: (lang: 'EN' | 'FR' | 'AR') => void;
  // Live Status
  isLive: boolean;
  setIsLive: (live: boolean) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthModalOpen, setAuthModalOpen] = useState(false);
  const [isAddingRole, setIsAddingRole] = useState(false);
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);
  const [isLive, setIsLive] = useState(true); // Platform is live by default in mock

  // Persistence for Guests & Users
  const [theme, setThemeState] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('midmike-theme') as 'dark' | 'light') || 'dark';
  });
  const [language, setLanguageState] = useState<'EN' | 'FR' | 'AR'>(() => {
    return (localStorage.getItem('midmike-lang') as 'EN' | 'FR' | 'AR') || 'EN';
  });

  const setTheme = (newTheme: 'dark' | 'light') => {
    setThemeState(newTheme);
    localStorage.setItem('midmike-theme', newTheme);
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
  };

  const setLanguage = (lang: 'EN' | 'FR' | 'AR') => {
    setLanguageState(lang);
    localStorage.setItem('midmike-lang', lang);
  };

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  // Reset adding role state when modal closes
  useEffect(() => {
    if (!isAuthModalOpen) {
      setIsAddingRole(false);
    }
  }, [isAuthModalOpen]);

  const login = (userData: User) => {
    setUser(userData);
    setAuthModalOpen(false);
    if (pendingAction) {
      pendingAction();
      setPendingAction(null);
    }
  };

  const register = (userData: User) => {
    setUser(userData);
    setAuthModalOpen(false);
    if (pendingAction) {
      pendingAction();
      setPendingAction(null);
    }
  };

  const logout = () => {
    setUser(null);
  };

  const switchRole = (newRole: Role) => {
    if (user && user.availableRoles.includes(newRole)) {
      setUser({ ...user, role: newRole });
    }
  };

  const updateProfile = (data: Partial<User>) => {
    if (user) {
      setUser({ ...user, ...data });
    }
  };

  const requireAuth = (action: () => void) => {
    if (user) {
      action();
    } else {
      setPendingAction(() => action);
      setAuthModalOpen(true);
    }
  };

  const openAddRole = () => {
    if (user) {
      setIsAddingRole(true);
      setAuthModalOpen(true);
    } else {
      setAuthModalOpen(true);
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      isAuthenticated: !!user, 
      login, 
      register, 
      logout, 
      switchRole,
      updateProfile,
      requireAuth,
      isAuthModalOpen,
      setAuthModalOpen,
      isAddingRole,
      openAddRole,
      theme,
      setTheme,
      language,
      setLanguage,
      isLive,
      setIsLive
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};