
import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface TourStep {
  targetId: string;
  title: string;
  content: string;
  position?: 'top' | 'bottom' | 'left' | 'right';
}

interface TourContextType {
  isTourActive: boolean;
  currentStepIndex: number;
  startTour: () => void;
  endTour: () => void;
  nextStep: () => void;
  prevStep: () => void;
  steps: TourStep[];
}

const TOUR_STEPS: TourStep[] = [
  {
    targetId: 'sidebar', // The entire sidebar
    title: 'Navigation Hub',
    content: 'Access all major sections here. Switch between Events, Artist directories, and Professional tools.',
    position: 'right'
  },
  {
    targetId: 'global-search', // The top bar search
    title: 'Global Search',
    content: 'Find anything instantly. Search for specific venues, artists by genre, or technical equipment.',
    position: 'bottom'
  },
  {
    targetId: 'create-event-btn', // The create button
    title: 'Create & Launch',
    content: 'Ready to host? Start the event creation wizard here to publish your event to the network.',
    position: 'bottom'
  },
  {
    targetId: 'user-menu', // The user avatar
    title: 'Your Identity',
    content: 'Manage your profile, switch between roles (e.g., Artist vs Client), and access account settings.',
    position: 'bottom' // Desktop: bottom-left, Mobile handles auto
  }
];

const TourContext = createContext<TourContextType | undefined>(undefined);

export const TourProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isTourActive, setIsTourActive] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  const startTour = () => {
    setCurrentStepIndex(0);
    setIsTourActive(true);
  };

  const endTour = () => {
    setIsTourActive(false);
    setCurrentStepIndex(0);
  };

  const nextStep = () => {
    if (currentStepIndex < TOUR_STEPS.length - 1) {
      setCurrentStepIndex(prev => prev + 1);
    } else {
      endTour();
    }
  };

  const prevStep = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(prev => prev - 1);
    }
  };

  return (
    <TourContext.Provider value={{ 
      isTourActive, 
      currentStepIndex, 
      startTour, 
      endTour, 
      nextStep, 
      prevStep,
      steps: TOUR_STEPS
    }}>
      {children}
    </TourContext.Provider>
  );
};

export const useTour = () => {
  const context = useContext(TourContext);
  if (!context) throw new Error('useTour must be used within TourProvider');
  return context;
};
